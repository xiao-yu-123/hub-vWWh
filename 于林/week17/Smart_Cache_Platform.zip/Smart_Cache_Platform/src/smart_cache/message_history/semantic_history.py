"""Semantic Message History — session-scoped conversation storage with semantic retrieval."""

import json
from typing import Optional, List, Union

import numpy as np

from ..core.connection import get_connection
from ..embeddings.local import LocalVectorizer
from ..schemas import Message, MessageRole


class SemanticMessageHistory:
    """Stores conversation history per session in Redis with semantic search.

    Each session is identified by a unique `name` (session_id).
    Messages are stored as a JSON list with role + content.

    Usage:
        history = SemanticMessageHistory(name="session-123", ttl=86400)
        history.add_messages([
            {"role": "user", "content": "hello"},
            {"role": "llm", "content": "Hi there!"},
        ])
        recent = history.get_recent(top_k=5)
        relevant = history.get_relevant("hello", top_k=3)
    """

    REDIS_KEY_PREFIX = "semantic_history"

    def __init__(self, name: str, ttl: int = 86400, distance_threshold: float = 0.7):
        self.name = name
        self.ttl = ttl
        self.distance_threshold = distance_threshold

        conn = get_connection()
        self._redis = conn.redis_client
        self._vectorizer = LocalVectorizer()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_messages(self, messages: List[dict]) -> bool:
        """Append messages to the session history.

        Each message dict must have "role" and "content" keys.
        Optional "metadata" dict is also supported.

        Args:
            messages: A list of message dicts, e.g.
                      [{"role": "user", "content": "hello"}]
        """
        current = self.get_history()
        current.extend(messages)
        self._save_history(current)
        return True

    def get_history(self) -> List[dict]:
        """Return the full conversation history for this session."""
        raw = self._redis.get(self._redis_key())
        if raw is None:
            return []
        return json.loads(raw)

    def get_recent(
        self,
        role: Optional[Union[str, MessageRole]] = None,
        top_k: int = 10,
    ) -> List[dict]:
        """Return the most recent messages, optionally filtered by role.

        Args:
            role: If provided, only return messages with this role.
            top_k: Maximum number of messages to return (most recent first).

        Returns:
            A list of message dicts, newest last in the returned slice.
        """
        history = self.get_history()
        if role:
            role_val = role.value if isinstance(role, MessageRole) else role
            history = [m for m in history if m.get("role") == role_val]

        return history[-top_k:] if top_k else history

    def get_relevant(
        self,
        content: str,
        top_k: int = 10,
    ) -> List[dict]:
        """Return messages semantically relevant to the given content.

        Uses embedding-based semantic similarity instead of Levenshtein.

        Args:
            content: The query text to find relevant messages for.
            top_k: Maximum number of relevant messages to return.

        Returns:
            A list of message dicts sorted by relevance (most relevant first).
        """
        history = self.get_history()
        if not history:
            return []

        # Extract content from each message
        contents = [m.get("content", "") for m in history]

        # Embed the query and all message contents
        query_vec = self._vectorizer.embed(content)
        content_vecs = self._vectorizer.embed(contents)

        # Compute cosine similarity (vectors are already normalized)
        similarities = np.dot(content_vecs, query_vec.T).flatten()

        # Sort by similarity descending
        ranked = sorted(
            enumerate(similarities),
            key=lambda x: x[1],
            reverse=True,
        )

        # Filter by distance threshold (1 - similarity ≈ cosine distance)
        # distance = 1 - cosine_similarity for normalized vectors
        result = []
        for idx, sim in ranked:
            dist = 1.0 - float(sim)
            if dist <= self.distance_threshold and len(result) < top_k:
                result.append(history[idx])

        return result

    def delete_history(self, keep_last: int = 0):
        """Trim the history, keeping only the last `keep_last` messages.

        Args:
            keep_last: Number of most recent messages to retain.
        """
        history = self.get_history()
        if keep_last > 0:
            history = history[-keep_last:]
        else:
            history = []
        self._save_history(history)

    def clear_history(self) -> bool:
        """Delete the entire session history from Redis."""
        self._redis.delete(self._redis_key())
        return True

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _redis_key(self) -> str:
        return f"{self.REDIS_KEY_PREFIX}:{self.name}"

    def _save_history(self, history: List[dict]):
        self._redis.setex(
            self._redis_key(),
            self.ttl,
            json.dumps(history, ensure_ascii=False),
        )
