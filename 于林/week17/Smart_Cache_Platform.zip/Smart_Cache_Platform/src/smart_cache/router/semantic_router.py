"""Semantic Router — intent classification via embedding similarity + caching."""

import hashlib
import json
from typing import Optional, List, Dict

from pymilvus import DataType

from ..core.connection import get_connection
from ..embeddings.local import LocalVectorizer
from ..schemas import Route, RouteResult


class SemanticRouter:
    """Classifies queries into named routes using embedding-based nearest-neighbor.

    Each Route defines a category with reference examples. When `route()` is called:
    1. If the query was previously routed, return the cached result.
    2. Otherwise, embed the query, search for the closest reference in Milvus,
       and return the matching route.
    3. Cache the result in Redis for future calls.

    Usage:
        router = SemanticRouter(name="topic-router")
        router.add_routes([
            Route(name="greeting", references=["hello", "hi"], distance_threshold=0.3),
            Route(name="farewell", references=["bye", "goodbye"], distance_threshold=0.3),
        ])
        result = router.route("Hi, good morning")  # → RouteResult(route_name="greeting", ...)
    """

    def __init__(self, name: str):
        self.name = name
        conn = get_connection()
        self._redis = conn.redis_client
        self._milvus = conn.milvus_client
        self._vectorizer = LocalVectorizer()
        self._dim = self._vectorizer.get_dimension()

        self._collection_name = f"semantic_router_{name}"
        self._routes: Dict[str, Route] = {}  # route_name → Route

        self._ensure_collection()
        self._load_existing_routes()

    # ------------------------------------------------------------------
    # Milvus collection management
    # ------------------------------------------------------------------

    def _ensure_collection(self):
        """Create the Milvus collection for route references if it doesn't exist."""
        if self._milvus.has_collection(self._collection_name):
            return

        schema = self._milvus.create_schema(auto_id=True)
        schema.add_field("id", datatype=DataType.INT64, is_primary=True)
        schema.add_field(
            "vector",
            datatype=DataType.FLOAT_VECTOR,
            dim=self._dim,
        )
        schema.add_field("reference", datatype=DataType.VARCHAR, max_length=2048)
        schema.add_field("route_name", datatype=DataType.VARCHAR, max_length=256)

        self._milvus.create_collection(
            collection_name=self._collection_name,
            schema=schema,
        )

        index_params = self._milvus.prepare_index_params()
        index_params.add_index(
            field_name="vector",
            index_type="IVF_FLAT",
            metric_type="L2",
            params={"nlist": 128},
        )
        self._milvus.create_index(self._collection_name, index_params)
        self._milvus.load_collection(self._collection_name)

    def _load_existing_routes(self):
        """Load routes that were already stored in Redis (survive restarts)."""
        raw = self._redis.get(f"router:{self.name}:routes")
        if raw:
            routes_data = json.loads(raw)
            for r_data in routes_data:
                route = Route(**r_data)
                self._routes[route.name] = route

    def _save_routes_meta(self):
        """Persist route metadata to Redis."""
        data = [r.model_dump() for r in self._routes.values()]
        self._redis.set(f"router:{self.name}:routes", json.dumps(data, ensure_ascii=False))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_routes(self, routes: List[Route]) -> bool:
        """Register one or more routes and index their references in Milvus.

        Args:
            routes: A list of Route objects to add.

        Returns:
            True on success.
        """
        data = []
        for route in routes:
            self._routes[route.name] = route
            embeddings = self._vectorizer.embed(route.references)
            for ref, vec in zip(route.references, embeddings):
                data.append({
                    "reference": ref,
                    "route_name": route.name,
                    "vector": vec.tolist(),
                })

        if data:
            self._milvus.insert(collection_name=self._collection_name, data=data)
            self._milvus.load_collection(self._collection_name)

        self._save_routes_meta()
        return True

    def route(self, question: str) -> Optional[RouteResult]:
        """Classify a question into the best matching route.

        1. Check Redis cache — if this exact question was routed before, return cached.
        2. Embed the question and search Milvus for the closest reference.
        3. Check if the distance is within the route's threshold.
        4. Cache and return the result.

        Args:
            question: The query string to classify.

        Returns:
            RouteResult if matched, None if no route is close enough.
        """
        # 1. Check exact-match cache in Redis
        cached = self._get_cached_result(question)
        if cached is not None:
            return cached

        # 2. Embed and search
        vector = self._vectorizer.embed(question)
        search_vec = vector.tolist() if vector.ndim == 1 else vector[0].tolist()

        results = self._milvus.search(
            collection_name=self._collection_name,
            data=[search_vec],
            limit=5,
            output_fields=["reference", "route_name"],
        )

        if not results or not results[0]:
            return None

        # 3. Check each hit against its route's distance_threshold
        for hit in results[0]:
            route_name = hit["entity"]["route_name"]
            route = self._routes.get(route_name)
            if route is None:
                continue

            if hit["distance"] < route.distance_threshold:
                result = RouteResult(
                    route_name=route_name,
                    distance=hit["distance"],
                    metadata=route.metadata,
                    matched_reference=hit["entity"]["reference"],
                )
                # 4. Cache the result
                self._set_cached_result(question, result)
                return result

        return None

    # ------------------------------------------------------------------
    # Cache helpers (Redis)
    # ------------------------------------------------------------------

    def _cache_key(self, question: str) -> str:
        h = hashlib.md5(question.encode("utf-8")).hexdigest()
        return f"router:{self.name}:result:{h}"

    def _get_cached_result(self, question: str) -> Optional[RouteResult]:
        raw = self._redis.get(self._cache_key(question))
        if raw is None:
            return None
        return RouteResult(**json.loads(raw))

    def _set_cached_result(self, question: str, result: RouteResult):
        self._redis.setex(
            self._cache_key(question),
            86400,  # cache routing results for 24h
            json.dumps(result.model_dump(), ensure_ascii=False),
        )

    def clear_cache(self):
        """Clear all routing result caches (not the route definitions)."""
        pattern = f"router:{self.name}:result:*"
        cursor = 0
        while True:
            cursor, keys = self._redis.scan(cursor=cursor, match=pattern, count=100)
            if keys:
                self._redis.delete(*keys)
            if cursor == 0:
                break
