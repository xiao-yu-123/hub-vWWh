"""Embedding Cache — caches text→vector results to avoid redundant computation."""

import hashlib
from typing import Optional, List, Union

import numpy as np

from ..core.connection import get_connection
from ..schemas import EmbeddingRecord


class EmbeddingCache:
    """Cache that stores computed embeddings in Redis, keyed by MD5 of the text.

    Usage:
        cache = EmbeddingCache(name="embed_cache", ttl=3600)
        cache.store(text="What is ML?", embedding=np.array([...]))
        result = cache.get(text="What is ML?")   # returns np.array or None
    """

    def __init__(self, name: str, ttl: int = 3600):
        self.name = name
        self.ttl = ttl
        conn = get_connection()
        self._redis = conn.redis_client_raw  # raw bytes mode for numpy arrays

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store(self, text: Union[str, List[str]], embedding: np.ndarray) -> bool:
        """Cache one or more text→embedding pairs.

        Args:
            text: A single text string or a list of text strings.
            embedding: Corresponding embedding(s). If text is a list, embedding
                       must be a 2D array with the same number of rows.

        Returns:
            True on success.
        """
        if isinstance(text, str):
            text = [text]
            embedding = embedding.reshape(1, -1) if embedding.ndim == 1 else embedding

        if len(text) != len(embedding):
            raise ValueError("text and embedding must have the same length")

        pipe = self._redis.pipeline()
        for t, emb in zip(text, embedding):
            key = self._make_key(t)
            pipe.setex(key, self.ttl, emb.astype(np.float32).tobytes())
        pipe.execute()

        return True

    def get(self, text: Union[str, List[str]]) -> Optional[Union[np.ndarray, List[Optional[np.ndarray]]]]:
        """Retrieve cached embedding(s) for the given text(s).

        Args:
            text: A single text string or a list of text strings.

        Returns:
            - For a single str: numpy array or None if not cached.
            - For a list: list of numpy arrays (None for cache misses).
        """
        single = isinstance(text, str)
        if single:
            text = [text]

        keys = [self._make_key(t) for t in text]
        results = self._redis.mget(keys)

        embeddings: List[Optional[np.ndarray]] = []
        for r in results:
            if r is None:
                embeddings.append(None)
            else:
                embeddings.append(np.frombuffer(r, dtype=np.float32))

        if single:
            return embeddings[0]
        return embeddings

    def delete(self, text: Union[str, List[str]]) -> bool:
        """Remove cached embedding(s) for the given text(s)."""
        if isinstance(text, str):
            text = [text]

        keys = [self._make_key(t) for t in text]
        self._redis.delete(*keys)
        return True

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_key(self, text: str) -> str:
        """Generate a deterministic Redis key from the text content."""
        h = hashlib.md5(text.encode("utf-8")).hexdigest()
        return f"{self.name}:{h}"
