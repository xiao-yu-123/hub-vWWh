"""Semantic Cache — LLM request/response caching by semantic similarity."""

import hashlib
import json
import time
from typing import Optional, List, Union

import numpy as np
from pymilvus import DataType

from ..core.config import get_config
from ..core.connection import get_connection
from ..embeddings.local import LocalVectorizer
from ..schemas import CacheEntry, CacheCheckResult


class SemanticCache:
    """Cache that matches prompts by semantic similarity using Milvus + Redis.

    Flow:
    1. store(prompt, response): embed prompt → store vector in Milvus, store response in Redis.
    2. check(prompt): embed prompt → search Milvus for nearest vectors →
       filter by distance_threshold → fetch response from Redis.

    Usage:
        cache = SemanticCache(name="llmcache", ttl=3600, distance_threshold=0.1)
        cache.store(prompt="中国的首都是什么？", response="北京")
        result = cache.check(prompt="中国的首都？")
    """

    def __init__(
        self,
        name: str,
        ttl: int = 3600,
        distance_threshold: float = 0.1,
    ):
        self.name = name
        self.ttl = ttl
        self.distance_threshold = distance_threshold

        conn = get_connection()
        self._redis = conn.redis_client
        self._milvus = conn.milvus_client

        self._vectorizer = LocalVectorizer()
        self._dim = self._vectorizer.get_dimension()

        self._collection_name = f"semantic_cache_{name}"
        self._ensure_collection()

    # ------------------------------------------------------------------
    # Milvus collection management
    # ------------------------------------------------------------------

    def _ensure_collection(self):
        """Create the Milvus collection if it does not already exist."""
        if self._milvus.has_collection(self._collection_name):
            return

        schema = self._milvus.create_schema(auto_id=True)
        schema.add_field("id", datatype=DataType.INT64, is_primary=True)
        schema.add_field(
            "vector",
            datatype=DataType.FLOAT_VECTOR,
            dim=self._dim,
        )
        schema.add_field("prompt", datatype=DataType.VARCHAR, max_length=8192)

        self._milvus.create_collection(
            collection_name=self._collection_name,
            schema=schema,
        )

        # Build an IVF_FLAT index for fast approximate search
        index_params = self._milvus.prepare_index_params()
        index_params.add_index(
            field_name="vector",
            index_type="IVF_FLAT",
            metric_type="L2",
            params={"nlist": 128},
        )
        self._milvus.create_index(self._collection_name, index_params)
        self._milvus.load_collection(self._collection_name)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store(
        self,
        prompt: Union[str, List[str]],
        response: Union[str, List[str]],
    ) -> bool:
        """Store one or more prompt-response pairs in the cache.

        Args:
            prompt: A single prompt string or a list of prompt strings.
            response: A single response string or a list of response strings
                      (must match prompt length).

        Returns:
            True on success.
        """
        if isinstance(prompt, str):
            prompt = [prompt]
            response = [response]

        if len(prompt) != len(response):
            raise ValueError("prompt and response must have the same length")

        # Embed all prompts
        vectors = self._vectorizer.embed(prompt)

        # Insert into Milvus and Redis in one go
        data = []
        for i, (p, vec) in enumerate(zip(prompt, vectors)):
            data.append({"prompt": p, "vector": vec.tolist()})

        self._milvus.insert(collection_name=self._collection_name, data=data)

        # Store responses in Redis: key = {name}:resp:{md5(prompt)}
        pipe = self._redis.pipeline()
        for p, r in zip(prompt, response):
            key = self._redis_response_key(p)
            pipe.setex(key, self.ttl, r)
        pipe.execute()

        return True

    def check(self, prompt: str, top_k: int = 5) -> Optional[CacheCheckResult]:
        """Check the cache for a semantically similar prompt.

        Args:
            prompt: The new prompt to look up.
            top_k: Number of nearest neighbors to retrieve from Milvus.

        Returns:
            CacheCheckResult if a match is found within distance_threshold,
            otherwise None.
        """
        # Wait for any pending inserts to be visible
        self._milvus.load_collection(self._collection_name)

        vector = self._vectorizer.embed(prompt)
        # Milvus expects a list of vectors
        search_vector = vector.tolist() if vector.ndim == 1 else vector[0].tolist()

        results = self._milvus.search(
            collection_name=self._collection_name,
            data=[search_vector],
            limit=top_k,
            output_fields=["prompt"],
        )

        if not results or not results[0]:
            return None

        best = None
        for hit in results[0]:
            if hit["distance"] < self.distance_threshold:
                matched_prompt = hit["entity"]["prompt"]
                redis_key = self._redis_response_key(matched_prompt)
                resp = self._redis.get(redis_key)
                if resp is not None:
                    return CacheCheckResult(
                        response=resp,
                        prompt=matched_prompt,
                        distance=hit["distance"],
                    )

        return None

    def clear(self):
        """Remove all cached entries (Milvus collection + Redis keys)."""
        # Delete Milvus collection
        if self._milvus.has_collection(self._collection_name):
            self._milvus.drop_collection(self._collection_name)

        # Delete Redis keys matching our prefix pattern
        pattern = f"{self.name}:resp:*"
        cursor = 0
        while True:
            cursor, keys = self._redis.scan(cursor=cursor, match=pattern, count=100)
            if keys:
                self._redis.delete(*keys)
            if cursor == 0:
                break

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _redis_response_key(self, prompt_text: str) -> str:
        """Generate a deterministic Redis key for a prompt's response."""
        h = hashlib.md5(prompt_text.encode("utf-8")).hexdigest()
        return f"{self.name}:resp:{h}"
