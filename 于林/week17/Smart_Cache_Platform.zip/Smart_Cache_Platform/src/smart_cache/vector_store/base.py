"""Abstract base class for vector store backends."""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any
import numpy as np

from .schema import CollectionSchema, VectorIndexParams


class BaseVectorStore(ABC):
    """Abstract interface for vector storage backends.

    Concrete implementations (e.g. MilvusStore) handle:
    - Collection / index lifecycle
    - Data insertion
    - Vector similarity search
    - Scalar filtering
    """

    @abstractmethod
    def create_collection(self, schema: CollectionSchema) -> bool:
        """Create a new collection from a schema definition."""
        pass

    @abstractmethod
    def drop_collection(self, collection_name: str) -> bool:
        """Delete a collection and all its data."""
        pass

    @abstractmethod
    def has_collection(self, collection_name: str) -> bool:
        """Check whether a collection exists."""
        pass

    @abstractmethod
    def insert(
        self,
        collection_name: str,
        data: List[Dict[str, Any]],
    ) -> List[int]:
        """Insert rows into a collection.

        Args:
            collection_name: Target collection.
            data: List of dicts where keys are field names and values are field values.
                  Vector fields should be provided as list[float].

        Returns:
            List of inserted primary key IDs.
        """
        pass

    @abstractmethod
    def search(
        self,
        collection_name: str,
        vector: np.ndarray,
        top_k: int = 10,
        filter_expr: Optional[str] = None,
        output_fields: Optional[List[str]] = None,
        metric_type: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """Search for nearest neighbors by vector similarity.

        Args:
            collection_name: Target collection.
            vector: Query embedding, shape (dim,) or (1, dim).
            top_k: Number of nearest neighbors to return.
            filter_expr: Optional scalar filter expression (Milvus syntax).
            output_fields: Fields to include in results beyond id + distance.
            metric_type: Override the default metric.

        Returns:
            A list (one per query vector) of lists of hit dicts:
            [{"id": ..., "distance": ..., "entity": {...}}, ...]
        """
        pass

    @abstractmethod
    def delete(
        self,
        collection_name: str,
        filter_expr: str,
    ) -> int:
        """Delete entities matching a filter expression.

        Returns:
            Number of deleted entities.
        """
        pass

    @abstractmethod
    def get_by_id(
        self,
        collection_name: str,
        ids: List[int],
        output_fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve entities by primary key."""
        pass

    @abstractmethod
    def create_index(
        self,
        collection_name: str,
        index_params: VectorIndexParams,
    ) -> bool:
        """Build a vector index on a collection."""
        pass

    @abstractmethod
    def load_collection(self, collection_name: str) -> bool:
        """Load a collection into memory for search."""
        pass
