"""Schema definitions for vector store collections and fields."""

from enum import Enum
from typing import Optional, List
from pydantic import BaseModel, Field
from pymilvus import DataType as _DataType


class FieldDataType(int, Enum):
    """Supported Milvus field data types, mapped to pymilvus DataType values."""
    INT64 = _DataType.INT64
    FLOAT = _DataType.FLOAT
    DOUBLE = _DataType.DOUBLE
    VARCHAR = _DataType.VARCHAR
    BOOL = _DataType.BOOL
    FLOAT_VECTOR = _DataType.FLOAT_VECTOR


class SimilarityMetric(str, Enum):
    """Supported similarity / distance metrics."""
    L2 = "L2"
    IP = "IP"            # Inner Product
    COSINE = "COSINE"


class IndexType(str, Enum):
    """Supported vector index types."""
    IVF_FLAT = "IVF_FLAT"
    IVF_SQ8 = "IVF_SQ8"
    IVF_PQ = "IVF_PQ"
    HNSW = "HNSW"
    FLAT = "FLAT"
    AUTOINDEX = "AUTOINDEX"


class FieldSchema(BaseModel):
    """Definition of a single field in a collection."""
    name: str
    datatype: FieldDataType
    is_primary: bool = False
    auto_id: bool = False
    dim: Optional[int] = None          # Required for vector fields
    max_length: Optional[int] = None   # Required for VARCHAR fields
    default_value: Optional[str] = None
    description: str = ""


class VectorIndexParams(BaseModel):
    """Parameters for building a vector index on a field."""
    field_name: str
    index_type: IndexType = IndexType.IVF_FLAT
    metric_type: SimilarityMetric = SimilarityMetric.L2
    params: dict = Field(default_factory=dict)  # e.g. {"nlist": 128} for IVF_FLAT


class CollectionSchema(BaseModel):
    """Complete definition of a Milvus collection."""
    name: str
    description: str = ""
    fields: List[FieldSchema]
    vector_indexes: List[VectorIndexParams] = Field(default_factory=list)
