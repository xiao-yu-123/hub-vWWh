"""Milvus Cloud vector store implementation."""

from typing import Optional, List, Dict, Any
import numpy as np

from .base import BaseVectorStore
from .schema import CollectionSchema, FieldSchema, FieldDataType, VectorIndexParams, SimilarityMetric
from ..core.connection import get_connection
from ..core.exceptions import StoreError


class MilvusStore(BaseVectorStore):
    """Concrete vector store backed by Milvus Cloud.

    Usage:
        store = MilvusStore()

        schema = CollectionSchema(
            name="my_collection",
            fields=[
                FieldSchema(name="id", datatype=FieldDataType.INT64, is_primary=True, auto_id=True),
                FieldSchema(name="text", datatype=FieldDataType.VARCHAR, max_length=2048),
                FieldSchema(name="vector", datatype=FieldDataType.FLOAT_VECTOR, dim=512),
            ],
            vector_indexes=[
                VectorIndexParams(field_name="vector", metric_type=SimilarityMetric.L2),
            ],
        )
        store.create_collection(schema)
        store.insert("my_collection", [{"text": "hello", "vector": [0.1]*512}])
        results = store.search("my_collection", vector=np.random.randn(512).astype(np.float32))
    """

    def __init__(self):
        conn = get_connection()
        self._client = conn.milvus_client

    # ------------------------------------------------------------------
    # Collection lifecycle
    # ------------------------------------------------------------------

    def create_collection(self, schema: CollectionSchema) -> bool:
        """Create a Milvus collection and build its vector indexes."""
        if self._client.has_collection(schema.name):
            return True

        # Build Milvus schema
        milvus_schema = self._client.create_schema(
            auto_id=any(f.auto_id for f in schema.fields),
            description=schema.description,
        )

        for field in schema.fields:
            kwargs: Dict[str, Any] = {}
            if field.is_primary:
                kwargs["is_primary"] = True
            if field.auto_id:
                kwargs["auto_id"] = True
            if field.dim is not None:
                kwargs["dim"] = field.dim
            if field.max_length is not None:
                kwargs["max_length"] = field.max_length
            if field.default_value is not None:
                kwargs["default_value"] = field.default_value

            milvus_schema.add_field(
                field_name=field.name,
                datatype=field.datatype,
                **kwargs,
            )

        self._client.create_collection(
            collection_name=schema.name,
            schema=milvus_schema,
        )

        # Build vector indexes
        for idx in schema.vector_indexes:
            self.create_index(schema.name, idx)

        self._client.load_collection(schema.name)
        return True

    def drop_collection(self, collection_name: str) -> bool:
        if self._client.has_collection(collection_name):
            self._client.drop_collection(collection_name)
        return True

    def has_collection(self, collection_name: str) -> bool:
        return self._client.has_collection(collection_name)

    # ------------------------------------------------------------------
    # Data operations
    # ------------------------------------------------------------------

    def insert(
        self,
        collection_name: str,
        data: List[Dict[str, Any]],
    ) -> List[int]:
        """Insert rows. Vector fields must be list[float], not np.ndarray."""
        # Convert any numpy arrays in the data to lists
        clean_data = []
        for row in data:
            clean_row = {}
            for k, v in row.items():
                if isinstance(v, np.ndarray):
                    clean_row[k] = v.tolist()
                else:
                    clean_row[k] = v
            clean_data.append(clean_row)

        result = self._client.insert(
            collection_name=collection_name,
            data=clean_data,
        )
        return result.get("ids", []) if result else []

    def search(
        self,
        collection_name: str,
        vector: np.ndarray,
        top_k: int = 10,
        filter_expr: Optional[str] = None,
        output_fields: Optional[List[str]] = None,
        metric_type: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """Vector similarity search with optional scalar filter."""
        self._client.load_collection(collection_name)

        # Ensure vector is a list of lists
        if vector.ndim == 1:
            search_vectors = [vector.tolist()]
        else:
            search_vectors = vector.tolist()

        kwargs: Dict[str, Any] = {
            "collection_name": collection_name,
            "data": search_vectors,
            "limit": top_k,
        }
        if filter_expr:
            kwargs["filter"] = filter_expr
        if output_fields:
            kwargs["output_fields"] = output_fields
        if metric_type:
            kwargs["metric_type"] = metric_type

        results = self._client.search(**kwargs)
        return results if results else []

    def delete(self, collection_name: str, filter_expr: str) -> int:
        """Delete entities matching a scalar filter expression."""
        result = self._client.delete(
            collection_name=collection_name,
            filter=filter_expr,
        )
        return result.get("delete_count", 0) if result else 0

    def get_by_id(
        self,
        collection_name: str,
        ids: List[int],
        output_fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve entities by primary key."""
        kwargs: Dict[str, Any] = {
            "collection_name": collection_name,
            "ids": ids,
        }
        if output_fields:
            kwargs["output_fields"] = output_fields

        results = self._client.get(**kwargs)
        return results if results else []

    # ------------------------------------------------------------------
    # Index management
    # ------------------------------------------------------------------

    def create_index(
        self,
        collection_name: str,
        index_params: VectorIndexParams,
    ) -> bool:
        """Build a vector index on a specific field."""
        params = self._client.prepare_index_params()
        params.add_index(
            field_name=index_params.field_name,
            index_type=index_params.index_type.value,
            metric_type=index_params.metric_type.value,
            params=index_params.params if index_params.params else {},
        )
        self._client.create_index(collection_name, params)
        return True

    def load_collection(self, collection_name: str) -> bool:
        self._client.load_collection(collection_name)
        return True
