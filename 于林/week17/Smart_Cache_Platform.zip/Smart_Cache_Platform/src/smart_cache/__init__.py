"""Smart Cache Platform — 向量检索与智能缓存服务平台.

A unified Python SDK for vector retrieval and intelligent caching,
built on Milvus Cloud + Redis with local BGE embeddings.

Quick Start:
    from smart_cache import (
        SemanticCache,
        EmbeddingCache,
        SemanticMessageHistory,
        SemanticRouter,
        HybridQuery,
        Filter,
        MilvusStore,
        LocalVectorizer,
        Route,
        CollectionSchema,
        FieldSchema,
        FieldDataType,
        VectorIndexParams,
        SimilarityMetric,
        IndexType,
    )
"""

# ── Embeddings ──────────────────────────────────────────────────────
from .embeddings.base import BaseVectorizer
from .embeddings.local import LocalVectorizer

# ── Vector Store ────────────────────────────────────────────────────
from .vector_store.base import BaseVectorStore
from .vector_store.milvus_store import MilvusStore
from .vector_store.schema import (
    FieldSchema,
    FieldDataType,
    CollectionSchema,
    VectorIndexParams,
    SimilarityMetric,
    IndexType,
)

# ── Query ───────────────────────────────────────────────────────────
from .query.filter_builder import Filter
from .query.hybrid import HybridQuery

# ── Cache ───────────────────────────────────────────────────────────
from .cache.semantic import SemanticCache
from .cache.embedding_cache import EmbeddingCache

# ── Message History ─────────────────────────────────────────────────
from .message_history.semantic_history import SemanticMessageHistory

# ── Router ──────────────────────────────────────────────────────────
from .router.semantic_router import SemanticRouter
from .schemas import Route, RouteResult

# ── Schemas ─────────────────────────────────────────────────────────
from .schemas import (
    Message,
    MessageRole,
    CacheEntry,
    CacheCheckResult,
    EmbeddingRecord,
)

__all__ = [
    # Embeddings
    "BaseVectorizer",
    "LocalVectorizer",
    # Vector Store
    "BaseVectorStore",
    "MilvusStore",
    "FieldSchema",
    "FieldDataType",
    "CollectionSchema",
    "VectorIndexParams",
    "SimilarityMetric",
    "IndexType",
    # Query
    "Filter",
    "HybridQuery",
    # Cache
    "SemanticCache",
    "EmbeddingCache",
    # Message History
    "SemanticMessageHistory",
    # Router
    "SemanticRouter",
    "Route",
    "RouteResult",
    # Schemas
    "Message",
    "MessageRole",
    "CacheEntry",
    "CacheCheckResult",
    "EmbeddingRecord",
]
