"""Chat orchestration service — cache → history → LLM fallback chain."""

from typing import Optional, Dict, Any
from dataclasses import dataclass, field

from ..cache.semantic import SemanticCache
from ..cache.embedding_cache import EmbeddingCache
from ..message_history.semantic_history import SemanticMessageHistory
from ..embeddings.local import LocalVectorizer
from .llm_client import LLMClient


@dataclass
class ChatResponse:
    """Result returned by ChatService."""
    response: str
    source: str           # "semantic_cache" | "history" | "llm"
    session_id: str
    embedding_cached: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


class ChatService:
    """Orchestrates the full chat pipeline.

    Pipeline:
    1. Check embedding cache → skip embedding if cached.
    2. Check semantic cache → return directly if similar question answered.
    3. Get relevant history as LLM context.
    4. Call LLM with history context.
    5. Store response in semantic cache + message history.

    Usage:
        service = ChatService()
        result = service.chat(session_id="user-123", message="今天天气怎么样？")
        print(result.response, result.source)
    """

    def __init__(self):
        self._llm = LLMClient()
        self._vectorizer = LocalVectorizer()

        # These are created per-call to get the right session_id
        # We keep a dict of per-session components
        self._semantic_caches: Dict[str, SemanticCache] = {}
        self._embedding_caches: Dict[str, EmbeddingCache] = {}
        self._histories: Dict[str, SemanticMessageHistory] = {}

        # Global embedding cache (shared across sessions)
        self._global_embed_cache = EmbeddingCache(name="global_embed", ttl=86400)

    def chat(self, session_id: str, message: str) -> ChatResponse:
        """Process a chat message through the full pipeline.

        Args:
            session_id: Unique session identifier.
            message: User's input message.

        Returns:
            ChatResponse with the answer and source metadata.
        """
        embedding_cached = False

        # ── Step 1: Embedding cache check ──
        cached_embed = self._global_embed_cache.get(message)
        if cached_embed is not None:
            embedding_cached = True

        # ── Step 2: Semantic cache check ──
        sc = self._get_semantic_cache(session_id)
        cache_result = sc.check(message)
        if cache_result is not None:
            # Also record this exchange in message history
            mh = self._get_history(session_id)
            mh.add_messages([
                {"role": "user", "content": message},
                {"role": "llm", "content": cache_result.response,
                 "metadata": {"source": "semantic_cache"}},
            ])
            return ChatResponse(
                response=cache_result.response,
                source="semantic_cache",
                session_id=session_id,
                embedding_cached=embedding_cached,
                metadata={"distance": cache_result.distance},
            )

        # ── Step 3: Get relevant history for LLM context ──
        mh = self._get_history(session_id)
        relevant_history = mh.get_relevant(message, top_k=10)
        recent_history = mh.get_recent(top_k=20)

        # Merge relevant + recent, deduplicate by content
        seen = set()
        context: list = []
        for msg in relevant_history + recent_history:
            key = (msg.get("role", ""), msg.get("content", ""))
            if key not in seen:
                seen.add(key)
                context.append(msg)

        # ── Step 4: Call LLM ──
        # Build a system prompt that summarizes relevant past context
        system_prompt = "你是一个有用的AI助手，请用简洁的中文回答用户的问题。"
        if relevant_history:
            history_text = "\n".join(
                f"[{m.get('role', '?')}]: {m.get('content', '')}"
                for m in relevant_history[:5]
            )
            system_prompt += f"\n\n以下是与此问题相关的历史对话，可以参考：\n{history_text}"

        llm_response = self._llm.chat(
            message=message,
            system_prompt=system_prompt,
            history=context,
        )

        # ── Step 5: Store results ──
        # Semantic cache
        sc.store(prompt=message, response=llm_response)

        # Embedding cache (cache the embedding for future lookups)
        embedding = self._vectorizer.embed(message)
        self._global_embed_cache.store(text=message, embedding=embedding)

        # Message history
        mh.add_messages([
            {"role": "user", "content": message},
            {"role": "llm", "content": llm_response, "metadata": {"source": "llm"}},
        ])

        return ChatResponse(
            response=llm_response,
            source="llm",
            session_id=session_id,
            embedding_cached=embedding_cached,
            metadata={"history_context_count": len(relevant_history)},
        )

    def get_history(self, session_id: str) -> list:
        """Return the conversation history for a session."""
        return self._get_history(session_id).get_history()

    def clear_history(self, session_id: str):
        """Clear conversation history and caches for a session."""
        self._get_history(session_id).clear_history()
        if session_id in self._semantic_caches:
            self._semantic_caches[session_id].clear()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_semantic_cache(self, session_id: str) -> SemanticCache:
        if session_id not in self._semantic_caches:
            self._semantic_caches[session_id] = SemanticCache(
                name=f"chat_{session_id}",
                ttl=86400,
                distance_threshold=0.1,
            )
        return self._semantic_caches[session_id]

    def _get_embedding_cache(self, session_id: str) -> EmbeddingCache:
        if session_id not in self._embedding_caches:
            self._embedding_caches[session_id] = EmbeddingCache(
                name=f"embed_{session_id}",
                ttl=86400,
            )
        return self._embedding_caches[session_id]

    def _get_history(self, session_id: str) -> SemanticMessageHistory:
        if session_id not in self._histories:
            self._histories[session_id] = SemanticMessageHistory(
                name=session_id,
                ttl=86400,
                distance_threshold=0.7,
            )
        return self._histories[session_id]
