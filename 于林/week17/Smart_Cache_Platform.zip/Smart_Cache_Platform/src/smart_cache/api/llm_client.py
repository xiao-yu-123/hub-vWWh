"""DashScope LLM client — OpenAI-compatible chat completion API."""

from typing import Optional, List, Dict
from openai import OpenAI

from ..core.config import get_config


class LLMClient:
    """Thin wrapper around DashScope's OpenAI-compatible chat API.

    Usage:
        client = LLMClient()
        response = client.chat("你好", context=[{"role": "user", "content": "之前的问题"}])
    """

    def __init__(self):
        config = get_config()
        self._client = OpenAI(
            base_url=config.base_url,
            api_key=config.api_key,
        )
        self._model = config.default_model

    def chat(
        self,
        message: str,
        system_prompt: Optional[str] = None,
        history: Optional[List[Dict[str, str]]] = None,
    ) -> str:
        """Send a chat message and return the LLM response.

        Args:
            message: The user's current message.
            system_prompt: Optional system-level instruction.
            history: Optional list of previous messages [{"role":..., "content":...}].

        Returns:
            The assistant's text response.
        """
        messages: List[Dict[str, str]] = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        else:
            messages.append({
                "role": "system",
                "content": "你是一个有用的AI助手，请用简洁的中文回答用户的问题。"
            })

        if history:
            # Filter to role + content only (LLM API format)
            for h in history:
                role = h.get("role", "user")
                content = h.get("content", "")
                # Map 'llm' role to 'assistant' for the API
                if role == "llm":
                    role = "assistant"
                messages.append({"role": role, "content": content})

        messages.append({"role": "user", "content": message})

        response = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            temperature=0.7,
            max_tokens=1024,
        )

        return response.choices[0].message.content or ""
