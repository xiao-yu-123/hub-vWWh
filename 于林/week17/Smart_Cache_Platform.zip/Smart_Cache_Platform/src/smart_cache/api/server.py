"""FastAPI server — REST API + chat frontend.

Start with:
    uvicorn smart_cache.api.server:app --reload --host 0.0.0.0 --port 8000
"""

from pathlib import Path
from typing import Optional
from pydantic import BaseModel

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware

from .chat_service import ChatService, ChatResponse

# ── App setup ───────────────────────────────────────────────────────

app = FastAPI(title="Smart Cache Platform", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Template directory
_TEMPLATES = Path(__file__).parent.parent / "templates"

# Single global chat service
chat_service = ChatService()

# ── Request / Response models ───────────────────────────────────────


class ChatRequest(BaseModel):
    session_id: str = "default"
    message: str


class ChatAPIResponse(BaseModel):
    response: str
    source: str
    session_id: str
    embedding_cached: bool = False
    metadata: dict = {}


class HistoryItem(BaseModel):
    role: str
    content: str
    metadata: Optional[dict] = None


# ── API Routes ──────────────────────────────────────────────────────


@app.post("/api/chat", response_model=ChatAPIResponse)
def chat(req: ChatRequest):
    """Send a message and get an AI response with source tracking."""
    result = chat_service.chat(
        session_id=req.session_id,
        message=req.message,
    )
    return ChatAPIResponse(
        response=result.response,
        source=result.source,
        session_id=result.session_id,
        embedding_cached=result.embedding_cached,
        metadata=result.metadata,
    )


@app.get("/api/history/{session_id}")
def get_history(session_id: str):
    """Return conversation history for a session."""
    history = chat_service.get_history(session_id)
    return {"session_id": session_id, "messages": history}


@app.delete("/api/history/{session_id}")
def clear_history(session_id: str):
    """Clear conversation history for a session."""
    chat_service.clear_history(session_id)
    return {"status": "ok", "session_id": session_id}


# ── Frontend ────────────────────────────────────────────────────────


@app.get("/", response_class=HTMLResponse)
def index():
    """Serve the chat UI."""
    html_path = _TEMPLATES / "index.html"
    if not html_path.exists():
        return HTMLResponse(
            "<h1>Frontend not found</h1><p>templates/index.html is missing.</p>",
            status_code=404,
        )
    return HTMLResponse(html_path.read_text(encoding="utf-8"))
