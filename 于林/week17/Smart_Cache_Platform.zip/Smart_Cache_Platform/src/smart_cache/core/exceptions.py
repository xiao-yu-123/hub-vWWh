class SmartCacheError(Exception):
    """Base exception for Smart Cache Platform."""
    pass


class ConnectionError(SmartCacheError):
    """Raised when Redis or Milvus connection fails."""
    pass


class EmbeddingError(SmartCacheError):
    """Raised when embedding computation fails."""
    pass


class StoreError(SmartCacheError):
    """Raised when storing data fails."""
    pass


class RetrievalError(SmartCacheError):
    """Raised when retrieving data fails."""
    pass


class ConfigError(SmartCacheError):
    """Raised when configuration is invalid or missing."""
    pass
