import json
import os
from typing import Optional
from .exceptions import ConfigError


class Config:
    """Global configuration loaded from system_config.json."""

    _instance: Optional["Config"] = None
    _data: dict = {}

    def __init__(self, config_path: Optional[str] = None):
        if config_path is None:
            # Default path: project_root/config/system_config.json
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            config_path = os.path.join(project_root, "config", "system_config.json")

        if not os.path.exists(config_path):
            raise ConfigError(f"Config file not found: {config_path}")

        with open(config_path, "r", encoding="utf-8") as f:
            self._data = json.load(f)

    @property
    def base_url(self) -> str:
        return self._data.get("base_url", "")

    @property
    def api_key(self) -> str:
        return self._data.get("api_key", "")

    @property
    def default_model(self) -> str:
        return self._data.get("default_model", "qwen-flash")

    @property
    def milvus_uri(self) -> str:
        return self._data.get("milvus_uri", "")

    @property
    def milvus_token(self) -> str:
        return self._data.get("milvus_token", "")

    @property
    def embedding_model_path(self) -> str:
        """Absolute path to the local embedding model directory."""
        rel_path = self._data.get("embedding_model", "models/BAAI/bge-small-zh-v1.5")
        if not os.path.isabs(rel_path):
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            rel_path = os.path.join(project_root, rel_path)
        return os.path.normpath(rel_path)

    @property
    def redis_host(self) -> str:
        return self._data.get("redis_host", "localhost")

    @property
    def redis_port(self) -> int:
        return self._data.get("redis_port", 6379)

    @property
    def redis_password(self) -> Optional[str]:
        return self._data.get("redis_password", None)

    @property
    def redis_db(self) -> int:
        return self._data.get("redis_db", 0)

    def get(self, key: str, default=None):
        return self._data.get(key, default)


# Global singleton
_config: Optional[Config] = None


def get_config(config_path: Optional[str] = None) -> Config:
    """Get or create the global Config singleton."""
    global _config
    if _config is None:
        _config = Config(config_path)
    return _config
