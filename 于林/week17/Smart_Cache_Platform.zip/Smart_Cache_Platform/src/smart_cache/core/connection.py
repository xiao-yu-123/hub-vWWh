import redis
from pymilvus import MilvusClient
from typing import Optional
from .config import get_config
from .exceptions import ConnectionError


class ConnectionManager:
    """Manages Redis and Milvus connections.

    Provides two Redis clients:
    - redis_client: auto-decodes responses as UTF-8 strings (for text data).
    - redis_client_raw: returns raw bytes (for binary data like numpy arrays).
    """

    _instance: Optional["ConnectionManager"] = None

    def __init__(self):
        self._redis: Optional[redis.Redis] = None
        self._redis_raw: Optional[redis.Redis] = None
        self._milvus: Optional[MilvusClient] = None
        self._config = get_config()

    def _build_redis(self, decode_responses: bool) -> redis.Redis:
        """Create a Redis connection with the given decode setting."""
        return redis.Redis(
            host=self._config.redis_host,
            port=self._config.redis_port,
            password=self._config.redis_password or None,
            db=self._config.redis_db,
            decode_responses=decode_responses,
        )

    @property
    def redis_client(self) -> redis.Redis:
        """Get or create Redis connection with UTF-8 auto-decoding.

        Use this for text-based data (JSON, strings, etc.).
        """
        if self._redis is None:
            try:
                self._redis = self._build_redis(decode_responses=True)
                self._redis.ping()
            except Exception as e:
                raise ConnectionError(f"Failed to connect to Redis: {e}")
        return self._redis

    @property
    def redis_client_raw(self) -> redis.Redis:
        """Get or create Redis connection that returns raw bytes.

        Use this for binary data (numpy arrays, serialized objects, etc.).
        """
        if self._redis_raw is None:
            try:
                self._redis_raw = self._build_redis(decode_responses=False)
                self._redis_raw.ping()
            except Exception as e:
                raise ConnectionError(f"Failed to connect to Redis (raw): {e}")
        return self._redis_raw

    @property
    def milvus_client(self) -> MilvusClient:
        """Get or create Milvus connection (lazy)."""
        if self._milvus is None:
            try:
                self._milvus = MilvusClient(
                    uri=self._config.milvus_uri,
                    token=self._config.milvus_token,
                )
            except Exception as e:
                raise ConnectionError(f"Failed to connect to Milvus: {e}")
        return self._milvus

    def close(self):
        """Close all connections."""
        if self._redis is not None:
            self._redis.close()
            self._redis = None
        if self._redis_raw is not None:
            self._redis_raw.close()
            self._redis_raw = None
        if self._milvus is not None:
            self._milvus.close()
            self._milvus = None


# Global singleton
_connection: Optional[ConnectionManager] = None


def get_connection() -> ConnectionManager:
    """Get or create the global ConnectionManager singleton."""
    global _connection
    if _connection is None:
        _connection = ConnectionManager()
    return _connection
