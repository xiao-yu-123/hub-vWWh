"""Pydantic data models for the Smart Cache Platform."""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum


# ========== 消息相关 ==========

class MessageRole(str, Enum):
    SYSTEM = "system"
    USER = "user"
    LLM = "llm"
    TOOL = "tool"


class Message(BaseModel):
    """A single conversation message."""
    role: MessageRole
    content: str
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


# ========== 语义缓存相关 ==========

class CacheEntry(BaseModel):
    """A prompt-response pair stored in the semantic cache."""
    prompt: str
    response: str
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


class CacheCheckResult(BaseModel):
    """Result returned when checking the semantic cache."""
    response: str
    prompt: str
    distance: float
    metadata: Optional[Dict[str, Any]] = None


# ========== 语义路由相关 ==========

class Route(BaseModel):
    """A named route with reference examples for intent classification."""
    name: str
    references: List[str]
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
    distance_threshold: float = 0.3


class RouteResult(BaseModel):
    """Result of routing a query to a route."""
    route_name: str
    distance: float
    metadata: Optional[Dict[str, Any]] = None
    matched_reference: str


# ========== Embedding 缓存相关 ==========

class EmbeddingRecord(BaseModel):
    """Metadata for a cached embedding."""
    text: str
    text_hash: str
    embedding_dim: int
