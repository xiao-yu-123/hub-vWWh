"""Milvus scalar filter expression builder.

Constructs filter expressions in Milvus expression syntax.
Supports chaining with & (AND) and | (OR) operators.

Usage:
    f = Filter()
    expr = (f.field("category") == "news") & (f.field("score") > 0.8)
    # → 'category == "news" and score > 0.8'
"""

from typing import Any, List, Optional


class _Condition:
    """A single or combined filter condition. Created by Filter.field()."""

    def __init__(self, expr: str):
        self._expr = expr

    def __and__(self, other: "_Condition") -> "_Condition":
        return _Condition(f"({self._expr}) and ({other._expr})")

    def __or__(self, other: "_Condition") -> "_Condition":
        return _Condition(f"({self._expr}) or ({other._expr})")

    def build(self) -> str:
        return self._expr

    def __repr__(self) -> str:
        return self._expr


class _Field:
    """Represents a field being filtered. Created by Filter.field()."""

    def __init__(self, name: str):
        self._name = name

    def _escape_value(self, value: Any) -> str:
        if isinstance(value, str):
            # Escape double quotes inside strings
            escaped = value.replace('"', '\\"')
            return f'"{escaped}"'
        if isinstance(value, bool):
            return str(value).lower()
        return str(value)

    def __eq__(self, value: Any) -> _Condition:  # type: ignore[override]
        return _Condition(f'{self._name} == {self._escape_value(value)}')

    def __ne__(self, value: Any) -> _Condition:  # type: ignore[override]
        return _Condition(f'{self._name} != {self._escape_value(value)}')

    def __gt__(self, value: Any) -> _Condition:
        return _Condition(f'{self._name} > {self._escape_value(value)}')

    def __ge__(self, value: Any) -> _Condition:
        return _Condition(f'{self._name} >= {self._escape_value(value)}')

    def __lt__(self, value: Any) -> _Condition:
        return _Condition(f'{self._name} < {self._escape_value(value)}')

    def __le__(self, value: Any) -> _Condition:
        return _Condition(f'{self._name} <= {self._escape_value(value)}')

    def in_(self, values: List[Any]) -> _Condition:
        """Match if the field value is in the given list."""
        escaped = [self._escape_value(v) for v in values]
        return _Condition(f'{self._name} in [{", ".join(escaped)}]')

    def like(self, pattern: str) -> _Condition:
        """Match with SQL-like pattern (uses % as wildcard)."""
        escaped = pattern.replace('"', '\\"')
        return _Condition(f'{self._name} like "{escaped}"')

    def between(self, low: Any, high: Any) -> _Condition:
        """Match if low <= field <= high."""
        return _Condition(
            f'{self._name} >= {self._escape_value(low)} and {self._name} <= {self._escape_value(high)}'
        )


class Filter:
    """Entry point for building filter expressions.

    Usage:
        f = Filter()
        expr = (f.field("category") == "news") & f.field("score").between(0.5, 1.0)
        expr2 = f.field("tags").in_(["AI", "LLM"])
        combined = expr & expr2
    """

    @staticmethod
    def field(name: str) -> _Field:
        """Start a filter on a specific field."""
        return _Field(name)

    @staticmethod
    def raw(expression: str) -> _Condition:
        """Use a raw Milvus expression string directly."""
        return _Condition(expression)

    @staticmethod
    def and_(*conditions: _Condition) -> _Condition:
        """Combine multiple conditions with AND."""
        if not conditions:
            return _Condition("")
        expr = " and ".join(f"({c._expr})" for c in conditions)
        return _Condition(expr)

    @staticmethod
    def or_(*conditions: _Condition) -> _Condition:
        """Combine multiple conditions with OR."""
        if not conditions:
            return _Condition("")
        expr = " or ".join(f"({c._expr})" for c in conditions)
        return _Condition(expr)
