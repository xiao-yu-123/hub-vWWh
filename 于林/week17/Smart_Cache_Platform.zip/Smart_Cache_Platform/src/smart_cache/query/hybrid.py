"""Hybrid Query Engine — combines vector similarity search with scalar filtering.

Usage:
    engine = HybridQuery(store)

    # Pure vector search
    results = engine.search(vector=embedding, collection="docs", top_k=10)

    # Vector + scalar filter
    f = Filter()
    results = engine.search(
        vector=embedding,
        collection="docs",
        top_k=10,
        filter_expr=(f.field("category") == "tech") & (f.field("score") > 0.5),
    )

    # With specific output fields
    results = engine.search(
        vector=embedding,
        collection="docs",
        top_k=5,
        output_fields=["title", "url", "category"],
    )
"""

from typing import Optional, List, Dict, Any
import numpy as np

from ..vector_store.base import BaseVectorStore
from ..vector_store.milvus_store import MilvusStore
from ..vector_store.schema import SimilarityMetric
from .filter_builder import _Condition


class HybridQuery:
    """Hybrid search combining vector similarity with scalar metadata filtering.

    Wraps a BaseVectorStore and provides a simplified search interface
    that accepts both a query vector and an optional filter expression.
    """

    def __init__(self, store: Optional[BaseVectorStore] = None):
        self._store = store or MilvusStore()

    @property
    def store(self) -> BaseVectorStore:
        return self._store

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        vector: np.ndarray,
        collection_name: str,
        top_k: int = 10,
        filter_expr: Optional[str] = None,
        output_fields: Optional[List[str]] = None,
        metric_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Execute a vector search with optional scalar filter.

        Args:
            vector: Query embedding, shape (dim,) or (1, dim).
            collection_name: Target Milvus collection.
            top_k: Number of results to return.
            filter_expr: Milvus filter expression string, or None.
            output_fields: Fields to include in result entities.
            metric_type: Similarity metric override.

        Returns:
            A flat list of result dicts: {"id": ..., "distance": ..., "entity": {...}}
        """
        results = self._store.search(
            collection_name=collection_name,
            vector=vector,
            top_k=top_k,
            filter_expr=filter_expr,
            output_fields=output_fields,
            metric_type=metric_type,
        )

        if results and len(results) > 0:
            return results[0]
        return []

    def search_with_filter(
        self,
        vector: np.ndarray,
        collection_name: str,
        condition: _Condition,
        top_k: int = 10,
        output_fields: Optional[List[str]] = None,
        metric_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search with a _Condition object (from filter_builder) instead of raw string.

        Args:
            vector: Query embedding.
            collection_name: Target Milvus collection.
            condition: A _Condition built with Filter.field().
            top_k: Number of results.
            output_fields: Fields to include.
            metric_type: Similarity metric override.

        Returns:
            A flat list of result dicts.
        """
        return self.search(
            vector=vector,
            collection_name=collection_name,
            top_k=top_k,
            filter_expr=condition.build(),
            output_fields=output_fields,
            metric_type=metric_type,
        )

    # ------------------------------------------------------------------
    # Convenience CRUD
    # ------------------------------------------------------------------

    def insert(
        self,
        collection_name: str,
        data: List[Dict[str, Any]],
    ) -> List[int]:
        """Insert rows into a collection."""
        return self._store.insert(collection_name, data)

    def delete_by_filter(
        self,
        collection_name: str,
        condition: _Condition,
    ) -> int:
        """Delete rows matching a filter condition."""
        return self._store.delete(collection_name, condition.build())

    def get_by_id(
        self,
        collection_name: str,
        ids: List[int],
        output_fields: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Retrieve rows by primary key."""
        return self._store.get_by_id(collection_name, ids, output_fields)
