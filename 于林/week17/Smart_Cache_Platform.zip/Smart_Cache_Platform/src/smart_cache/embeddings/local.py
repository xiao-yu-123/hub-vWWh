import numpy as np
from typing import List, Union, Optional
from sentence_transformers import SentenceTransformer
from .base import BaseVectorizer
from ..core.config import get_config
from ..core.exceptions import EmbeddingError


class LocalVectorizer(BaseVectorizer):
    """Vectorizer using a local SentenceTransformer model (BGE-small-zh-v1.5)."""

    def __init__(self, model_path: Optional[str] = None):
        if model_path is None:
            config = get_config()
            model_path = config.embedding_model_path

        try:
            self._model = SentenceTransformer(model_path)
        except Exception as e:
            raise EmbeddingError(f"Failed to load embedding model from {model_path}: {e}")

        # Prefer the new API name, fall back to the deprecated one
        if hasattr(self._model, "get_embedding_dimension"):
            self._dimension = self._model.get_embedding_dimension()
        else:
            self._dimension = self._model.get_sentence_embedding_dimension()

    def embed(self, text: Union[str, List[str]]) -> np.ndarray:
        """Convert text(s) to normalized embedding vectors.

        Args:
            text: A single string or a list of strings.

        Returns:
            A numpy array of shape (n_texts, embedding_dim) with float32 dtype.
        """
        try:
            if isinstance(text, str):
                text = [text]

            embeddings = self._model.encode(
                text,
                normalize_embeddings=True,
                convert_to_numpy=True,
            )

            if embeddings.ndim == 1:
                embeddings = embeddings.reshape(1, -1)

            return embeddings.astype(np.float32)

        except Exception as e:
            raise EmbeddingError(f"Embedding failed: {e}")

    def get_dimension(self) -> int:
        return self._dimension
