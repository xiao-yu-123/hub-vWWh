from abc import ABC, abstractmethod
from typing import List, Union
import numpy as np


class BaseVectorizer(ABC):
    """Abstract base class for all embedding vectorizers."""

    @abstractmethod
    def embed(self, text: Union[str, List[str]]) -> np.ndarray:
        """Convert text(s) to embedding vector(s).

        Args:
            text: A single string or a list of strings.

        Returns:
            A numpy array of shape (n_texts, embedding_dim).
        """
        pass

    @abstractmethod
    def get_dimension(self) -> int:
        """Return the embedding dimension."""
        pass
