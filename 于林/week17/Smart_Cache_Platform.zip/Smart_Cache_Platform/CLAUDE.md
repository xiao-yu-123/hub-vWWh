# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**Smart Cache Platform (向量检索与智能缓存服务平台)** — an internal AI infrastructure platform that wraps a company Redis cluster to provide:

1. **Unified Vector Data Management** — standardized index definition, data ingestion, vector search across multiple embedding algorithms and similarity metrics.
2. **Hybrid Query Engine** — combined vector similarity + metadata filtering + full-text keyword search.
3. **Intelligent Caching**:
   - **Semantic Cache** — cache LLM request/response pairs by semantic similarity to avoid redundant model calls.
   - **Embedding Cache** — cache text→vector embeddings to avoid redundant embedding computation.
4. **LLM Application Support Components** — conversation history management, semantic routing (intent recognition).

The project is inspired by [RedisVL](https://github.com/redis/redis-vl-python) and targets Redis as the primary backend, with Faiss as a secondary vector index option.

## Architecture (Planned)

The system is a Python SDK + service with these core modules:

- **Vector Store** — Index CRUD, vector insert/search, pluggable similarity metrics (cosine, L2, IP).
- **Hybrid Query** — Combine vector search with Redis search/query predicates and full-text filters.
- **Semantic Cache** — TTL-based cache keyed by embedding distance; `store(prompt, response)` / `check(prompt)` API.
- **Embedding Cache** — Wraps vectorizers (HuggingFace, OpenAI, etc.); transparently caches text→embedding results.
- **Semantic Message History** — Session-scoped conversation storage with semantic retrieval of past messages.
- **Semantic Router** — Intent classifier: define routes with reference examples, classify new queries by nearest-neighbor over embeddings, with caching.

## Key Design Decisions (from README)

- Backend: Redis cluster (already deployed at the company). Faiss as optional secondary index.
- Language: Python (SDK + service).
- Session isolation: cache entries are separated by `session_id`.
- Distance threshold: configurable per use case; determines what counts as a "semantic match."

## Current State

This repository is **greenfield** — only the README exists. No code, no build system, no dependency manifest. The first task is to bootstrap the Python project structure, choose dependencies (Redis client, embedding libraries, Faiss), and implement the modules described above.
