"""狼人杀集成测试 / 演示脚本。

支持三种步进模式，用于调试和观察游戏流程：
- step   : 每步询问——每个阶段推进后暂停
- day    : 每天询问——每个完整昼夜循环后暂停
- auto   : 自动运行——全程无暂停

用法：
    python main_demo.py                        # 默认 6 人标准局，每步询问
    python main_demo.py --mode day             # 每天询问
    python main_demo.py --mode auto            # 自动运行
    python main_demo.py --shuffle               # 随机打乱角色
    python main_demo.py --styles bold,cautious,balanced,random,balanced,balanced
"""

import argparse
import os
import sys
from typing import Optional, List

from engine.game_engine import GameEngine, GAME_CONFIGS
from schema.game_logger import GameLogger
from schema.game_record import GameRecord

PLAYER_STYLES = ["balanced", "bold", "cautious", "random"]


def _c(text: str, code: str) -> str:
    """终端着色。"""
    codes = {"r": "31", "g": "32", "y": "33", "b": "34", "c": "36", "w": "37", "B": "1"}
    return f"\033[{codes.get(code, '37')}m{text}\033[0m"


def _icon(role: str) -> str:
    return {"werewolf": "W", "seer": "S", "witch": "M", "hunter": "H", "villager": "V"}.get(role, "?")


def _role_name(role: str) -> str:
    return {"werewolf": "狼人", "seer": "预言家", "witch": "女巫",
            "hunter": "猎人", "villager": "村民"}.get(role, role)


class DemoRunner:
    """演示运行器。"""

    def __init__(self, config_name="standard_6", shuffle=False,
                 player_styles=None, mode="step"):
        self.mode = mode
        self.engine = GameEngine(config_name=config_name, shuffle=shuffle)
        os.makedirs("logs", exist_ok=True)
        self.logger = GameLogger(f"logs/demo_{self.engine.game_id}.log")
        self._styles = player_styles or []
        self._step_count = 0

    def run(self):
        self._header()
        self._players()

        while not self.engine.state.is_game_over:
            day = self.engine.state.day_number

            if self.mode == "step":
                self._wait("Enter 推进")
            elif self.mode == "day" and self.engine.current_phase == "night_wolf":
                if day > 1:
                    self._wait(f"第{day - 1}天结束，Enter 继续")

            result = self.engine.step()
            self._step_count += 1
            self._show(result)

            if result.is_game_over:
                break

            # day 模式：在 day_end 后暂停（第二天开始前）
            if self.mode == "day" and result.phase == "day_end":
                pass  # 下次循环到 night_wolf 时暂停

        self._game_over()

    def _header(self):
        n = len(self.engine.state.players)
        shuf = "打乱" if self.engine.config_name else "固定"
        print(f"\n{_c(f'狼人杀演示 - {self.engine.config_name} ({n}人)', 'B')}")
        print(f"模式: {self.mode}  |  ID: {self.engine.game_id}")
        print("-" * 60)

    def _players(self):
        print(f"\n{_c('角色分配:', 'B')}")
        for p in self.engine.state.players:
            side = "好人" if p.side == "good" else "狼人"
            style = f" [{self._styles[p.player_id]}]" if self._styles and p.player_id < len(self._styles) else ""
            print(f"  {_icon(p.role)} [{p.player_id}] {p.name} — {_c(p.role, 'y')} ({side}){style}")
        print()

    def _show(self, r):
        phase = r.phase
        day = r.day_number
        data = r.step_data

        labels = {
            "night_wolf": "狼人选杀目标", "night_seer": "预言家查验",
            "night_witch": "女巫用药", "night_result": "夜晚结算",
            "day_start": "天亮了", "speech": "玩家发言",
            "vote": "投票放逐", "day_end": "检查胜负",
        }
        print(f"\n{_c(f'[{self._step_count}] 第{day}天 {labels.get(phase, phase)}', 'c')}")

        # 阶段详情
        if phase == "night_wolf":
            t = data.get("final_target")
            print(f"  击杀目标: {_c(f'玩家{t}', 'r')}" if t is not None else "  空刀")
        elif phase == "night_seer":
            if data.get("target") is not None:
                r = "狼人" if data["result"] == "evil" else "好人"
                c = "r" if data["result"] == "evil" else "g"
                print(f"  查验玩家{data['target']}: {_c(r, c)}")
        elif phase == "night_witch":
            s, p = data.get("save"), data.get("poison")
            if s and s != "already_used":
                print(f"  {_c(f'解药救玩家{s}', 'g')}")
            elif s == "already_used":
                print(f"  解药已用")
            if p:
                print(f"  {_c(f'毒药毒玩家{p}', 'r')}")
        elif phase == "night_result":
            for d in data.get("deaths", []):
                cn = {"night_kill": "被狼刀", "poison": "被毒", "shoot": "被枪带"}
                pid = d["player_id"]
                cause = cn.get(d["cause"], d["cause"])
                print(f"  {_c(f'玩家{pid} {cause}', 'r')}")
            if not data.get("deaths"):
                print(f"  {_c('平安夜', 'g')}")
        elif phase == "speech":
            for s in data.get("speeches", []):
                txt = s["content"][:80]
                print(f"  [{s['player_id']}] {s['player_name']}: {txt}")
        elif phase == "vote":
            print(f"  投票: {data.get('tally', {})}")
            if data.get("eliminated") is not None:
                elim = data["eliminated"]
                print(f"  {_c(f'玩家{elim} 被放逐', 'r')}")

        # 存活/死亡
        alive = [p.player_id for p in self.engine.state.players if p.is_alive]
        dead = [p.player_id for p in self.engine.state.players if not p.is_alive]
        print(f"  存活: {_c(str(alive), 'g')}  死亡: {_c(str(dead) if dead else '无', 'r')}")

    def _game_over(self):
        print("\n" + "=" * 60)
        w = self.engine.state.winner
        print(_c("  好人阵营获胜!" if w == "good" else "  狼人阵营获胜!", "B"))
        print(f"  回合: {self._step_count}  |  天数: {self.engine.state.day_number}")
        print("\n  角色复盘:")
        for p in self.engine.state.players:
            st = _c("存活", "g") if p.is_alive else _c("死亡", "r")
            cause = ""
            for d in self.engine.state.deaths:
                if d.player_id == p.player_id:
                    cn = {"night_kill": "被狼刀", "vote": "被放逐",
                          "poison": "被毒", "shoot": "被枪带"}
                    cause = f" — {cn.get(d.cause, d.cause)}"
            print(f"    {_icon(p.role)} [{p.player_id}] {p.name} ({_role_name(p.role)}) [{st}]{cause}")

        # 保存
        os.makedirs("records", exist_ok=True)
        rec = GameRecord.from_game_state(self.engine.state, self.engine.game_id, self.engine.config_name)
        path = f"records/demo_{self.engine.game_id}.json"
        rec.to_json(path)
        print(f"\n  记录: {path}")
        print("=" * 60)
        self.logger.close()

    def _wait(self, prompt: str):
        try:
            input(f"\n{prompt}...")
        except EOFError:
            pass


def main():
    parser = argparse.ArgumentParser(description="狼人杀集成测试演示")
    parser.add_argument("--config", default="standard_6",
                        choices=list(GAME_CONFIGS.keys()))
    parser.add_argument("--mode", default="step",
                        choices=["step", "day", "auto"],
                        help="step=每步, day=每天, auto=自动")
    parser.add_argument("--shuffle", action="store_true",
                        help="随机打乱角色")
    parser.add_argument("--styles", type=str, default=None,
                        help="风格逗号分隔: bold,cautious,balanced,random")
    args = parser.parse_args()

    styles = None
    if args.styles:
        styles = [s.strip() for s in args.styles.split(",")]
        for s in styles:
            if s not in PLAYER_STYLES:
                print(f"无效风格: {s}，可选: {PLAYER_STYLES}")
                sys.exit(1)

    if args.mode == "auto":
        engine = GameEngine(config_name=args.config, shuffle=args.shuffle)
        n = 0
        while not engine.state.is_game_over:
            engine.step()
            n += 1
        w = engine.state.winner
        print(f"游戏结束: {'好人胜' if w == 'good' else '狼人胜'} "
              f"| 回合:{n} | 存活:{len(engine.state.alive_players)}")
        os.makedirs("records", exist_ok=True)
        GameRecord.from_game_state(engine.state, engine.game_id, engine.config_name) \
            .to_json(f"records/demo_{engine.game_id}.json")
    else:
        runner = DemoRunner(
            config_name=args.config, shuffle=args.shuffle,
            player_styles=styles, mode=args.mode,
        )
        runner.run()


if __name__ == "__main__":
    main()
