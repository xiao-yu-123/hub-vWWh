<template>
  <div>
    <header class="header">
      <h1>狼人杀 · AI 对战平台</h1>
      <span v-if="store.gameId" class="game-id">游戏 {{ store.gameId }}</span>
    </header>

    <GameSetup v-if="!store.gameId" />
    <template v-else>
      <GameBoard />
      <GameLog />
    </template>

    <!-- 错误提示 -->
    <div v-if="store.error" class="error-msg">{{ store.error }}</div>

    <!-- 胜负弹窗 -->
    <div v-if="store.isGameOver" class="overlay">
      <div class="overlay-box" :class="store.winner === 'good' ? 'win-good' : 'win-evil'">
        <h2 v-if="store.winner === 'good'">好人阵营获胜!</h2>
        <h2 v-else>狼人阵营获胜!</h2>
        <p style="margin:12px 0 20px;color:#9aaaba">
          游戏结束 — 第 {{ store.dayNumber }} 天
        </p>
        <button class="btn btn-primary" @click="store.reset()">开始新游戏</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useGameStore } from './store.js'
import GameSetup from './components/GameSetup.vue'
import GameBoard from './components/GameBoard.vue'
import GameLog from './components/GameLog.vue'

const store = useGameStore()
</script>
