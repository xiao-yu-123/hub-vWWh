const BASE = ''

async function request(url, options = {}) {
  const res = await fetch(`${BASE}${url}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || `HTTP ${res.status}`)
  }
  return res.json()
}

export const api = {
  health:    ()                => request('/'),
  configs:   ()                => request('/configs'),
  create:    (body)            => request('/games', { method: 'POST', body: JSON.stringify(body) }),
  step:      (id)              => request(`/games/${id}/step`, { method: 'POST' }),
  getGame:   (id)              => request(`/games/${id}`),
  listGames: ()                => request('/games'),
  deleteGame:(id)              => request(`/games/${id}`, { method: 'DELETE' }),
}
