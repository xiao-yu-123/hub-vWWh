<template>
  <div class="card" v-if="entries.length">
    <h3 style="margin-bottom:8px;font-size:14px;color:#9aaaba">游戏日志</h3>
    <div class="log-panel" ref="logRef">
      <div v-for="(entry, i) in entries" :key="i"
           class="log-entry"
           :class="entry.cls">
        <span v-if="entry.time" class="time">{{ entry.time }}</span>
        <span v-html="entry.text" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, watch, nextTick } from 'vue'
import { useGameStore } from '../store.js'

const store = useGameStore()
const logRef = ref(null)

const causeLabel = (c) => ({ night_kill: '被狼刀', vote: '被放逐', poison: '被毒', shoot: '被枪带' }[c] || c)

const entries = computed(() => {
  const result = []

  // 发言记录
  for (const d of store.dialogues) {
    result.push({
      cls: 'speech',
      text: `[${d.player_name || '玩家' + d.player_id}] ${d.content}`,
    })
  }

  // 死亡记录
  for (const d of store.deaths) {
    result.push({
      cls: 'death',
      text: `玩家${d.player_id} ${causeLabel(d.cause)}`,
    })
  }

  // 投票
  const sd = store.stepData
  if (sd?.tally && Object.keys(sd.tally).length) {
    result.push({
      cls: 'vote',
      text: `投票结果: ${JSON.stringify(sd.tally)}` +
           (sd.eliminated != null ? ` → 放逐玩家${sd.eliminated}` : ''),
    })
  }

  // 阶段切换
  if (store.phase) {
    const labels = {
      night_wolf: '狼人选杀', night_seer: '预言家查验', night_witch: '女巫用药',
      night_result: '夜晚结算', day_start: '天亮了', speech: '发言',
      vote: '投票放逐', day_end: '检查胜负',
    }
    result.push({
      cls: 'phase',
      text: `第${store.dayNumber}天 — ${labels[store.phase] || store.phase}`,
    })
  }

  return result
})

// 自动滚动到底部
watch(() => entries.value.length, () => {
  nextTick(() => {
    if (logRef.value) logRef.value.scrollTop = logRef.value.scrollHeight
  })
})
</script>
