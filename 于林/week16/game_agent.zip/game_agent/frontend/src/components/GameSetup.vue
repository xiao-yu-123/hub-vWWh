<template>
  <div class="setup-form">
    <div class="card">
      <h2 style="margin-bottom:16px;color:#e8c34b">创建新游戏</h2>

      <label>角色配置</label>
      <select v-model="configName">
        <option v-for="cfg in configs" :key="cfg.name" :value="cfg.name">
          {{ cfg.name }} — {{ cfg.description }}
        </option>
      </select>

      <label>玩家名称（逗号分隔，留空自动生成）</label>
      <input v-model="namesInput" placeholder="如: 狼1,狼2,预言,女巫,猎人,村民" />

      <label style="display:flex;align-items:center;gap:8px">
        <input type="checkbox" v-model="shuffle" />
        随机打乱角色分配
      </label>

      <div style="margin-top:16px">
        <button class="btn btn-primary" @click="create" :disabled="creating"
                style="width:100%;padding:12px">
          {{ creating ? '创建中...' : '创建游戏' }}
        </button>
      </div>
    </div>

    <!-- 可用配置说明 -->
    <div v-if="loadedConfigs.length" class="card" style="margin-top:16px">
      <h3 style="margin-bottom:8px;font-size:14px;color:#9aaaba">可用配置</h3>
      <div v-for="cfg in loadedConfigs" :key="cfg.name"
           style="font-size:13px;margin-bottom:4px;color:#7a8a9a">
        <strong>{{ cfg.name }}</strong> ({{ cfg.player_count }}人):
        <span v-for="(r, i) in cfg.roles" :key="i">
          {{ r.count }}×{{ r.role }}<span v-if="i < cfg.roles.length - 1">, </span>
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useGameStore } from '../store.js'
import { api } from '../api.js'

const store = useGameStore()
const configName = ref('standard_6')
const namesInput = ref('')
const shuffle = ref(true)
const creating = ref(false)
const loadedConfigs = ref([])

onMounted(async () => {
  try { loadedConfigs.value = await api.configs() } catch {}
})

async function create() {
  creating.value = true
  try {
    const names = namesInput.value
      ? namesInput.value.split(',').map(s => s.trim()).filter(Boolean)
      : null
    await store.createGame(configName.value, names, shuffle.value)
    await store.refreshGame()
  } catch (e) {
    store.error = e.message
  } finally {
    creating.value = false
  }
}
</script>
