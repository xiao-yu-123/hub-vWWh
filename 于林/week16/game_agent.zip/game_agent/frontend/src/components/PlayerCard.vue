<template>
  <div class="player-card" :class="player.is_alive ? 'alive' : 'dead'">
    <div class="avatar" :class="player.side || 'good'">
      {{ icon }}
    </div>
    <div class="name">{{ player.name }}</div>
    <div class="role" v-if="player.role">{{ roleName }}</div>
    <div class="role" v-else style="color:#5a6a7a">未知</div>
    <div class="status">
      <span v-if="player.is_alive" class="alive-dot">存活</span>
      <span v-else class="dead-dot">死亡</span>
      <span v-if="player.player_id === sheriffId" style="margin-left:4px;font-size:10px">
        ⭐ 警长
      </span>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  player: { type: Object, required: true },
  sheriffId: { type: Number, default: null },
})

const icon = computed(() => {
  const icons = { werewolf: '🐺', seer: '🔮', witch: '🧪', hunter: '🏹', villager: '👤' }
  return icons[props.player.role] || '❓'
})

const roleName = computed(() => {
  const names = { werewolf: '狼人', seer: '预言家', witch: '女巫', hunter: '猎人', villager: '村民' }
  return names[props.player.role] || props.player.role
})
</script>
