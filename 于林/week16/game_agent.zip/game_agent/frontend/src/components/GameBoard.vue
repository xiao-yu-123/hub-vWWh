<template>
  <div>
    <!-- 信息栏 -->
    <div class="info-bar">
      <span>配置: {{ store.configName }}</span>
      <span>第 {{ store.dayNumber }} 天</span>
      <span>阶段: {{ phaseLabel }}</span>
      <span>存活: {{ store.alivePlayers.length }} / {{ store.players.length }}</span>
    </div>

    <!-- 阶段指示器 -->
    <div class="phase-bar">
      <span v-for="(name, idx) in store.phaseNames" :key="name"
            class="phase-dot"
            :class="{
              active: idx === store.phaseIndex,
              done: idx < store.phaseIndex
            }"
            :title="phaseLabelMap[name]">
        {{ phaseShort[name] }}
      </span>
    </div>

    <!-- 控制按钮 -->
    <div class="controls">
      <button class="btn btn-primary" @click="doStep" :disabled="store.isGameOver">
        单步执行
      </button>
      <button v-if="!autoRunning" class="btn btn-success" @click="startAuto"
              :disabled="store.isGameOver">
        自动推进
      </button>
      <button v-else class="btn btn-danger" @click="stopAuto">
        暂停
      </button>
      <button class="btn btn-outline btn-sm" @click="doRefresh">
        刷新
      </button>
    </div>

    <!-- 本阶段结果 -->
    <div v-if="stepSummary" class="card" style="font-size:13px;margin:10px 0">
      <strong style="color:#e8c34b">{{ phaseLabel }} 结果:</strong>
      <span v-html="stepSummary" />
    </div>

    <!-- 玩家面板 -->
    <div class="card">
      <h3 style="margin-bottom:10px;font-size:14px;color:#9aaaba">
        存活玩家 ({{ store.alivePlayers.length }})
      </h3>
      <div class="grid-6">
        <PlayerCard v-for="p in store.alivePlayers" :key="p.player_id"
                    :player="p" :sheriff-id="store.sheriffId" />
      </div>
    </div>

    <div v-if="store.deadPlayers.length" class="card">
      <h3 style="margin-bottom:10px;font-size:14px;color:#5a6a7a">
        死亡玩家 ({{ store.deadPlayers.length }})
      </h3>
      <div class="grid-6">
        <PlayerCard v-for="p in store.deadPlayers" :key="p.player_id"
                    :player="p" :sheriff-id="store.sheriffId" />
      </div>
    </div>

    <!-- 死亡记录 -->
    <div v-if="store.deaths.length" class="card">
      <h3 style="margin-bottom:6px;font-size:14px;color:#ef4444">死亡记录</h3>
      <div v-for="(d, i) in store.deaths" :key="i"
           style="font-size:13px;margin:2px 0;color:#9aaaba">
        <span style="color:#ef4444">玩家{{ d.player_id }}</span>
        因
        <span style="color:#fca5a5">{{ causeLabel(d.cause) }}</span>
        死亡 ({{ d.phase }})
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useGameStore } from '../store.js'
import PlayerCard from './PlayerCard.vue'

const store = useGameStore()
const autoRunning = ref(false)

const phaseLabelMap = {
  night_wolf: '狼人选杀', night_seer: '预言家查验', night_witch: '女巫用药',
  night_result: '夜晚结算', day_start: '天亮了', speech: '发言',
  vote: '投票放逐', day_end: '检查胜负',
}
const phaseShort = {
  night_wolf: '狼', night_seer: '预', night_witch: '巫',
  night_result: '结', day_start: '晨', speech: '言', vote: '投', day_end: '终',
}

const phaseLabel = computed(() => phaseLabelMap[store.phase] || store.phase)

const causeLabel = (c) => ({ night_kill: '被狼刀', vote: '被放逐', poison: '被毒', shoot: '被枪带' }[c] || c)

const stepSummary = computed(() => {
  const d = store.stepData
  if (!d || !Object.keys(d).length) return ''
  const parts = []
  if (d.final_target != null) parts.push(`击杀目标: 玩家${d.final_target}`)
  if (d.target != null && d.result) parts.push(`查验玩家${d.target}: <span style="color:${d.result==='evil'?'#f87171':'#4ade80'}">${d.result==='evil'?'狼人':'好人'}</span>`)
  if (d.save && d.save !== 'already_used') parts.push(`解药救玩家${d.save}`)
  if (d.poison) parts.push(`毒药毒玩家${d.poison}`)
  if (d.eliminated != null) parts.push(`被放逐: 玩家${d.eliminated}`)
  if (d.tally) parts.push(`投票: ${JSON.stringify(d.tally)}`)
  if (d.deaths?.length) {
    d.deaths.forEach(dd => parts.push(`死亡: 玩家${dd.player_id} (${causeLabel(dd.cause)})`))
  }
  if (d.speeches?.length) parts.push(`${d.speeches.length} 条发言`)
  if (d.last_night_deaths?.length) {
    parts.push(`昨晚死亡: ${d.last_night_deaths.map(x => x.player_id).join(', ')}`)
  }
  return parts.join(' | ')
})

async function doStep() {
  await store.stepGame()
}

async function doRefresh() {
  await store.refreshGame()
}

function startAuto() {
  autoRunning.value = true
  store.startAuto(2000)
}

function stopAuto() {
  autoRunning.value = false
  store.stopAuto()
}
</script>
