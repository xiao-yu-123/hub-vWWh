import { defineStore } from 'pinia'
import { api } from './api.js'

export const useGameStore = defineStore('game', {
  state: () => ({
    gameId: null,
    phase: '',
    phaseIndex: 0,
    dayNumber: 1,
    players: [],
    dialogues: [],
    deaths: [],
    stepData: {},
    sheriffId: null,
    isGameOver: false,
    winner: null,
    configName: '',
    eventLog: [],
    autoTimer: null,
    error: null,
  }),

  getters: {
    alivePlayers: (s) => s.players.filter(p => p.is_alive),
    deadPlayers:  (s) => s.players.filter(p => !p.is_alive),
    phaseNames:   () => ['night_wolf','night_seer','night_witch','night_result',
                         'day_start','speech','vote','day_end'],
  },

  actions: {
    async createGame(config_name = 'standard_6', player_names = null, shuffle = true) {
      this.error = null
      const data = await api.create({ config_name, player_names, shuffle })
      this.gameId = data.game_id
      this.phase = data.phase
      this.dayNumber = data.day_number
      this.isGameOver = data.is_game_over
      this.winner = data.winner
      this.configName = data.config_name
      return data
    },

    async stepGame() {
      if (!this.gameId || this.isGameOver) return
      this.error = null
      try {
        const data = await api.step(this.gameId)
        this.phase = data.phase
        this.phaseIndex = data.phase_index
        this.dayNumber = data.day_number
        this.stepData = data.step_data || {}
        this.players = data.players || []
        this.dialogues = data.dialogues || []
        this.deaths = data.deaths || []
        this.isGameOver = data.is_game_over
        this.winner = data.winner
        this.sheriffId = data.sheriff_id || null
      } catch (e) {
        this.error = e.message
      }
    },

    async refreshGame() {
      if (!this.gameId) return
      this.error = null
      try {
        const data = await api.getGame(this.gameId)
        this.phase = data.phase
        this.phaseIndex = data.phase_index
        this.dayNumber = data.day_number
        this.players = data.players
        this.dialogues = data.dialogues || []
        this.deaths = data.deaths || []
        this.isGameOver = data.is_game_over
        this.winner = data.winner
        this.sheriffId = data.sheriff_id || null
        this.configName = data.config_name
        this.eventLog = data.event_log || []
      } catch (e) {
        this.error = e.message
      }
    },

    startAuto(intervalMs = 2000) {
      if (this.autoTimer) return
      this.autoTimer = setInterval(() => {
        if (this.isGameOver) {
          this.stopAuto()
          return
        }
        this.stepGame()
      }, intervalMs)
    },

    stopAuto() {
      if (this.autoTimer) {
        clearInterval(this.autoTimer)
        this.autoTimer = null
      }
    },

    reset() {
      this.stopAuto()
      this.$reset()
    },
  },
})
