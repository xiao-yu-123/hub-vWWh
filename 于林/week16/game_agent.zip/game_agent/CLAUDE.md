# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A multi-agent Werewolf (狼人杀) game platform powered by LLMs. Each AI agent plays as an independent player with private context, making autonomous decisions during night actions, daytime debate, and voting. The system enforces strict information isolation so agents cannot "cheat" by seeing other players' hidden roles.

## Tech Stack

- **Backend**: Python, FastAPI, uvicorn
- **Frontend**: Vue 3 + Vite
- **Agent framework**: LangGraph, AutoGen, or custom multi-agent orchestration (TBD)

## Intended Architecture

### Game Engine (Judge/God)

The core state machine that drives the game loop. It must:

- Enforce strict role-based information isolation — werewolves see teammates but not roles; villagers see nothing. Each agent gets a private context and independent memory.
- Cycle through phases in order: `night_wolf` → `night_seer` → `night_witch` → `night_result` → `day_start` → `speech` → `vote` → `day_end` → (loop or game over).
- Support sheriff election on day 1 (players announce candidacy, non-candidates vote, sheriff gets 1.5 votes and decides speaking order).
- Collect structured JSON decisions from each agent at their turn.
- Determine win conditions: good side wins by eliminating all wolves; wolf side wins by taking out all seers+witches+hunters OR all villagers (屠边).

### Roles

| Role | Side | Night Action |
|------|------|--------------|
| Werewolf (狼人) | Evil | Collective kill vote via private chat |
| Seer (预言家) | Good/God | Check one player → returns `good` or `evil` |
| Witch (女巫) | Good/God | One antidote (revive night kill), one poison (kill a player); single-use each, cannot save self, cannot use both in one night |
| Hunter (猎人) | Good/God | On death by kill or vote, can shoot one player; death by poison negates this |
| Villager (村民) | Good/Civilian | No night action |

### API Endpoints (FastAPI, planned)

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/` | Health check |
| `POST` | `/games` | Create and initialize a new game |
| `POST` | `/games/{id}/step` | Advance one phase |
| `GET` | `/games/{id}` | Get full game state |
| `GET` | `/games` | List active games |
| `DELETE` | `/games/{id}` | Delete a game |
| `GET` | `/configs` | List available role configurations |

Config presets: `standard_6`, `simple_4`, `big_9`.

### Frontend (Vue 3, planned)

Spectator dashboard with: game creation form, auto/step/manual phase advancement controls, player cards grid (role, side, alive/dead), real-time action log, winner overlay. Frontend proxies `/games` and `/configs` to the backend via Vite.

## Planned Directory Layout

```
/
├── api/                # FastAPI server
│   └── server.py       # uvicorn entry point, HTTP endpoints
├── engine/             # Game engine — state machine, phase transitions, win detection
├── agents/             # Agent implementations — LLM-backed players with private context
├── frontend/           # Vue 3 + Vite spectator UI
├── configs/            # Role configuration presets (standard_6, simple_4, big_9)
├── roles/              # Role definitions (Werewolf, Seer, Witch, Hunter, Villager)
├── tests/              # Unit tests
├── requirements.txt
└── README.md
```

## Running (once implemented)

```bash
# Backend
pip install -r requirements.txt
uvicorn api.server:app --reload --host 0.0.0.0 --port 8000

# Frontend
cd frontend && npm install && npm run dev
```

Swagger docs at http://localhost:8000/docs; frontend at http://localhost:5173.
