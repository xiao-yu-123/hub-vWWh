"""FastAPI Server — 狼人杀游戏 HTTP API。

启动方式：
    uvicorn api.server:app --reload --host 0.0.0.0 --port 8000
    http://localhost:8000/docs 查看 Swagger 文档。
"""

import random
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from api.models import (
    CreateGameRequest, GameSummary, StepResult, GameStateResponse,
    ConfigInfo, HealthResponse, DeleteResponse, ErrorResponse,
    PlayerInfo, PlayerInfoAdmin, DialogueEntry, DeathEntry,
)
from roles import create_role, ROLE_REGISTRY
from engine.decision_engine import DecisionEngine

# ---- 游戏配置预设 ----

GAME_CONFIGS: Dict[str, dict] = {
    "standard_6": {
        "name": "standard_6",
        "description": "标准 6 人局：2狼 1预言家 1女巫 1猎人 1村民",
        "player_count": 6,
        "roles": [
            {"role": "werewolf", "count": 2},
            {"role": "seer", "count": 1},
            {"role": "witch", "count": 1},
            {"role": "hunter", "count": 1},
            {"role": "villager", "count": 1},
        ],
    },
    "simple_4": {
        "name": "simple_4",
        "description": "简易 4 人局：2狼 1预言家 1村民",
        "player_count": 4,
        "roles": [
            {"role": "werewolf", "count": 2},
            {"role": "seer", "count": 1},
            {"role": "villager", "count": 1},
        ],
    },
    "big_9": {
        "name": "big_9",
        "description": "标准 9 人局：3狼 1预言家 1女巫 1猎人 3村民",
        "player_count": 9,
        "roles": [
            {"role": "werewolf", "count": 3},
            {"role": "seer", "count": 1},
            {"role": "witch", "count": 1},
            {"role": "hunter", "count": 1},
            {"role": "villager", "count": 3},
        ],
    },
}

PHASES = [
    "night_wolf",
    "night_seer",
    "night_witch",
    "night_result",
    "day_start",
    "speech",
    "vote",
    "day_end",
]

# ---- FastAPI App ----

app = FastAPI(
    title="狼人杀多智能体平台",
    description="LLM 驱动的狼人杀对局 HTTP API",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- GameSession — 单个对局实例 ----

class GameSession:
    """封装一局狼人杀的全部状态和阶段流转。

    当前为简化默认实现：各阶段使用默认决策。
    后续接入 Agent 层和完整引擎后替换内部逻辑。
    """

    def __init__(self, config_name: str, player_names: Optional[List[str]],
                 shuffle: bool, player_styles: Optional[Dict[str, str]]):
        import random

        cfg = GAME_CONFIGS[config_name]
        self.config_name = config_name
        self.game_id = uuid.uuid4().hex[:8]
        self.phase_index = 0
        self.day_number = 1
        self.round_number = 0
        self.is_game_over = False
        self.winner: Optional[str] = None
        self.created_at = datetime.now().isoformat()
        self.shuffle = shuffle
        self.player_styles = player_styles or {}
        self.decision_engine = DecisionEngine(player_styles=self.player_styles)

        # 展开角色列表
        role_list = []
        for entry in cfg["roles"]:
            role_list.extend([entry["role"]] * entry["count"])

        # 打乱
        if shuffle:
            random.shuffle(role_list)

        # 生成玩家名
        if not player_names:
            player_names = [f"玩家{i}" for i in range(1, len(role_list) + 1)]

        # 构建 Player 数据结构
        self.players: List[dict] = []
        for i, (name, role_name) in enumerate(zip(player_names, role_list)):
            self.players.append({
                "player_id": i,
                "name": name,
                "role": role_name,
                "side": ROLE_REGISTRY[role_name](player_id=0).camp.value,
                "is_alive": True,
                "can_act": True,
                "check_results": {},
            })

        # 游戏运行状态
        self.sheriff_id: Optional[int] = None
        self.witch_antidote_used = False
        self.witch_poison_used = False
        self.witch_antidote_target: Optional[int] = None
        self.witch_poison_target: Optional[int] = None
        self.night_kill_target: Optional[int] = None
        self.hunter_shoot_target: Optional[int] = None
        self.dialogues: List[dict] = []
        self.deaths: List[dict] = []
        self.event_log: List[dict] = []

    # ---- helpers ----

    @property
    def phase(self) -> str:
        return PHASES[self.phase_index] if self.phase_index < len(PHASES) else "game_over"

    @property
    def alive_players(self) -> List[dict]:
        return [p for p in self.players if p["is_alive"]]

    @property
    def alive_wolf_ids(self) -> List[int]:
        return [p["player_id"] for p in self.alive_players if p["role"] == "werewolf"]

    @property
    def alive_god_ids(self) -> List[int]:
        return [p["player_id"] for p in self.alive_players
                if p["role"] in ("seer", "witch", "hunter")]

    @property
    def alive_villager_ids(self) -> List[int]:
        return [p["player_id"] for p in self.alive_players if p["role"] == "villager"]

    @property
    def alive_player_ids(self) -> List[int]:
        return [p["player_id"] for p in self.alive_players]

    def get_player(self, pid: int) -> Optional[dict]:
        for p in self.players:
            if p["player_id"] == pid:
                return p
        return None

    def add_dialogue(self, pid: int, content: str):
        p = self.get_player(pid)
        entry = {
            "player_id": pid,
            "player_name": p["name"] if p else f"玩家{pid}",
            "phase": self.phase,
            "content": content,
        }
        self.dialogues.append(entry)

    def add_death(self, pid: int, cause: str):
        p = self.get_player(pid)
        if p:
            p["is_alive"] = False
            p["can_act"] = False
        entry = {
            "player_id": pid,
            "player_name": p["name"] if p else f"玩家{pid}",
            "cause": cause,
            "phase": self.phase,
        }
        self.deaths.append(entry)

    def add_event(self, event_type: str, data: dict, public: bool = True):
        self.event_log.append({
            "phase": self.phase,
            "day": self.day_number,
            "event_type": event_type,
            "data": data,
            "public": public,
        })

    def check_win(self) -> Optional[str]:
        """屠边规则胜负判定。"""
        if not self.alive_wolf_ids:
            return "good"
        if not self.alive_god_ids or not self.alive_villager_ids:
            return "evil"
        return None

    # ---- 阶段执行 ----

    def step(self) -> dict:
        """推进一个阶段，返回 step_data。"""
        if self.is_game_over:
            return {}

        phase_name = self.phase
        handler = {
            "night_wolf": self._do_night_wolf,
            "night_seer": self._do_night_seer,
            "night_witch": self._do_night_witch,
            "night_result": self._do_night_result,
            "day_start": self._do_day_start,
            "speech": self._do_speech,
            "vote": self._do_vote,
            "day_end": self._do_day_end,
        }

        step_data = handler.get(phase_name, lambda: {})()
        self.round_number += 1

        # 推进到下一阶段
        self.phase_index += 1
        if self.phase_index >= len(PHASES):
            self.phase_index = 0
            self.day_number += 1

        return step_data

    def _do_night_wolf(self) -> dict:
        """狼人选击杀目标（DE 按风格智能选择）。"""
        targets = [p for p in self.alive_players if p["role"] != "werewolf"]
        smart_target = self.decision_engine.wolf_kill_target(self.alive_players, self.alive_wolf_ids)
        valid_ids = [p["player_id"] for p in targets]
        self.night_kill_target = smart_target if smart_target in valid_ids else (targets[0]["player_id"] if targets else None)
        wolf_votes = [{"player_id": wid, "target": self.night_kill_target}
                      for wid in self.alive_wolf_ids] if self.night_kill_target else []
        self.add_event("wolf_kill", {"wolf_ids": self.alive_wolf_ids,
                                     "target": self.night_kill_target}, public=False)
        return {"wolf_votes": wolf_votes, "final_target": self.night_kill_target}

    def _do_night_seer(self) -> dict:
        """预言家查验（DE 按风格智能选择目标）。"""
        seers = [p for p in self.alive_players if p["role"] == "seer"]
        if not seers:
            return {"check_result": None}
        seer = seers[0]
        checked = set(seer.get("check_results", {}).keys())
        smart_target = self.decision_engine.seer_check_target(
            self.alive_players, seer["player_id"], checked)
        valid_ids = [p["player_id"] for p in self.alive_players
                     if p["player_id"] != seer["player_id"]
                     and p["player_id"] not in checked]
        target = smart_target if smart_target in valid_ids else (valid_ids[0] if valid_ids else None)
        if target is not None:
            t = self.get_player(target)
            result = "evil" if t and t["role"] == "werewolf" else "good"
            seer["check_results"][target] = result
            self.add_event("seer_check", {"seer_id": seer["player_id"],
                                          "target": target, "result": result}, public=False)
            return {"seer_id": seer["player_id"], "target": target, "result": result}
        return {"check_result": None}

    def _do_night_witch(self) -> dict:
        """女巫用药（DE 按风格决定是否救人/毒人）。"""
        witches = [p for p in self.alive_players if p["role"] == "witch"]
        if not witches:
            return {"action": None}
        witch = witches[0]
        style = self.decision_engine.style_of(witch["player_id"])
        data = {"witch_id": witch["player_id"]}

        # 解药 — DE 按风格决定
        should_save = self.decision_engine.witch_should_save(
            self.night_kill_target, witch["player_id"], style)
        if (should_save and self.night_kill_target is not None
                and not self.witch_antidote_used
                and self.night_kill_target != witch["player_id"]):
            self.witch_antidote_used = True
            self.witch_antidote_target = self.night_kill_target
            data["save"] = self.night_kill_target
            self.add_event("witch_save", {"target": self.night_kill_target}, public=False)
        else:
            data["save"] = None

        # 毒药 — DE 按风格决定
        smart_poison = self.decision_engine.witch_poison_target(
            self.alive_players, witch["player_id"], style)
        if smart_poison is not None and not self.witch_poison_used:
            self.witch_poison_used = True
            self.witch_poison_target = smart_poison
            data["poison"] = smart_poison
            self.add_event("witch_poison", {"target": smart_poison}, public=False)
        else:
            data["poison"] = None

        if self.witch_antidote_target is not None and data.get("save") is None:
            data["save"] = "already_used"

        return data

    def _do_night_result(self) -> dict:
        """夜晚结算：处理死亡 + 猎人开枪。"""
        deaths_today = []

        # 狼刀结算：如果被女巫救了则不死
        if self.night_kill_target is not None:
            if self.witch_antidote_target == self.night_kill_target:
                # 被救活了
                self.add_event("night_kill_saved",
                               {"target": self.night_kill_target}, public=True)
            else:
                self.add_death(self.night_kill_target, "night_kill")
                deaths_today.append(
                    {"player_id": self.night_kill_target, "cause": "night_kill"})

                # 检查死者是否为猎人，触发开枪
                killed = self.get_player(self.night_kill_target)
                if killed and killed["role"] == "hunter":
                    shoot = self._hunter_shoot(self.night_kill_target, "night_kill")
                    if shoot:
                        deaths_today.append(shoot)

        # 毒药结算
        if self.witch_poison_target is not None:
            self.add_death(self.witch_poison_target, "poison")
            deaths_today.append({"player_id": self.witch_poison_target, "cause": "poison"})

        self.add_event("night_deaths", {"deaths": deaths_today}, public=True)
        return {"deaths": deaths_today}

    def _hunter_shoot(self, hunter_id: int, cause: str) -> Optional[dict]:
        """猎人开枪（默认选第一个存活玩家）。"""
        if cause == "poison":
            return None  # 闷枪
        targets = [p for p in self.alive_players
                   if p["player_id"] != hunter_id and p["is_alive"]]
        if not targets:
            return None
        target = targets[0]["player_id"]
        self.add_death(target, "shoot")
        self.add_event("hunter_shoot", {"hunter_id": hunter_id, "target": target},
                       public=True)
        return {"player_id": target, "cause": "shoot"}

    def _do_day_start(self) -> dict:
        """白天开始：公布昨晚信息。"""
        deaths_last_night = [d for d in self.deaths
                             if d["phase"] == "night_result"]
        return {"announced": True, "last_night_deaths": deaths_last_night}

    def _do_speech(self) -> dict:
        """发言阶段（DE 生成角色化发言）。"""
        speeches = []
        for p in self.alive_players:
            check_results = p.get("check_results", {})
            known_wolves = [w for w in self.alive_wolf_ids if w != p["player_id"]] if p["role"] == "werewolf" else []
            content = self.decision_engine.generate_speech(
                p, self.day_number, check_results, known_wolves,
            )
            self.add_dialogue(p["player_id"], content)
            speeches.append({"player_id": p["player_id"], "content": content})
        return {"speeches": speeches}

    def _do_vote(self) -> dict:
        """投票阶段（DE 按风格选择投票目标）。"""
        if not self.alive_players:
            return {"votes": {}, "eliminated": None}

        votes: Dict[int, int] = {}
        for voter in self.alive_players:
            candidates = [p for p in self.alive_players
                          if p["player_id"] != voter["player_id"]]
            if candidates:
                smart = self.decision_engine.vote_target(self.alive_players, voter["player_id"])
                valid_ids = [c["player_id"] for c in candidates]
                target = smart if smart in valid_ids else candidates[0]["player_id"]
                votes[voter["player_id"]] = target

        # 统计票数
        tally: Dict[int, int] = {}
        for target in votes.values():
            tally[target] = tally.get(target, 0) + 1

        # 警长有 1.5 票（向上取整，简化为 +1）
        if self.sheriff_id is not None and self.sheriff_id in votes:
            target = votes[self.sheriff_id]
            tally[target] = tally.get(target, 0) + 1

        # 得票最高者出局
        eliminated = None
        if tally:
            eliminated = max(tally, key=tally.get)
            self.add_death(eliminated, "vote")

            # 检查被投者是否为猎人
            killed = self.get_player(eliminated)
            if killed and killed["role"] == "hunter":
                self._hunter_shoot(eliminated, "vote")

        self.add_event("vote_result", {"votes": votes, "tally": tally,
                                       "eliminated": eliminated}, public=True)
        return {
            "votes": [{"voter": v, "target": t} for v, t in votes.items()],
            "tally": tally,
            "eliminated": eliminated,
        }

    def _do_day_end(self) -> dict:
        """检查胜负。"""
        winner = self.check_win()
        if winner:
            self.is_game_over = True
            self.winner = winner
        return {"winner": winner}

    # ---- 构建响应 ----

    def to_summary(self) -> GameSummary:
        return GameSummary(
            game_id=self.game_id,
            config_name=self.config_name,
            phase=self.phase,
            day_number=self.day_number,
            alive_count=len(self.alive_players),
            player_count=len(self.players),
            is_game_over=self.is_game_over,
            winner=self.winner,
            created_at=self.created_at,
        )

    def to_step_result(self, step_data: dict, next_phase: str) -> StepResult:
        return StepResult(
            game_id=self.game_id,
            phase=self.phase,
            phase_index=self.phase_index,
            day_number=self.day_number,
            step_data=step_data,
            players=[PlayerInfo(player_id=p["player_id"], name=p["name"],
                                is_alive=p["is_alive"])
                     for p in self.players],
            dialogues=[DialogueEntry(**d) for d in self.dialogues[-10:]],
            deaths=[DeathEntry(**d) for d in self.deaths[-5:]],
            is_game_over=self.is_game_over,
            winner=self.winner,
            next_phase=next_phase,
        )

    def to_state_response(self) -> GameStateResponse:
        return GameStateResponse(
            game_id=self.game_id,
            config_name=self.config_name,
            phase=self.phase,
            phase_index=self.phase_index,
            day_number=self.day_number,
            round_number=self.round_number,
            players=[PlayerInfoAdmin(
                player_id=p["player_id"], name=p["name"],
                is_alive=p["is_alive"], role=p["role"], side=p["side"],
            ) for p in self.players],
            sheriff_id=self.sheriff_id,
            dialogues=[DialogueEntry(**d) for d in self.dialogues],
            deaths=[DeathEntry(**d) for d in self.deaths],
            event_log=self.event_log,
            witch_antidote_used=self.witch_antidote_used,
            witch_poison_used=self.witch_poison_used,
            is_game_over=self.is_game_over,
            winner=self.winner,
            created_at=self.created_at,
        )


# ---- GameManager — 全局对局管理器 ----

class GameManager:
    """管理所有活跃对局。"""

    def __init__(self):
        self._games: Dict[str, GameSession] = {}

    def create(self, req: CreateGameRequest) -> GameSummary:
        if req.config_name not in GAME_CONFIGS:
            raise HTTPException(
                status_code=400,
                detail=f"无效配置: {req.config_name}。可选: {list(GAME_CONFIGS)}",
            )
        session = GameSession(
            config_name=req.config_name,
            player_names=req.player_names,
            shuffle=req.shuffle,
            player_styles=req.player_styles,
        )
        self._games[session.game_id] = session
        return session.to_summary()

    def step(self, game_id: str) -> StepResult:
        session = self._get(game_id)
        if session.is_game_over:
            raise HTTPException(status_code=400, detail="游戏已结束，无法推进")
        step_data = session.step()
        next_phase = session.phase if not session.is_game_over else None
        return session.to_step_result(step_data, next_phase)

    def get(self, game_id: str) -> GameStateResponse:
        session = self._get(game_id)
        return session.to_state_response()

    def list_all(self) -> List[GameSummary]:
        return [s.to_summary() for s in self._games.values()]

    def delete(self, game_id: str) -> DeleteResponse:
        session = self._get(game_id)
        del self._games[game_id]
        return DeleteResponse(game_id=game_id, deleted=True)

    def _get(self, game_id: str) -> GameSession:
        session = self._games.get(game_id)
        if session is None:
            raise HTTPException(status_code=404, detail=f"游戏不存在: {game_id}")
        return session


manager = GameManager()

# ---- 路由 ----

@app.get("/", response_model=HealthResponse)
async def health():
    """服务健康检查。"""
    return HealthResponse()


@app.post("/games", response_model=GameSummary, status_code=201)
async def create_game(req: CreateGameRequest):
    """创建并初始化一局新游戏。"""
    return manager.create(req)


@app.post("/games/{game_id}/step", response_model=StepResult)
async def step_game(game_id: str):
    """推进一个游戏阶段。"""
    return manager.step(game_id)


@app.get("/games/{game_id}", response_model=GameStateResponse)
async def get_game(game_id: str):
    """获取当前游戏完整状态（含角色信息，用于观战）。"""
    return manager.get(game_id)


@app.get("/games", response_model=List[GameSummary])
async def list_games():
    """列出所有活跃游戏。"""
    return manager.list_all()


@app.delete("/games/{game_id}", response_model=DeleteResponse)
async def delete_game(game_id: str):
    """删除一局游戏。"""
    return manager.delete(game_id)


@app.get("/configs", response_model=List[ConfigInfo])
async def list_configs():
    """列出可用角色配置。"""
    return [ConfigInfo(**cfg) for cfg in GAME_CONFIGS.values()]
