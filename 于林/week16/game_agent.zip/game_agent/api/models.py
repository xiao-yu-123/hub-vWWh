"""API 请求/响应 Pydantic 模型。"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


# ---- 游戏创建 ----

class CreateGameRequest(BaseModel):
    """创建新游戏的请求体。"""
    config_name: str = Field(
        default="standard_6",
        description="角色配置名：standard_6, simple_4, big_9",
    )
    player_names: Optional[List[str]] = Field(
        default=None,
        description="自定义玩家名称列表，不传则自动生成",
    )
    shuffle: bool = Field(
        default=True,
        description="是否随机打乱角色分配",
    )
    player_styles: Optional[Dict[str, str]] = Field(
        default=None,
        description="玩家决策风格映射，如 {\"0\": \"bold\", \"1\": \"cautious\"}",
    )


# ---- 玩家 ----

class PlayerInfo(BaseModel):
    """对局中的单个玩家信息（公开视图，不暴露角色）。"""
    player_id: int = Field(description="玩家编号")
    name: str = Field(description="玩家名称")
    is_alive: bool = Field(description="是否存活")


class PlayerInfoAdmin(PlayerInfo):
    """管理员/观战视图的玩家信息（包含角色和阵营）。"""
    role: Optional[str] = Field(default=None, description="角色名称")
    side: Optional[str] = Field(default=None, description="阵营：good / evil")


# ---- 对话 ----

class DialogueEntry(BaseModel):
    """一条发言记录。"""
    player_id: int = Field(description="发言玩家编号")
    player_name: str = Field(description="发言玩家名称")
    phase: str = Field(description="发言阶段")
    content: str = Field(description="发言内容")


# ---- 死亡 ----

class DeathEntry(BaseModel):
    """一条死亡记录。"""
    player_id: int = Field(description="死亡玩家编号")
    player_name: str = Field(description="死亡玩家名称")
    cause: str = Field(description="死因：night_kill / vote / poison / shoot")
    phase: str = Field(description="死亡发生的阶段")


# ---- 游戏摘要 ----

class GameSummary(BaseModel):
    """游戏列表项的简要信息。"""
    game_id: str = Field(description="游戏唯一 ID")
    config_name: str = Field(description="使用的角色配置名")
    phase: str = Field(description="当前阶段标识")
    day_number: int = Field(description="当前天数")
    alive_count: int = Field(description="存活人数")
    player_count: int = Field(description="总人数")
    is_game_over: bool = Field(description="游戏是否已结束")
    winner: Optional[str] = Field(default=None, description="胜利方：good / evil")
    created_at: str = Field(description="创建时间")


# ---- 阶段推进结果 ----

class StepResult(BaseModel):
    """step 接口返回的单步推进结果。"""
    game_id: str = Field(description="游戏 ID")
    phase: str = Field(description="当前阶段标识")
    phase_index: int = Field(description="当前阶段索引 (0-7)")
    day_number: int = Field(description="当前天数")
    step_data: Dict[str, Any] = Field(
        default_factory=dict,
        description="本阶段执行的动作和结果数据",
    )
    players: List[PlayerInfo] = Field(
        default_factory=list,
        description="所有玩家当前状态列表",
    )
    dialogues: List[DialogueEntry] = Field(
        default_factory=list,
        description="本阶段产生的发言",
    )
    deaths: List[DeathEntry] = Field(
        default_factory=list,
        description="本阶段产生的死亡",
    )
    is_game_over: bool = Field(default=False, description="游戏是否已结束")
    winner: Optional[str] = Field(default=None, description="胜利方：good / evil")
    next_phase: Optional[str] = Field(default=None, description="下一个阶段标识")


# ---- 完整游戏状态（管理员视图，含角色信息） ----

class GameStateResponse(BaseModel):
    """GET /games/{id} 返回的完整游戏状态（含角色）。"""
    game_id: str = Field(description="游戏 ID")
    config_name: str = Field(description="角色配置名")
    phase: str = Field(description="当前阶段标识")
    phase_index: int = Field(description="当前阶段索引")
    day_number: int = Field(description="当前天数")
    round_number: int = Field(description="总回合数（阶段步数）")
    players: List[PlayerInfoAdmin] = Field(
        default_factory=list,
        description="所有玩家（含角色和阵营）",
    )
    sheriff_id: Optional[int] = Field(default=None, description="警长玩家 ID")
    dialogues: List[DialogueEntry] = Field(default_factory=list, description="所有发言记录")
    deaths: List[DeathEntry] = Field(default_factory=list, description="所有死亡记录")
    event_log: List[Dict[str, Any]] = Field(default_factory=list, description="完整事件日志")
    witch_antidote_used: bool = Field(default=False, description="女巫解药是否已用")
    witch_poison_used: bool = Field(default=False, description="女巫毒药是否已用")
    is_game_over: bool = Field(default=False, description="游戏是否已结束")
    winner: Optional[str] = Field(default=None, description="胜利方")
    created_at: str = Field(description="创建时间")


# ---- 配置 ----

class ConfigInfo(BaseModel):
    """可用角色配置信息。"""
    name: str = Field(description="配置名")
    description: str = Field(description="配置描述")
    player_count: int = Field(description="总人数")
    roles: List[Dict[str, Any]] = Field(description="角色列表及数量")


# ---- 通用响应 ----

class HealthResponse(BaseModel):
    """健康检查响应。"""
    status: str = Field(default="ok", description="服务状态")
    timestamp: str = Field(
        default_factory=lambda: datetime.now().isoformat(),
        description="当前时间",
    )


class DeleteResponse(BaseModel):
    """删除游戏响应。"""
    game_id: str = Field(description="被删除的游戏 ID")
    deleted: bool = Field(default=True, description="是否删除成功")


class ErrorResponse(BaseModel):
    """错误响应。"""
    detail: str = Field(description="错误详情描述")
