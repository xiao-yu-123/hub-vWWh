"""总结代理。

每局游戏结束后，每个玩家 Agent 以第一人称视角，
根据自己在整局游戏中的经历进行深度反思总结。
总结结果可用于后续的自我进化（经验回放 / RLAIF）。
"""

import json
import re
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List

from agents.base import BaseAgent


SUMMARY_PROMPT_TEMPLATE = """你刚刚完成了一局狼人杀游戏。请以第一人称视角，回顾你这局游戏的表现，进行深度总结。

## 你的身份
- 角色：{role_name}
- 阵营：{camp_name}
- 玩家名称：{player_name}

## 游戏结果
- 胜利方：{winner_name}
- 你的阵营：{is_winner_text}

## 你的游戏经历
以下是你在整局游戏中经历的所有事件：
{personal_history}

## 要求
请反思你的表现，并以 **JSON 格式** 输出以下内容：

```json
{{
    "summary": "整体表现总结（2-3句话，回顾自己本局的表现和关键决策）",
    "strategies": "你使用了哪些策略？哪些有效、哪些无效？",
    "mistakes": "犯了哪些错误？有哪些地方可以做得更好？",
    "lessons": "对未来的自己有什么具体建议？（1-2条，面向同角色的后续游戏）"
}}
```

只输出 JSON，不要包含其他内容。
"""


@dataclass
class PlayerReflection:
    """玩家对局反思的结构化输出"""
    summary: str = ""
    strategies: str = ""
    mistakes: str = ""
    lessons: str = ""

    @classmethod
    def from_json(cls, data: dict) -> "PlayerReflection":
        return cls(
            summary=data.get("summary", ""),
            strategies=data.get("strategies", ""),
            mistakes=data.get("mistakes", ""),
            lessons=data.get("lessons", ""),
        )

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "strategies": self.strategies,
            "mistakes": self.mistakes,
            "lessons": self.lessons,
        }


class SummaryAgent(BaseAgent):
    """玩家反思总结 Agent。

    以玩家的第一人称视角，根据该玩家在整局游戏中的
    所有经历（personal_history），生成深度反思总结。
    """

    def __init__(self,
                 role_name: str,
                 camp_name: str,
                 player_name: str,
                 winner_name: str,
                 is_winner: bool,
                 personal_history: str):
        super().__init__()
        self.role_name = role_name
        self.camp_name = camp_name
        self.player_name = player_name
        self.winner_name = winner_name
        self.is_winner = is_winner

        self._personal_history = ""
        self.agent.name = f"复盘-{player_name}"
        self.agent.instructions = (
            f"你是一位刚刚完成了一局狼人杀游戏的玩家。"
            f"你的角色是{role_name}，阵营是{camp_name}。"
            f"请以第一人称视角对自己的表现进行深度反思。"
        )

    def build_prompt(self) -> str:
        """根据玩家信息和对局经历构建反思 prompt。"""
        is_winner_text = "你所在的阵营**获胜**了！" if self.is_winner else "你所在的阵营**失败**了。"

        return SUMMARY_PROMPT_TEMPLATE.format(
            role_name=self.role_name,
            camp_name=self.camp_name,
            player_name=self.player_name,
            winner_name=self.winner_name,
            is_winner_text=is_winner_text,
            personal_history=self._personal_history or "（本局游戏记录为空）",
        )

    def set_personal_history(self, history: str):
        """设置玩家在本局中的个人经历文本。

        应由 GameEngine 在游戏结束时调用，
        传入该玩家视角下的所有事件（发言、动作、查验结果等）。
        """
        self._personal_history = history

    async def summarize(self) -> PlayerReflection:
        """生成反思总结。

        Returns:
            PlayerReflection
        """
        prompt = self.build_prompt()
        try:
            raw_output = await self.run(prompt)
            return self.parse_reflection(raw_output)
        except Exception:
            return PlayerReflection(
                summary="LLM 调用失败，无法生成反思总结。",
            )

    def parse_reflection(self, raw_output: str) -> PlayerReflection:
        """从 LLM 输出解析反思报告。

        Args:
            raw_output: LLM 原始输出

        Returns:
            PlayerReflection
        """
        json_str = self._extract_json(raw_output)
        if json_str is None:
            return PlayerReflection(
                summary=raw_output[:200] if raw_output else "",
                mistakes="JSON 解析失败",
            )
        try:
            data = json.loads(json_str)
            return PlayerReflection.from_json(data)
        except json.JSONDecodeError:
            return PlayerReflection(
                summary=raw_output[:200] if raw_output else "",
                mistakes="JSON 解析失败",
            )

    @staticmethod
    def _extract_json(text: str) -> Optional[str]:
        m = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', text, re.DOTALL)
        if m:
            return m.group(1).strip()
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1 and end > start:
            return text[start:end + 1]
        return None
