"""玩家 AI 代理。

基于 BaseAgent，为每个游戏角色创建具有角色意识的 Agent。
接收游戏状态的合法视图，通过 LLM 生成结构化决策。
"""

import json
import re
from dataclasses import dataclass, field
from typing import Optional, Dict, Any

from agents.base import BaseAgent


ROLE_INSTRUCTIONS = {
    "werewolf": (
        "你是狼人杀中的狼人。你的阵营是邪恶方。\n"
        "目标：消灭所有神职或所有村民（屠边规则）。\n"
        "夜晚：与其他狼人协商后选择一名击杀目标。\n"
        "白天：伪装成好人发言，投票时引导放逐好人。"
    ),
    "seer": (
        "你是狼人杀中的预言家。你的阵营是好人方神职。\n"
        "目标：帮助好人阵营消灭所有狼人。\n"
        "夜晚：查验一名玩家的阵营（好人/狼人）。\n"
        "白天：可以透露查验结果，引导好人投票放逐狼人。"
    ),
    "witch": (
        "你是狼人杀中的女巫。你的阵营是好人方神职。\n"
        "目标：帮助好人阵营消灭所有狼人。\n"
        "拥有两瓶药：解药（复活被刀玩家，不可自救）和毒药（毒杀一名玩家），各限用一次。"
    ),
    "hunter": (
        "你是狼人杀中的猎人。你的阵营是好人方神职。\n"
        "目标：帮助好人阵营消灭所有狼人。\n"
        "被动技能：被刀或被投票出局时可以开枪带走一人；被毒则不能开枪。"
    ),
    "villager": (
        "你是狼人杀中的村民。你的阵营是好人方平民。\n"
        "目标：帮助好人阵营消灭所有狼人。\n"
        "无特殊技能，纯靠听发言进行逻辑推理和投票。"
    ),
}


@dataclass
class PlayerDecision:
    """玩家决策的结构化输出"""
    action: str = ""
    target: Optional[int] = None
    content: str = ""
    reason: str = ""

    @classmethod
    def from_json(cls, data: dict) -> "PlayerDecision":
        return cls(
            action=data.get("action", ""),
            target=data.get("target"),
            content=data.get("content", ""),
            reason=data.get("reason", ""),
        )

    def to_dict(self) -> dict:
        return {
            "action": self.action,
            "target": self.target,
            "content": self.content,
            "reason": self.reason,
        }


class PlayerAgent(BaseAgent):
    """具有角色意识的玩家 Agent。

    根据 role_type 构建对应的系统指令，
    接收游戏状态视图生成决策。
    """

    def __init__(self, player_id: int, role_type: str, camp: str,
                 player_name: str = None, extra_context: dict = None):
        super().__init__()
        self.player_id = player_id
        self.role_type = role_type
        self.camp = camp
        self.player_name = player_name or f"玩家{player_id}"
        self.extra_context = extra_context or {}

        instructions = self._build_instructions()
        self.agent.name = f"{self.player_name}({self.role_type})"
        self.agent.instructions = instructions

    def _build_instructions(self) -> str:
        """根据角色构建系统指令。"""
        base = ROLE_INSTRUCTIONS.get(
            self.role_type, "你是狼人杀的一名玩家。"
        )
        parts = [base]
        parts.append(f"\n你的玩家编号是 {self.player_id}，名字是 {self.player_name}。")
        parts.append(f"你的阵营是 {'好人方' if self.camp == 'good' else '邪恶方'}。")

        if self.extra_context:
            parts.append("\n你的私有信息：")
            for key, value in self.extra_context.items():
                parts.append(f"  - {key}: {value}")

        parts.append(
            "\n请根据当前游戏状态做出决策。你必须以 JSON 格式回复：\n"
            '{"action": "<行动>", "target": <目标玩家ID或null>, '
            '"content": "<发言内容或决策说明>", "reason": "<推理过程>"}'
        )
        return "\n".join(parts)

    def build_prompt(self, game_view: dict) -> str:
        """根据游戏视图构建当前轮次的 prompt。

        Args:
            game_view: 玩家合法视图

        Returns:
            格式化的游戏状态描述文本
        """
        lines = [
            f"=== 第 {game_view.get('day_number', 1)} 天 ===",
            f"当前阶段: {game_view.get('phase', 'unknown')}",
        ]

        # 存活玩家列表
        players = game_view.get("players", [])
        parts = []
        for p in players:
            pid = p.get("player_id", "?")
            name = p.get("name", f"玩家{pid}")
            status = "存活" if p.get("is_alive", True) else "死亡"
            parts.append(f"  [{pid}] {name} ({status})")
        lines.append("玩家状态:\n" + "\n".join(parts))

        # 近期发言
        speeches = game_view.get("recent_speeches", [])
        if speeches:
            lines.append("近期发言:")
            for s in speeches[-6:]:
                sid = s.get("player_id", "?")
                sname = s.get("player_name", f"玩家{sid}")
                lines.append(f"  [{sid}] {sname}: {s.get('content', '')}")

        # 近期事件
        events = game_view.get("recent_events", [])
        if events:
            lines.append("近期事件:")
            for e in events[-5:]:
                ename = e.get("event_type", "")
                edata = e.get("data", {})
                lines.append(f"  - {ename}: {edata}")

        # 操作提示
        action_space = game_view.get("my_action_space", [])
        if action_space:
            lines.append(f"\n可执行操作: {', '.join(action_space)}")
        lines.append("\n请给出你的决策（JSON 格式）：")
        return "\n".join(lines)

    async def decide(self, game_view: dict) -> PlayerDecision:
        """根据游戏视图做出决策。

        Args:
            game_view: 玩家合法视图

        Returns:
            PlayerDecision
        """
        prompt = self.build_prompt(game_view)
        try:
            raw_output = await self.run(prompt)
            return self.parse_decision(raw_output)
        except Exception:
            return PlayerDecision(action="pass", reason="LLM 调用失败，跳过")

    def parse_decision(self, raw_output: str) -> PlayerDecision:
        """从 LLM 输出解析结构化决策。

        支持格式：纯 JSON、```json 代码块、含额外文本的 JSON。

        Args:
            raw_output: LLM 原始输出文本

        Returns:
            PlayerDecision
        """
        json_str = self._extract_json(raw_output)
        if json_str is None:
            return PlayerDecision(action="pass", content=raw_output, reason="无法提取 JSON")

        try:
            data = json.loads(json_str)
            return PlayerDecision.from_json(data)
        except json.JSONDecodeError:
            return PlayerDecision(action="pass", content=raw_output, reason="JSON 解析失败")

    @staticmethod
    def _extract_json(text: str) -> Optional[str]:
        """从文本中提取 JSON 字符串。"""
        # 尝试 markdown 代码块
        m = re.search(r'```(?:json)?\s*\n?(.*?)\n?```', text, re.DOTALL)
        if m:
            return m.group(1).strip()
        # 尝试直接匹配 { ... }
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1 and end > start:
            return text[start:end + 1]
        return None
