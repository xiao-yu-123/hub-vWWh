"""Agents package — re-exports from openai-agents SDK.

The local agents/ directory shadows the openai-agents SDK package.
We temporarily remove ourselves from sys.modules, import the real SDK,
restore ourselves, and copy the needed attributes.
"""

import sys as _sys
import os as _os

_root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))

# Save reference to this package
_self = _sys.modules[__name__]

# Temporarily remove from sys.modules so 'import agents' finds the SDK
del _sys.modules[__name__]

# Remove project root from path so SDK is found
_orig_path = _sys.path.copy()
_sys.path = [p for p in _sys.path if _os.path.abspath(p) != _root]

# Import the real SDK
import agents as _sdk  # noqa: E402

# Restore path and ourselves
_sys.path = _orig_path
_sys.modules[__name__] = _self

# Re-export SDK symbols that our local modules need
Agent = _sdk.Agent
Runner = _sdk.Runner
set_default_openai_api = _sdk.set_default_openai_api
set_tracing_disabled = _sdk.set_tracing_disabled
