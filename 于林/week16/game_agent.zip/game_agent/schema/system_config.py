"""系统配置加载模块。"""

import json
import os
from dataclasses import dataclass, field


@dataclass
class LogConfig:
    level: str = "INFO"         # DEBUG / INFO / WARNING / ERROR
    output_dir: str = "logs"    # 日志输出目录
    console: bool = True        # 是否输出到控制台
    file: bool = True           # 是否输出到文件


@dataclass
class SystemConfig:
    """系统全局配置。"""
    default_model: str = "gpt-4o"
    api_base_url: str = "https://api.openai.com/v1"
    api_key: str = ""
    max_retries: int = 2
    log: LogConfig = field(default_factory=LogConfig)


def load_system_config(path: str) -> SystemConfig:
    """从 JSON 文件加载系统配置。文件不存在时返回默认值。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return SystemConfig()

    log_cfg = data.get("log", {})
    return SystemConfig(
        default_model=data.get("model", data.get("default_model", "gpt-4o")),
        api_base_url=data.get("api_base_url", "https://api.openai.com/v1"),
        api_key=data.get("api_key", ""),
        max_retries=data.get("max_retries", 2),
        log=LogConfig(
            level=log_cfg.get("level", "INFO"),
            output_dir=log_cfg.get("output_dir", "logs"),
            console=log_cfg.get("console", True),
            file=log_cfg.get("file", True),
        ),
    )
