"""游戏运行日志模块。

在游戏运行过程中实时记录结构化日志。
支持控制台输出和文件持久化两种模式。

用法:
    logger = GameLogger("logs/game_001.log")
    logger.phase_start("night_wolf", 1)
    logger.player_action(0, "kill", target=3, reason="他是预言家")
    logger.phase_end("night_wolf", 1, {"final_target": 3})
    logger.game_over("evil")
    logger.close()
"""

import json
import os
import sys
from datetime import datetime
from typing import Optional, List, Dict, Any


class GameLogger:
    """游戏运行日志记录器。

    同时支持控制台彩色输出和 JSON 文件写入。
    """

    # ANSI 颜色码
    COLORS = {
        "phase": "\033[1;36m",    # 青色加粗 — 阶段切换
        "action": "\033[1;33m",   # 黄色加粗 — 玩家行动
        "death": "\033[1;31m",    # 红色加粗 — 死亡
        "speech": "\033[0;32m",   # 绿色 — 发言
        "vote": "\033[0;35m",     # 紫色 — 投票
        "result": "\033[1;32m",   # 绿色加粗 — 结果
        "error": "\033[1;31m",    # 红色加粗 — 错误
        "info": "\033[0;37m",     # 白色 — 一般信息
        "reset": "\033[0m",
    }

    def __init__(self,
                 filepath: Optional[str] = None,
                 console: bool = True,
                 min_level: str = "INFO"):
        """
        Args:
            filepath: 日志文件路径，None 则不写入文件
            console: 是否输出到控制台
            min_level: 最低日志级别 (DEBUG / INFO)
        """
        self.filepath = filepath
        self.console = console
        self.min_level = min_level
        self._start_time = datetime.now()
        self._file = None

        if filepath:
            os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
            self._file = open(filepath, "w", encoding="utf-8")

    def close(self):
        """关闭日志文件。"""
        if self._file:
            self._file.close()
            self._file = None

    # ---- 阶段日志 ----

    def phase_start(self, phase: str, day: int, msg: str = ""):
        self._log("phase", f"⏱ [第{day}天] {phase} 开始 {msg}".strip())

    def phase_end(self, phase: str, day: int, result: dict = None):
        info = json.dumps(result, ensure_ascii=False) if result else ""
        self._log("phase", f"⏱ [第{day}天] {phase} 结束 {info}".strip())

    # ---- 玩家行动 ----

    def player_action(self, player_id: int, action: str, target: int = None,
                      reason: str = "", private: bool = False):
        """记录玩家行动。

        Args:
            player_id: 行动玩家 ID
            action: 行动类型 (kill/check/save/poison/shoot/speak/vote)
            target: 行动目标 ID
            reason: 行动原因/推理
            private: 是否为私密行动（如狼刀、查验）
        """
        lock = " " if private else ""
        target_str = f" -> 玩家{target}" if target is not None else ""
        reason_str = f" ({reason})" if reason else ""
        self._log("action",
                  f"{lock}玩家{player_id} [{action}]{target_str}{reason_str}")

    # ---- 发言 ----

    def speech(self, player_id: int, player_name: str, content: str):
        short = content[:100] + "..." if len(content) > 100 else content
        self._log("speech", f"  [{player_id}]{player_name}: {short}")

    # ---- 投票 ----

    def vote_result(self, votes: List[dict], tally: dict,
                    eliminated: Optional[int]):
        """记录投票结果。"""
        lines = [f"投票结果: {tally}"]
        if eliminated is not None:
            lines.append(f"，放逐玩家{eliminated}")
        self._log("vote", "".join(lines))

    # ---- 死亡 ----

    def death(self, player_id: int, player_name: str, cause: str):
        """记录死亡事件。"""
        cause_cn = {"night_kill": "被狼刀", "vote": "被放逐",
                    "poison": "被毒", "shoot": "被枪带"}
        label = cause_cn.get(cause, cause)
        self._log("death", f"☠ 玩家{player_id}({player_name}) {label}")

    # ---- 特殊事件 ----

    def witch_save(self, target: int):
        self._log("action", f"  女巫使用解药救活玩家{target}")

    def hunter_shoot(self, hunter_id: int, target: int):
        self._log("action", f"  猎人玩家{hunter_id}开枪带走玩家{target}")

    def seer_check(self, seer_id: int, target: int, result: str):
        result_cn = "狼人" if result == "evil" else "好人"
        self._log("action", f"  预言家玩家{seer_id}查验玩家{target}: {result_cn}")

    # ---- 胜负 ----

    def game_over(self, winner: str, day: int = 0):
        winner_cn = "好人阵营获胜!" if winner == "good" else "狼人阵营获胜!"
        elapsed = (datetime.now() - self._start_time).total_seconds()
        self._log("result", f"游戏结束 [{winner_cn}] "
                  f"(第{day}天, 耗时{elapsed:.1f}秒)")

    # ---- 通用 ----

    def info(self, msg: str):
        self._log("info", msg)

    def error(self, msg: str):
        self._log("error", msg)

    # ---- 内部 ----

    def _log(self, tag: str, message: str):
        ts = datetime.now().strftime("%H:%M:%S")

        # 控制台输出（带颜色）
        if self.console:
            color = self.COLORS.get(tag, "")
            reset = self.COLORS["reset"]
            print(f"{ts} {color}{message}{reset}", file=sys.stderr, flush=True)

        # 文件输出（纯 JSON）
        if self._file:
            record = {"time": ts, "tag": tag, "message": message}
            self._file.write(json.dumps(record, ensure_ascii=False) + "\n")
            self._file.flush()

    def __del__(self):
        self.close()
