"""游戏记录数据结构。

一局完整狼人杀对局的所有数据，包括：
- 玩家信息与角色分配
- 每个阶段的事件日志
- 所有发言和投票记录
- 死亡记录和胜负结果

可用于：复盘回放、经验存储、前端展示、天梯榜统计。
"""

import json
import os
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime


@dataclass
class GameRecord:
    """一局完整对局的不可变记录。"""
    game_id: str = ""
    config_name: str = ""
    winner: Optional[str] = None             # "good" / "evil"
    total_rounds: int = 0
    total_days: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    finished_at: str = ""

    # 玩家
    players: List[Dict[str, Any]] = field(default_factory=list)
    # [{player_id, name, role, side, is_alive}]

    # 事件
    event_log: List[Dict[str, Any]] = field(default_factory=list)
    # [{phase, day, event_type, data, public}]

    # 发言
    dialogues: List[Dict[str, Any]] = field(default_factory=list)
    # [{player_id, player_name, phase, content}]

    # 死亡
    deaths: List[Dict[str, Any]] = field(default_factory=list)
    # [{player_id, player_name, cause, phase}]

    # 投票
    vote_history: List[Dict[str, Any]] = field(default_factory=list)
    # [{day, votes: [{voter, target}], tally, eliminated}]

    # 警长
    sheriff_id: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "game_id": self.game_id,
            "config_name": self.config_name,
            "winner": self.winner,
            "total_rounds": self.total_rounds,
            "total_days": self.total_days,
            "created_at": self.created_at,
            "finished_at": self.finished_at,
            "players": self.players,
            "event_log": self.event_log,
            "dialogues": self.dialogues,
            "deaths": self.deaths,
            "vote_history": self.vote_history,
            "sheriff_id": self.sheriff_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "GameRecord":
        return cls(
            game_id=d.get("game_id", ""),
            config_name=d.get("config_name", ""),
            winner=d.get("winner"),
            total_rounds=d.get("total_rounds", 0),
            total_days=d.get("total_days", 0),
            created_at=d.get("created_at", ""),
            finished_at=d.get("finished_at", ""),
            players=d.get("players", []),
            event_log=d.get("event_log", []),
            dialogues=d.get("dialogues", []),
            deaths=d.get("deaths", []),
            vote_history=d.get("vote_history", []),
            sheriff_id=d.get("sheriff_id"),
        )

    # ---- 便捷构造 ----

    @classmethod
    def from_game_state(cls, state: "GameState", game_id: str,
                        config_name: str) -> "GameRecord":
        """从 GameState 构建 GameRecord。"""
        return cls(
            game_id=game_id,
            config_name=config_name,
            winner=state.winner,
            total_rounds=state.round_number,
            total_days=state.day_number,
            finished_at=datetime.now().isoformat(),
            players=[p.to_admin_dict() for p in state.players],
            event_log=[{
                "phase": e.phase, "day": e.day,
                "event_type": e.event_type, "data": e.data,
                "public": e.public,
            } for e in state.event_log],
            dialogues=[{
                "player_id": d.player_id, "player_name": d.player_name,
                "phase": d.phase, "content": d.content,
            } for d in state.dialogues],
            deaths=[{
                "player_id": d.player_id, "player_name": d.player_name,
                "cause": d.cause, "phase": d.phase,
            } for d in state.deaths],
            sheriff_id=state.sheriff_id,
        )

    # ---- 序列化 ----

    def to_json(self, path: str):
        """保存为 JSON 文件。"""
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    @classmethod
    def from_json(cls, path: str) -> "GameRecord":
        """从 JSON 文件加载。"""
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)

    # ---- 统计查询 ----

    def get_player_events(self, player_id: int) -> List[dict]:
        """获取某玩家的所有相关事件。"""
        result = []
        for e in self.event_log:
            data = e.get("data", {})
            if player_id in (data.get("player_id"), data.get("target"),
                             data.get("seer_id"), data.get("witch_id"),
                             data.get("hunter_id")):
                result.append(e)
            if "wolf_ids" in data and player_id in data["wolf_ids"]:
                result.append(e)
        return result

    def get_player_speeches(self, player_id: int) -> List[dict]:
        """获取某玩家的所有发言。"""
        return [d for d in self.dialogues if d.get("player_id") == player_id]

    def killer_of(self, player_id: int) -> Optional[str]:
        """返回指定玩家的死因。"""
        for d in self.deaths:
            if d.get("player_id") == player_id:
                return d.get("cause")
        return None

    @property
    def wolf_players(self) -> List[dict]:
        return [p for p in self.players if p.get("role") == "werewolf"]

    @property
    def god_players(self) -> List[dict]:
        return [p for p in self.players if p.get("role") in ("seer", "witch", "hunter")]
