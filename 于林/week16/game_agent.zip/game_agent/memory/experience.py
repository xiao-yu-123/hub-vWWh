"""跨游戏经验存储与共享。

按角色类型（werewolf/seer/witch/hunter/villager）保存每局游戏的反思总结。
在构建 PlayerAgent 指令时，将过往经验格式化为提示词，实现经验共享。
"""

import json
import os
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from datetime import datetime

_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
MAX_EXPERIENCES_PER_ROLE = 20


@dataclass
class Experience:
    """单局游戏经验记录。

    来源：SummaryAgent 生成的 PlayerReflection，
    在每局结束后由 GameEngine 调用 save_experience() 持久化。
    """
    role_type: str
    camp: str
    winner: str
    is_winner: bool
    summary: str = ""
    strategies: str = ""
    mistakes: str = ""
    lessons: str = ""
    game_id: str = ""
    player_name: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {
            "role_type": self.role_type,
            "camp": self.camp,
            "winner": self.winner,
            "is_winner": self.is_winner,
            "summary": self.summary,
            "strategies": self.strategies,
            "mistakes": self.mistakes,
            "lessons": self.lessons,
            "game_id": self.game_id,
            "player_name": self.player_name,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Experience":
        return cls(
            role_type=d.get("role_type", ""),
            camp=d.get("camp", ""),
            winner=d.get("winner", ""),
            is_winner=d.get("is_winner", False),
            summary=d.get("summary", ""),
            strategies=d.get("strategies", ""),
            mistakes=d.get("mistakes", ""),
            lessons=d.get("lessons", ""),
            game_id=d.get("game_id", ""),
            player_name=d.get("player_name", ""),
            timestamp=d.get("timestamp", ""),
        )


class ExperienceStore:
    """经验的持久化存储。

    每个角色类型一个 JSON 文件（如 werewolf.json），
    存储该角色的所有历史经验记录。
    """

    def __init__(self, data_dir: str = None):
        self._data_dir = data_dir or _DATA_DIR
        os.makedirs(self._data_dir, exist_ok=True)

    def _file_path(self, role_type: str) -> str:
        return os.path.join(self._data_dir, f"{role_type}.json")

    def save(self, exp: Experience):
        records = self._load_file(exp.role_type)
        records.append(exp.to_dict())
        if len(records) > MAX_EXPERIENCES_PER_ROLE:
            records = records[-MAX_EXPERIENCES_PER_ROLE:]
        with open(self._file_path(exp.role_type), "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)

    def load(self, role_type: str) -> List[Experience]:
        records = self._load_file(role_type)
        return [Experience.from_dict(r) for r in records]

    def _load_file(self, role_type: str) -> list:
        path = self._file_path(role_type)
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []

    def load_all(self) -> Dict[str, List[Experience]]:
        roles = ["werewolf", "seer", "witch", "hunter", "villager"]
        return {r: self.load(r) for r in roles}

    def clear(self, role_type: str = None):
        if role_type:
            path = self._file_path(role_type)
            if os.path.exists(path):
                os.remove(path)
        else:
            for role in ["werewolf", "seer", "witch", "hunter", "villager"]:
                path = self._file_path(role)
                if os.path.exists(path):
                    os.remove(path)


# 全局单例
_store = ExperienceStore()


def save_experience(exp: Experience):
    _store.save(exp)


def load_experiences(role_type: str) -> List[Experience]:
    return _store.load(role_type)


def format_experience_prompt(role_type: str, max_items: int = 5) -> str:
    """将过往经验格式化为提示词文本，供 PlayerAgent 构建指令时使用。

    优先展示胜利局的经验和 lessons。
    无经验时返回空字符串。
    """
    exps = _store.load(role_type)
    if not exps:
        return ""

    wins = [e for e in exps if e.is_winner]
    losses = [e for e in exps if not e.is_winner]

    selected = wins[:max_items]
    if len(selected) < max_items:
        selected += losses[:max_items - len(selected)]

    selected = sorted(selected, key=lambda e: e.timestamp, reverse=True)[:max_items]

    lines = ["\n## 历史游戏经验（来自过往对局的反思）"]
    for i, exp in enumerate(selected, 1):
        outcome = "胜利" if exp.is_winner else "失败"
        lines.append(f"\n### 第{i}局（{outcome}）")
        if exp.summary:
            lines.append(f"总结: {exp.summary}")
        if exp.lessons:
            lines.append(f"心得: {exp.lessons}")

    return "\n".join(lines)


def get_lessons_summary(role_type: str, top_n: int = 3) -> str:
    """提取该角色的 Top-N 经验教训摘要。

    用于作为简短的注入文本拼入 player_agent 的 extra_context。
    无经验时返回空字符串。
    """
    exps = _store.load(role_type)
    if not exps:
        return ""

    all_lessons = []
    for e in exps:
        if e.lessons:
            all_lessons.append(e.lessons)

    if not all_lessons:
        return ""

    unique = list(dict.fromkeys(all_lessons[::-1]))[::-1]
    parts = []
    for i, lesson in enumerate(unique[:top_n], 1):
        short = lesson[:120] + "..." if len(lesson) > 120 else lesson
        parts.append(f"{i}. {short}")

    return "\n".join(parts)
