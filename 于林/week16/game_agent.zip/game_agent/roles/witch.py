"""女巫角色。

女巫属于好人阵营神职。拥有两瓶药：
- 解药：可以复活当晚被狼人击杀的玩家（一局限用一次，不可自救）
- 毒药：可以毒杀任意一名存活玩家（一局限用一次）
规则约束：单夜不能双药同用。
胜利条件：所有狼人死亡。
"""

from typing import Optional, List, Dict, Any
from roles.base import BaseRole, RoleType, Camp, NightAction, VoteAction


class Witch(BaseRole):

    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._antidote_used = False
        self._poison_used = False

    @property
    def role_type(self) -> RoleType:
        return RoleType.WITCH

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    @property
    def antidote_used(self) -> bool:
        return self._antidote_used

    @property
    def poison_used(self) -> bool:
        return self._poison_used

    def use_antidote(self):
        self._antidote_used = True

    def use_poison(self):
        self._poison_used = True

    def is_night_actionable(self) -> bool:
        return not self._antidote_used or not self._poison_used

    def get_available_actions(self, game_state: Dict[str, Any]) -> List[str]:
        """获取女巫当前可用的行动列表。

        规则：
        - 单夜不能双药同用：如果有解药且有毒药，需要二选一
        - 解药仅在有人被狼刀时可用
        - 毒药始终可用（只要未使用）

        Args:
            game_state: 当前游戏状态，需包含 night_kill_target

        Returns:
            可用行动列表，如 ["save"], ["poison"], ["save", "poison"], ["pass"]
        """
        night_kill_target = game_state.get("night_kill_target")
        can_save = (
            not self._antidote_used
            and night_kill_target is not None
            and night_kill_target != self.player_id  # 不可自救
        )
        can_poison = not self._poison_used

        if can_save and can_poison:
            return ["save", "poison"]  # 二选一，不能双药同用
        elif can_save:
            return ["save"]
        elif can_poison:
            return ["poison"]
        else:
            return ["pass"]

    def get_night_action(self, game_state: Dict[str, Any]) -> Optional[NightAction]:
        """女巫夜晚行动：根据可用行动返回默认选择。

        Args:
            game_state: 当前游戏状态

        Returns:
            NightAction("save", target) / NightAction("poison", target) / None
        """
        available = self.get_available_actions(game_state)
        if not available or available == ["pass"]:
            return None

        action_type = available[0]  # 默认选第一个可用行动

        if action_type == "save":
            target = game_state.get("night_kill_target")
            return NightAction(action_type="save", target=target)

        if action_type == "poison":
            targets = self.get_valid_poison_targets(game_state)
            if targets:
                return NightAction(action_type="poison", target=targets[0])
            return None

        return None

    def get_valid_poison_targets(self, game_state: Dict[str, Any]) -> List[int]:
        """获取毒药合法目标（排除自己，选任意存活玩家）。

        Args:
            game_state: 当前游戏状态

        Returns:
            可毒杀的玩家 ID 列表
        """
        alive_players = game_state.get("alive_players", [])
        targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id:
                targets.append(pid)
        return targets

    def get_speech(self, game_state: Dict[str, Any]) -> str:
        """女巫白天发言。

        Args:
            game_state: 当前游戏状态

        Returns:
            发言文本（实际使用时由 Agent 决策层生成）
        """
        return "我是好人，先听发言再看情况。"

    def get_vote_target(self, game_state: Dict[str, Any]) -> Optional[VoteAction]:
        """女巫白天投票。"""
        alive_players = game_state.get("alive_players", [])
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id:
                return VoteAction(target=pid)
        return None

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        """检查好人阵营是否胜利（所有狼人死亡）。"""
        alive = game_state.get("alive_players", [])

        def _get_role(p) -> str:
            return p.get("role", "") if isinstance(p, dict) else getattr(p, "role", "")

        alive_wolves = sum(1 for p in alive if _get_role(p) == "werewolf")
        return alive_wolves == 0

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        """女巫死亡处理：无特殊技能。"""
        self._is_alive = False
        return None

    def get_private_context(self) -> Dict[str, Any]:
        """获取女巫的私有上下文（包括药品状态）。"""
        ctx = super().get_private_context()
        ctx["role_type"] = "witch"
        ctx["night_action"] = "save_or_poison"
        ctx["antidote_used"] = self._antidote_used
        ctx["poison_used"] = self._poison_used
        return ctx
