"""猎人角色。

猎人属于好人阵营神职。无夜间技能。
被动技能：因夜间被刀或白天被投票放逐而死时，可以翻牌开枪带走一名存活玩家。
若被女巫毒死，则技能锁定，无法开枪（闷枪）。
胜利条件：所有狼人死亡。
"""

from typing import Optional, List, Dict, Any
from roles.base import BaseRole, RoleType, Camp, VoteAction


class Hunter(BaseRole):

    @property
    def role_type(self) -> RoleType:
        return RoleType.HUNTER

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    def is_night_actionable(self) -> bool:
        return False

    def get_speech(self, game_state: Dict[str, Any]) -> str:
        """猎人白天发言。

        Args:
            game_state: 当前游戏状态

        Returns:
            发言文本（实际使用时由 Agent 决策层生成）
        """
        return "我是好人，有信息可以出来带队。"

    def get_vote_target(self, game_state: Dict[str, Any]) -> Optional[VoteAction]:
        """猎人白天投票。

        Args:
            game_state: 当前游戏状态

        Returns:
            VoteAction 或 None
        """
        alive_players = game_state.get("alive_players", [])
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id:
                return VoteAction(target=pid)
        return None

    def get_valid_shoot_targets(self, game_state: Dict[str, Any]) -> List[int]:
        """获取死亡时可开枪的合法目标列表（供 Agent 决策层使用）。

        排除自己，可选任意存活玩家。

        Args:
            game_state: 当前游戏状态

        Returns:
            可射击的玩家 ID 列表
        """
        alive_players = game_state.get("alive_players", [])
        targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id:
                targets.append(pid)
        return targets

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        """猎人死亡时触发被动技能。

        - 被刀（night_kill）或被投票（vote）：可以开枪带走一人
        - 被毒（poison）：技能锁定，不能开枪

        Args:
            cause: 死因，"night_kill" / "vote" / "poison" / "shoot"
            game_state: 当前游戏状态

        Returns:
            被开枪带走的玩家 ID 列表（单个元素），或 None（不开枪/闷枪）
        """
        self._is_alive = False

        # 被毒则闷枪
        if cause == "poison":
            return None

        # 被刀或被投票则可以开枪
        if cause in ("night_kill", "vote"):
            targets = self.get_valid_shoot_targets(game_state)
            if targets:
                return [targets[0]]  # 默认选第一个目标（由 Agent 决策层覆盖）
            return None

        return None

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        """检查好人阵营是否胜利（所有狼人死亡）。"""
        alive = game_state.get("alive_players", [])

        def _get_role(p) -> str:
            return p.get("role", "") if isinstance(p, dict) else getattr(p, "role", "")

        alive_wolves = sum(1 for p in alive if _get_role(p) == "werewolf")
        return alive_wolves == 0

    def get_private_context(self) -> Dict[str, Any]:
        """获取猎人的私有上下文。"""
        ctx = super().get_private_context()
        ctx["role_type"] = "hunter"
        ctx["night_action"] = None
        ctx["death_ability"] = "shoot"
        return ctx
