"""预言家角色。

预言家属于好人阵营神职。每晚可以查验一名存活玩家的阵营归属。
法官返回"good"或"evil"的二元结果。
白天可以发言（可透露查验结果）和投票。
胜利条件：所有狼人死亡。
"""

from typing import Optional, List, Dict, Any
from roles.base import BaseRole, RoleType, Camp, NightAction, VoteAction


class Seer(BaseRole):

    @property
    def role_type(self) -> RoleType:
        return RoleType.SEER

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    def is_night_actionable(self) -> bool:
        return True

    def get_night_action(self, game_state: Dict[str, Any]) -> Optional[NightAction]:
        """预言家夜晚行动：查验一名存活玩家（不能查验自己，不能重复查验）。

        Args:
            game_state: 当前游戏状态，需包含:
                - alive_players: 存活玩家列表
                - check_history: dict[int, str] 已查验过的玩家ID -> 结果

        Returns:
            NightAction("check", target) 或 None（无合法目标）
        """
        alive_players = game_state.get("alive_players", [])
        check_history = game_state.get("check_history", {})

        valid_targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id and pid not in check_history:
                valid_targets.append(pid)

        if not valid_targets:
            return None
        return NightAction(action_type="check", target=valid_targets[0])

    def get_valid_check_targets(self, game_state: Dict[str, Any]) -> List[int]:
        """获取当前可查验的玩家列表（供 Agent 决策层使用）。"""
        alive_players = game_state.get("alive_players", [])
        check_history = game_state.get("check_history", {})

        valid_targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id and pid not in check_history:
                valid_targets.append(pid)
        return valid_targets

    def get_speech(self, game_state: Dict[str, Any]) -> str:
        """预言家白天发言——可透露查验结果。

        Args:
            game_state: 当前游戏状态

        Returns:
            发言文本（实际使用时由 Agent 决策层生成）
        """
        return "我是预言家，查验结果稍后公布。"

    def get_vote_target(self, game_state: Dict[str, Any]) -> Optional[VoteAction]:
        """预言家白天投票。

        Args:
            game_state: 当前游戏状态

        Returns:
            VoteAction 或 None
        """
        alive_players = game_state.get("alive_players", [])
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id:
                return VoteAction(target=pid)
        return None

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        """检查好人阵营是否胜利（所有狼人死亡）。"""
        alive = game_state.get("alive_players", [])

        def _get_role(p) -> str:
            return p.get("role", "") if isinstance(p, dict) else getattr(p, "role", "")

        alive_wolves = sum(1 for p in alive if _get_role(p) == "werewolf")
        return alive_wolves == 0

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        """预言家死亡处理：无特殊技能。"""
        self._is_alive = False
        return None

    def get_private_context(self) -> Dict[str, Any]:
        """获取预言家的私有上下文（包括查验记录）。"""
        ctx = super().get_private_context()
        ctx["role_type"] = "seer"
        ctx["night_action"] = "check"
        return ctx
