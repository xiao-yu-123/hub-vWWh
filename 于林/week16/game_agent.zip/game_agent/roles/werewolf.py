"""狼人角色。

狼人属于邪恶阵营。每晚可以刀一名非狼人玩家。
白天可以发言、投票，也可以在投票阶段自爆（直接天黑）。
胜利条件（屠边）：所有神职死亡 或 所有村民死亡。
"""

from typing import Optional, List, Dict, Any
from roles.base import BaseRole, RoleType, Camp, NightAction, VoteAction


class Werewolf(BaseRole):

    @property
    def role_type(self) -> RoleType:
        return RoleType.WEREWOLF

    @property
    def camp(self) -> Camp:
        return Camp.EVIL

    def is_night_actionable(self) -> bool:
        return True

    def get_night_action(self, game_state: Dict[str, Any]) -> Optional[NightAction]:
        """狼人夜晚行动：选择一名非狼人存活玩家作为击杀目标。

        Args:
            game_state: 当前游戏状态，需包含:
                - alive_players: list[dict] 存活玩家列表，每个包含 player_id, role, camp
                - wolf_players: list[int] 狼人玩家ID列表（用于排除狼队友）

        Returns:
            NightAction("kill", target) 或 None（无合法目标时）
        """
        alive_players = game_state.get("alive_players", [])
        wolf_ids = game_state.get("wolf_players", [self.player_id])

        # 可选目标：存活且非狼人阵营的玩家
        valid_targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            camp = p.get("camp", "") if isinstance(p, dict) else getattr(p, "camp", "")
            if pid is not None and pid not in wolf_ids:
                valid_targets.append(pid)

        if not valid_targets:
            return None

        # 默认选择第一个合法目标（实际使用时由 Agent 决策层覆盖）
        return NightAction(action_type="kill", target=valid_targets[0])

    def get_valid_kill_targets(self, game_state: Dict[str, Any]) -> List[int]:
        """获取当前可行的击杀目标列表（供 Agent 决策层使用）。"""
        alive_players = game_state.get("alive_players", [])
        wolf_ids = game_state.get("wolf_players", [self.player_id])

        valid_targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            camp = p.get("camp", "") if isinstance(p, dict) else getattr(p, "camp", "")
            if pid is not None and pid not in wolf_ids:
                valid_targets.append(pid)
        return valid_targets

    def get_speech(self, game_state: Dict[str, Any]) -> str:
        """狼人白天发言——伪装成好人。

        Args:
            game_state: 当前游戏状态

        Returns:
            发言文本（实际使用时由 Agent 决策层生成）
        """
        return "我是好人，这轮信息不多，先听听大家怎么说。"

    def get_vote_target(self, game_state: Dict[str, Any]) -> Optional[VoteAction]:
        """狼人白天投票——投非狼人玩家以伪装。

        Args:
            game_state: 当前游戏状态

        Returns:
            VoteAction 或 None
        """
        alive_players = game_state.get("alive_players", [])
        wolf_ids = game_state.get("wolf_players", [self.player_id])

        valid_targets = []
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid not in wolf_ids:
                valid_targets.append(pid)

        if not valid_targets:
            return None
        return VoteAction(target=valid_targets[0])

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        """检查狼人阵营是否胜利（屠边规则）。

        胜利条件：所有神职死亡 或 所有村民死亡。

        Args:
            game_state: 当前游戏状态，需包含 alive_players

        Returns:
            True 如果狼人阵营胜利
        """
        alive = game_state.get("alive_players", [])

        def _get_role(p) -> str:
            return p.get("role", "") if isinstance(p, dict) else getattr(p, "role", "")

        alive_gods = sum(1 for p in alive if _get_role(p) in ("seer", "witch", "hunter"))
        alive_villagers = sum(1 for p in alive if _get_role(p) == "villager")

        return alive_gods == 0 or alive_villagers == 0

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        """狼人死亡处理：无特殊技能。"""
        self._is_alive = False
        return None

    def get_private_context(self) -> Dict[str, Any]:
        """获取狼人的私有上下文（包括狼队友信息）。"""
        ctx = super().get_private_context()
        ctx["role_type"] = "werewolf"
        ctx["night_action"] = "kill"
        return ctx
