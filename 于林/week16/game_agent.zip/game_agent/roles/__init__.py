from roles.base import BaseRole, RoleType, Camp, NightAction, VoteAction
from roles.werewolf import Werewolf
from roles.seer import Seer
from roles.witch import Witch
from roles.hunter import Hunter
from roles.villager import Villager

ROLE_REGISTRY: dict[str, type[BaseRole]] = {
    "werewolf": Werewolf,
    "seer": Seer,
    "witch": Witch,
    "hunter": Hunter,
    "villager": Villager,
}


def create_role(role_name: str, player_id: int = 0) -> BaseRole:
    cls = ROLE_REGISTRY.get(role_name)
    if cls is None:
        raise ValueError(f"Unknown role: {role_name}")
    return cls(player_id)
