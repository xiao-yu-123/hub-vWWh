"""村民角色。

村民属于好人阵营，无夜间技能。
白天通过听取发言进行逻辑推理和放逐投票。
胜利条件：所有狼人死亡。
"""

from typing import Optional, List, Dict, Any
from roles.base import BaseRole, RoleType, Camp, VoteAction


class Villager(BaseRole):

    @property
    def role_type(self) -> RoleType:
        return RoleType.VILLAGER

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    def is_night_actionable(self) -> bool:
        return False

    def get_speech(self, game_state: Dict[str, Any]) -> str:
        """村民白天发言——基于已有信息进行推理。

        Args:
            game_state: 当前游戏状态

        Returns:
            发言文本（实际使用时由 Agent 决策层生成）
        """
        return "我是村民，目前没有特殊信息，认真听发言找线索。"

    def get_vote_target(self, game_state: Dict[str, Any]) -> Optional[VoteAction]:
        """村民白天投票——投给最可疑的存活玩家。

        Args:
            game_state: 当前游戏状态，需包含 alive_players

        Returns:
            VoteAction 或 None
        """
        alive_players = game_state.get("alive_players", [])
        # 默认不投自己，选第一个其他存活玩家（实际由 Agent 决策层覆盖）
        for p in alive_players:
            pid = p.get("player_id") if isinstance(p, dict) else getattr(p, "player_id", None)
            if pid is not None and pid != self.player_id:
                return VoteAction(target=pid)
        return None

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        """检查好人阵营是否胜利。

        胜利条件：所有狼人死亡。

        Args:
            game_state: 当前游戏状态，需包含 alive_players

        Returns:
            True 如果好人阵营胜利
        """
        alive = game_state.get("alive_players", [])

        def _get_role(p) -> str:
            return p.get("role", "") if isinstance(p, dict) else getattr(p, "role", "")

        alive_wolves = sum(1 for p in alive if _get_role(p) == "werewolf")
        return alive_wolves == 0

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        """村民死亡处理：无特殊技能。"""
        self._is_alive = False
        return None

    def get_private_context(self) -> Dict[str, Any]:
        """获取村民的私有上下文。"""
        ctx = super().get_private_context()
        ctx["role_type"] = "villager"
        ctx["night_action"] = None
        return ctx
