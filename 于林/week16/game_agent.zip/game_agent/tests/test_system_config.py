"""测试系统配置加载。"""

import json
import tempfile
import pytest
from schema.system_config import (
    load_system_config, SystemConfig, LogConfig,
)


class TestLogConfig:
    def test_defaults(self):
        cfg = LogConfig()
        assert cfg.level == "INFO"
        assert cfg.console is True
        assert cfg.file is True


class TestSystemConfig:
    def test_defaults(self):
        cfg = SystemConfig()
        assert cfg.default_model == "gpt-4o"
        assert cfg.max_retries == 2
        assert isinstance(cfg.log, LogConfig)

    def test_load_from_file(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, encoding="utf-8"
        ) as f:
            json.dump({
                "model": "qwen-plus",
                "api_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
                "api_key": "sk-test",
                "max_retries": 3,
                "log": {"level": "DEBUG", "output_dir": "mylogs", "console": False, "file": True},
            }, f)

        cfg = load_system_config(f.name)
        assert cfg.default_model == "qwen-plus"
        assert cfg.api_key == "sk-test"
        assert cfg.max_retries == 3
        assert cfg.log.level == "DEBUG"
        assert cfg.log.console is False

    def test_load_missing_file_returns_defaults(self):
        cfg = load_system_config("nonexistent_config.json")
        assert cfg.default_model == "gpt-4o"

    def test_load_partial_json(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, encoding="utf-8"
        ) as f:
            json.dump({"model": "claude"}, f)

        cfg = load_system_config(f.name)
        assert cfg.default_model == "claude"
        assert cfg.max_retries == 2  # default
