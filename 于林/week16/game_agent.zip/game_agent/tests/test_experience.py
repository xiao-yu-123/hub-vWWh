"""测试跨游戏经验存储模块。"""

import tempfile
import pytest
from memory.experience import (
    Experience, ExperienceStore,
    format_experience_prompt, get_lessons_summary,
)
import memory.experience as mod


@pytest.fixture
def tmp_store():
    with tempfile.TemporaryDirectory() as tmpdir:
        store = ExperienceStore(data_dir=tmpdir)
        yield store


@pytest.fixture
def sample_exps():
    return [
        Experience(role_type="werewolf", camp="evil", winner="evil",
                   is_winner=True,
                   summary="悍跳预言家成功，带领狼队获胜。",
                   strategies="悍跳策略有效。",
                   mistakes="第2天发言有破绽。",
                   lessons="发言要前后一致，不要急于踩人。",
                   game_id="g001", player_name="玩家1"),
        Experience(role_type="werewolf", camp="evil", winner="good",
                   is_winner=False,
                   summary="被预言家首验，无力回天。",
                   strategies="尝试悍跳但失败。",
                   mistakes="晚上没有和狼队友充分沟通。",
                   lessons="首夜要充分讨论击杀目标，统一口径。",
                   game_id="g002", player_name="玩家1"),
        Experience(role_type="werewolf", camp="evil", winner="evil",
                   is_winner=True,
                   summary="低调存活到最后，配合队友完成屠边。",
                   strategies="倒钩策略有效。",
                   mistakes="前期过于低调被怀疑。",
                   lessons="适当发言减少嫌疑，保持存在感。",
                   game_id="g003", player_name="玩家2"),
    ]


class TestExperience:
    def test_create(self):
        e = Experience(role_type="werewolf", camp="evil", winner="evil",
                       is_winner=True)
        assert e.role_type == "werewolf"
        assert e.is_winner is True
        assert e.timestamp

    def test_to_dict(self):
        e = Experience(role_type="villager", camp="good", winner="good",
                       is_winner=True, summary="表现一般。",
                       lessons="多发言。", game_id="g1", player_name="P5")
        d = e.to_dict()
        assert d["role_type"] == "villager"
        assert d["game_id"] == "g1"

    def test_from_dict(self):
        d = {"role_type": "witch", "camp": "good", "winner": "good",
             "is_winner": True, "summary": "正确用药。",
             "strategies": "", "mistakes": "",
             "lessons": "保留解药给关键轮次。",
             "game_id": "g2", "player_name": "P4", "timestamp": "2026-01-01"}
        e = Experience.from_dict(d)
        assert e.role_type == "witch"
        assert e.lessons == "保留解药给关键轮次。"

    def test_roundtrip(self):
        e = Experience(role_type="hunter", camp="good", winner="evil",
                       is_winner=False, summary="被投出局，带错了人。",
                       lessons="开枪前确认目标。", game_id="g3", player_name="P6")
        assert Experience.from_dict(e.to_dict()).to_dict() == e.to_dict()


class TestExperienceStore:
    def test_save_and_load(self, tmp_store):
        e = Experience(role_type="seer", camp="good", winner="good",
                       is_winner=True, summary="发挥出色。",
                       lessons="细心查验。", game_id="g1", player_name="A")
        tmp_store.save(e)
        loaded = tmp_store.load("seer")
        assert len(loaded) == 1
        assert loaded[0].lessons == "细心查验。"

    def test_load_empty_role(self, tmp_store):
        assert tmp_store.load("werewolf") == []

    def test_save_multiple(self, tmp_store):
        for i in range(3):
            tmp_store.save(Experience(role_type="villager", camp="good",
                           winner="good", is_winner=True,
                           summary=f"第{i}局", lessons=""))
        assert len(tmp_store.load("villager")) == 3

    def test_max_limit(self, tmp_store):
        for i in range(25):
            tmp_store.save(Experience(role_type="witch", camp="good",
                           winner="good", is_winner=True,
                           summary=f"第{i}局", lessons=""))
        assert len(tmp_store.load("witch")) == 20

    def test_clear_role(self, tmp_store):
        tmp_store.save(Experience(role_type="hunter", camp="good",
                       winner="good", is_winner=True,
                       summary="", lessons=""))
        tmp_store.clear("hunter")
        assert tmp_store.load("hunter") == []

    def test_clear_all(self, tmp_store):
        for role in ["werewolf", "seer"]:
            tmp_store.save(Experience(role_type=role, camp="good",
                           winner="good", is_winner=True, summary="", lessons=""))
        tmp_store.clear()
        assert tmp_store.load("werewolf") == []
        assert tmp_store.load("seer") == []

    def test_load_all(self, tmp_store):
        tmp_store.save(Experience(role_type="werewolf", camp="evil",
                       winner="evil", is_winner=True, summary="", lessons=""))
        tmp_store.save(Experience(role_type="seer", camp="good",
                       winner="good", is_winner=True, summary="", lessons=""))
        all_exp = tmp_store.load_all()
        assert len(all_exp["werewolf"]) == 1
        assert len(all_exp["seer"]) == 1
        assert len(all_exp["villager"]) == 0


class TestFormatPrompt:
    def test_format_empty(self):
        assert format_experience_prompt("seer") == ""

    def test_format_with_experiences(self, tmp_store, sample_exps):
        for e in sample_exps:
            tmp_store.save(e)
        _swap_store(tmp_store)
        try:
            prompt = format_experience_prompt("werewolf")
            assert "历史游戏经验" in prompt
            assert "悍跳预言家成功" in prompt
        finally:
            _restore_store()

    def test_prioritizes_wins(self, tmp_store):
        for i in range(3):
            tmp_store.save(Experience(role_type="villager", camp="good",
                           winner="evil", is_winner=False,
                           summary=f"输了{i}", lessons=""))
        tmp_store.save(Experience(role_type="villager", camp="good",
                       winner="good", is_winner=True,
                       summary="唯一的胜利局", lessons="关键经验"))
        _swap_store(tmp_store)
        try:
            prompt = format_experience_prompt("villager", max_items=3)
            assert "唯一的胜利局" in prompt
        finally:
            _restore_store()


class TestLessonsSummary:
    def test_lessons_empty(self):
        assert get_lessons_summary("werewolf") == ""

    def test_lessons_summary(self, tmp_store):
        tmp_store.save(Experience(role_type="werewolf", camp="evil",
                       winner="evil", is_winner=True, summary="",
                       lessons="发言要一致"))
        tmp_store.save(Experience(role_type="werewolf", camp="evil",
                       winner="good", is_winner=False, summary="",
                       lessons="多和队友沟通"))
        _swap_store(tmp_store)
        try:
            result = get_lessons_summary("werewolf")
            assert "发言要一致" in result
            assert "多和队友沟通" in result
        finally:
            _restore_store()

    def test_deduplicate(self, tmp_store):
        for _ in range(5):
            tmp_store.save(Experience(role_type="seer", camp="good",
                           winner="good", is_winner=True, summary="",
                           lessons="不要急于跳身份"))
        _swap_store(tmp_store)
        try:
            result = get_lessons_summary("seer", top_n=5)
            assert result.count("不要急于跳身份") == 1
        finally:
            _restore_store()


# ---- helpers ----

_original_store = mod._store


def _swap_store(tmp_store):
    mod._store = tmp_store


def _restore_store():
    mod._store = _original_store
