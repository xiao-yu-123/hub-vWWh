import pytest
from roles.base import RoleType, Camp, NightAction
from roles.seer import Seer


def make_player(player_id: int, role: str) -> dict:
    return {"player_id": player_id, "role": role}


def make_game_state(alive_players: list[dict], check_history: dict = None) -> dict:
    return {
        "alive_players": alive_players,
        "check_history": check_history or {},
    }


class TestSeerBasics:
    """测试预言家基础属性"""

    def test_role_type(self):
        s = Seer(player_id=1)
        assert s.role_type == RoleType.SEER
        assert s.name == "Seer"

    def test_camp(self):
        s = Seer(player_id=1)
        assert s.camp == Camp.GOOD

    def test_is_night_actionable(self):
        s = Seer(player_id=1)
        assert s.is_night_actionable() is True

    def test_is_alive_by_default(self):
        s = Seer(player_id=1)
        assert s.is_alive is True

    def test_repr(self):
        s = Seer(player_id=2)
        r = repr(s)
        assert "Seer" in r
        assert "player_id=2" in r
        assert "alive" in r


class TestNightAction:
    """测试预言家夜晚查验"""

    def test_check_returns_valid_target(self):
        s = Seer(player_id=0)
        players = [
            make_player(0, "seer"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players)
        action = s.get_night_action(state)

        assert action is not None
        assert action.action_type == "check"
        assert action.target in (1, 2)

    def test_check_excludes_self(self):
        s = Seer(player_id=0)
        players = [
            make_player(0, "seer"),
            make_player(1, "villager"),
        ]
        state = make_game_state(players)
        action = s.get_night_action(state)

        assert action is not None
        assert action.target == 1

    def test_check_excludes_already_checked(self):
        s = Seer(player_id=0)
        players = [
            make_player(0, "seer"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players, check_history={1: "good"})
        action = s.get_night_action(state)

        assert action is not None
        assert action.target == 2

    def test_check_returns_none_when_all_checked(self):
        s = Seer(player_id=0)
        players = [
            make_player(0, "seer"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players, check_history={1: "good", 2: "evil"})
        action = s.get_night_action(state)

        assert action is None

    def test_get_valid_check_targets(self):
        s = Seer(player_id=0)
        players = [
            make_player(0, "seer"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
            make_player(3, "witch"),
            make_player(4, "hunter"),
        ]
        state = make_game_state(players, check_history={1: "good"})
        targets = s.get_valid_check_targets(state)

        assert 0 not in targets
        assert 1 not in targets
        assert 2 in targets
        assert 3 in targets
        assert 4 in targets
        assert len(targets) == 3


class TestDayActions:
    """测试预言家白天行为"""

    def test_can_speak_when_alive(self):
        s = Seer(player_id=1)
        assert s.can_speak() is True

    def test_cannot_speak_when_dead(self):
        s = Seer(player_id=1)
        s.is_alive = False
        assert s.can_speak() is False

    def test_can_vote_when_alive(self):
        s = Seer(player_id=1)
        assert s.can_vote() is True

    def test_get_speech_returns_non_empty(self):
        s = Seer(player_id=1)
        speech = s.get_speech({})
        assert isinstance(speech, str)
        assert len(speech) > 0

    def test_get_vote_target_excludes_self(self):
        s = Seer(player_id=0)
        players = [
            make_player(0, "seer"),
            make_player(1, "werewolf"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players)
        vote = s.get_vote_target(state)
        assert vote is not None
        assert vote.target != 0

    def test_get_vote_target_returns_none_when_only_self(self):
        s = Seer(player_id=0)
        state = make_game_state([make_player(0, "seer")])
        vote = s.get_vote_target(state)
        assert vote is None


class TestWinCondition:
    """测试预言家胜负判定"""

    def test_win_when_no_wolves(self):
        s = Seer(player_id=1)
        players = [
            make_player(1, "seer"),
            make_player(2, "villager"),
            make_player(3, "witch"),
        ]
        state = make_game_state(players)
        assert s.check_win(state) is True

    def test_not_win_when_wolves_alive(self):
        s = Seer(player_id=1)
        players = [
            make_player(1, "seer"),
            make_player(2, "werewolf"),
            make_player(3, "villager"),
        ]
        state = make_game_state(players)
        assert s.check_win(state) is False


class TestDeath:
    """测试预言家死亡处理"""

    def test_on_death_by_night_kill(self):
        s = Seer(player_id=1)
        s.on_death("night_kill", {})
        assert s.is_alive is False


class TestPrivateContext:
    """测试预言家私有上下文"""

    def test_get_private_context(self):
        s = Seer(player_id=3)
        ctx = s.get_private_context()
        assert ctx["role"] == "Seer"
        assert ctx["player_id"] == 3
        assert ctx["camp"] == "good"
        assert ctx["role_type"] == "seer"
        assert ctx["night_action"] == "check"
