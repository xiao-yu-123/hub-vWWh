import pytest
from roles.base import RoleType, Camp
from roles.villager import Villager


def make_player(player_id: int, role: str) -> dict:
    return {"player_id": player_id, "role": role}


def make_game_state(alive_players: list[dict]) -> dict:
    return {"alive_players": alive_players}


class TestVillagerBasics:
    """测试村民基础属性"""

    def test_role_type(self):
        v = Villager(player_id=1)
        assert v.role_type == RoleType.VILLAGER
        assert v.name == "Villager"

    def test_camp(self):
        v = Villager(player_id=1)
        assert v.camp == Camp.GOOD

    def test_is_night_actionable(self):
        v = Villager(player_id=1)
        assert v.is_night_actionable() is False

    def test_is_alive_by_default(self):
        v = Villager(player_id=1)
        assert v.is_alive is True

    def test_is_alive_setter(self):
        v = Villager(player_id=1)
        v.is_alive = False
        assert v.is_alive is False

    def test_repr(self):
        v = Villager(player_id=3)
        r = repr(v)
        assert "Villager" in r
        assert "player_id=3" in r
        assert "alive" in r


class TestDayActions:
    """测试村民白天行为"""

    def test_can_speak_when_alive(self):
        v = Villager(player_id=1)
        assert v.can_speak() is True

    def test_cannot_speak_when_dead(self):
        v = Villager(player_id=1)
        v.is_alive = False
        assert v.can_speak() is False

    def test_can_vote_when_alive(self):
        v = Villager(player_id=1)
        assert v.can_vote() is True

    def test_cannot_vote_when_dead(self):
        v = Villager(player_id=1)
        v.is_alive = False
        assert v.can_vote() is False

    def test_get_speech_returns_non_empty(self):
        v = Villager(player_id=1)
        speech = v.get_speech({})
        assert isinstance(speech, str)
        assert len(speech) > 0

    def test_get_vote_target_excludes_self(self):
        v = Villager(player_id=0)
        players = [
            make_player(0, "villager"),
            make_player(1, "werewolf"),
            make_player(2, "seer"),
        ]
        state = make_game_state(players)
        vote = v.get_vote_target(state)
        assert vote is not None
        assert vote.target != 0

    def test_get_vote_target_returns_none_when_only_self_alive(self):
        v = Villager(player_id=0)
        players = [make_player(0, "villager")]
        state = make_game_state(players)
        vote = v.get_vote_target(state)
        assert vote is None


class TestWinCondition:
    """测试村民胜负判定"""

    def test_win_when_all_wolves_dead(self):
        v = Villager(player_id=1)
        players = [
            make_player(1, "villager"),
            make_player(2, "seer"),
            make_player(3, "witch"),
        ]
        state = make_game_state(players)
        assert v.check_win(state) is True

    def test_win_when_only_villagers_alive(self):
        v = Villager(player_id=1)
        players = [
            make_player(1, "villager"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players)
        assert v.check_win(state) is True

    def test_not_win_when_wolves_alive(self):
        v = Villager(player_id=1)
        players = [
            make_player(1, "villager"),
            make_player(2, "werewolf"),
            make_player(3, "seer"),
        ]
        state = make_game_state(players)
        assert v.check_win(state) is False

    def test_not_win_when_all_dead(self):
        v = Villager(player_id=1)
        state = make_game_state([])
        assert v.check_win(state) is True  # 没有狼存活即胜利


class TestDeath:
    """测试村民死亡处理"""

    def test_on_death_by_night_kill(self):
        v = Villager(player_id=1)
        result = v.on_death("night_kill", {})
        assert v.is_alive is False
        assert result is None

    def test_on_death_by_vote(self):
        v = Villager(player_id=1)
        v.on_death("vote", {})
        assert v.is_alive is False

    def test_on_death_by_poison(self):
        v = Villager(player_id=1)
        v.on_death("poison", {})
        assert v.is_alive is False


class TestPrivateContext:
    """测试村民私有上下文"""

    def test_get_private_context(self):
        v = Villager(player_id=2)
        ctx = v.get_private_context()
        assert ctx["role"] == "Villager"
        assert ctx["player_id"] == 2
        assert ctx["camp"] == "good"
        assert ctx["role_type"] == "villager"
        assert ctx["night_action"] is None
