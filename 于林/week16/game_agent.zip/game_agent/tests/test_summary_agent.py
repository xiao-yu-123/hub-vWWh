"""测试 SummaryAgent — 玩家第一人称反思总结代理。"""

import json
import pytest
from unittest.mock import AsyncMock
from agents.summary import (
    SummaryAgent, PlayerReflection, SUMMARY_PROMPT_TEMPLATE,
)


def make_personal_history() -> str:
    return (
        "第1天夜晚：你和狼队友协商后选择击杀3号玩家（预言家）。\n"
        "第1天白天：你伪装成村民发言，表示'先听大家怎么说'。\n"
        "第1天投票：你投票放逐了5号玩家，他出局后身份是村民。\n"
        "第2天夜晚：你和狼队友决定击杀6号玩家（女巫）。\n"
        "第2天白天：2号预言家跳出来查验你为狼人，你悍跳预言家反驳。\n"
        "第2天投票：你被投票放逐出局。\n"
        "最终狼人阵营获胜。"
    )


# ---- PlayerReflection ----

class TestPlayerReflection:
    """测试 PlayerReflection 数据类"""

    def test_from_json_complete(self):
        data = {
            "summary": "整体表现尚可，成功掩护了狼队友。",
            "strategies": "使用了悍跳预言家策略，成功混淆好人视野。",
            "mistakes": "第1天发言太少，被预言家抓住把柄。",
            "lessons": "多发言，积极表现才能降低被查验的风险。",
        }
        r = PlayerReflection.from_json(data)
        assert r.summary == data["summary"]
        assert r.strategies == data["strategies"]
        assert r.mistakes == data["mistakes"]
        assert r.lessons == data["lessons"]

    def test_from_json_defaults(self):
        r = PlayerReflection.from_json({})
        assert r.summary == ""
        assert r.strategies == ""
        assert r.mistakes == ""
        assert r.lessons == ""

    def test_to_dict(self):
        r = PlayerReflection(
            summary="测试", strategies="策略",
            mistakes="错误", lessons="建议",
        )
        d = r.to_dict()
        assert d == {
            "summary": "测试", "strategies": "策略",
            "mistakes": "错误", "lessons": "建议",
        }

    def test_roundtrip(self):
        original = {
            "summary": "s", "strategies": "st",
            "mistakes": "m", "lessons": "l",
        }
        r = PlayerReflection.from_json(original)
        assert r.to_dict() == original


# ---- SummaryAgent Init ----

class TestSummaryAgentInit:
    """测试 SummaryAgent 初始化"""

    def test_init_sets_attributes(self):
        agent = SummaryAgent(
            role_name="狼人", camp_name="邪恶方",
            player_name="玩家1", winner_name="邪恶方",
            is_winner=True, personal_history="测试历史",
        )
        assert agent.role_name == "狼人"
        assert agent.camp_name == "邪恶方"
        assert agent.player_name == "玩家1"
        assert agent.winner_name == "邪恶方"
        assert agent.is_winner is True

    def test_init_sets_agent_name(self):
        agent = SummaryAgent(
            role_name="预言家", camp_name="好人方",
            player_name="玩家2", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        assert "玩家2" in agent.agent.name

    def test_init_sets_instructions(self):
        agent = SummaryAgent(
            role_name="村民", camp_name="好人方",
            player_name="玩家3", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        assert "村民" in agent.agent.instructions
        assert "好人方" in agent.agent.instructions

    def test_winner_context(self):
        agent = SummaryAgent(
            role_name="狼人", camp_name="邪恶方",
            player_name="玩家1", winner_name="邪恶方",
            is_winner=True, personal_history="",
        )
        assert agent.is_winner is True
        assert agent.winner_name == "邪恶方"

    def test_loser_context(self):
        agent = SummaryAgent(
            role_name="狼人", camp_name="邪恶方",
            player_name="玩家1", winner_name="好人方",
            is_winner=False, personal_history="",
        )
        assert agent.is_winner is False


# ---- BuildPrompt ----

class TestBuildPrompt:
    """测试 prompt 构建"""

    def test_prompt_uses_template(self):
        agent = SummaryAgent(
            role_name="预言家", camp_name="好人方",
            player_name="预言家小明", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        agent.set_personal_history("第1天查验了1号，查出狼人。")
        prompt = agent.build_prompt()
        assert "预言家" in prompt
        assert "好人方" in prompt
        assert "预言家小明" in prompt
        assert "第1天查验了1号" in prompt

    def test_winner_prompt_shows_victory(self):
        for is_win, expect in [(True, "获胜"), (False, "失败")]:
            agent = SummaryAgent(
                role_name="村民", camp_name="好人方",
                player_name="村民A", winner_name="好人方",
                is_winner=is_win, personal_history="",
            )
            agent.set_personal_history("无。")
            prompt = agent.build_prompt()
            assert expect in prompt

    def test_prompt_without_history_defaults(self):
        agent = SummaryAgent(
            role_name="猎人", camp_name="好人方",
            player_name="玩家4", winner_name="邪恶方",
            is_winner=False, personal_history="",
        )
        # 未调用 set_personal_history
        prompt = agent.build_prompt()
        assert "游戏记录为空" in prompt


# ---- ParseReflection ----

class TestParseReflection:
    """测试 LLM 输出解析"""

    def test_parse_valid_json(self):
        agent = SummaryAgent(
            role_name="狼人", camp_name="邪恶方",
            player_name="玩家1", winner_name="邪恶方",
            is_winner=True, personal_history="",
        )
        output = json.dumps({
            "summary": "本局表现良好，成功带领狼队获胜。",
            "strategies": "悍跳预言家策略有效，成功骗取好人信任。",
            "mistakes": "第2天发言露出破绽，差点被识破。",
            "lessons": "下次发言要更注意细节，避免前后矛盾。",
        }, ensure_ascii=False)
        r = agent.parse_reflection(output)
        assert "悍跳预言家" in r.strategies
        assert "细节" in r.lessons

    def test_parse_json_with_code_block(self):
        agent = SummaryAgent(
            role_name="预言家", camp_name="好人方",
            player_name="玩家2", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        data = {"summary": "S", "strategies": "ST", "mistakes": "M", "lessons": "L"}
        output = f'```json\n{json.dumps(data)}\n```'
        r = agent.parse_reflection(output)
        assert r.summary == "S"

    def test_parse_invalid_text(self):
        agent = SummaryAgent(
            role_name="村民", camp_name="好人方",
            player_name="玩家3", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        r = agent.parse_reflection("这是一段没有 JSON 的回复")
        assert "JSON 解析失败" in r.mistakes or "JSON 解析失败" in r.summary

    def test_parse_broken_json(self):
        agent = SummaryAgent(
            role_name="女巫", camp_name="好人方",
            player_name="玩家4", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        r = agent.parse_reflection("{broken")
        assert "JSON 解析失败" in r.mistakes or "JSON 解析失败" in r.summary


# ---- Summarize ----

class TestSummarize:
    """测试 summarize 异步方法"""

    @pytest.mark.asyncio
    async def test_summarize_returns_reflection(self):
        agent = SummaryAgent(
            role_name="狼人", camp_name="邪恶方",
            player_name="玩家1", winner_name="邪恶方",
            is_winner=True, personal_history="",
        )
        agent.set_personal_history("第1天刀了预言家。")
        output = json.dumps({
            "summary": "表现不错", "strategies": "悍跳有效",
            "mistakes": "无", "lessons": "继续",
        }, ensure_ascii=False)
        agent.run = AsyncMock(return_value=output)
        r = await agent.summarize()
        assert isinstance(r, PlayerReflection)
        assert r.summary == "表现不错"

    @pytest.mark.asyncio
    async def test_summarize_handles_exception(self):
        agent = SummaryAgent(
            role_name="预言家", camp_name="好人方",
            player_name="玩家2", winner_name="好人方",
            is_winner=True, personal_history="",
        )
        agent.set_personal_history("查验了1号。")
        agent.run = AsyncMock(side_effect=Exception("API Error"))
        r = await agent.summarize()
        assert isinstance(r, PlayerReflection)
        assert "失败" in r.summary

    @pytest.mark.asyncio
    async def test_summarize_uses_personal_history_in_prompt(self):
        agent = SummaryAgent(
            role_name="猎人", camp_name="好人方",
            player_name="玩家5", winner_name="邪恶方",
            is_winner=False, personal_history="",
        )
        agent.set_personal_history("被刀后开枪带走2号狼人。")
        output = json.dumps({
            "summary": "s", "strategies": "st",
            "mistakes": "m", "lessons": "l",
        })
        agent.run = AsyncMock(return_value=output)
        await agent.summarize()
        call_arg = agent.run.call_args[0][0]
        assert "猎人" in call_arg
        assert "玩家5" in call_arg
        assert "被刀后开枪带走" in call_arg
