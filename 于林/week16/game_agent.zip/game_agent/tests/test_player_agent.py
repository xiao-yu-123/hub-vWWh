import pytest
from unittest.mock import patch, AsyncMock
from agents.player_agent import (
    PlayerAgent, PlayerDecision, ROLE_INSTRUCTIONS,
)


def make_game_view(phase="speech", day_number=1, players=None,
                   speeches=None, events=None, action_space=None):
    return {
        "phase": phase,
        "day_number": day_number,
        "players": players or [
            {"player_id": 0, "name": "玩家0", "is_alive": True},
            {"player_id": 1, "name": "玩家1", "is_alive": True},
            {"player_id": 2, "name": "玩家2", "is_alive": True},
        ],
        "recent_speeches": speeches or [],
        "recent_events": events or [],
        "my_action_space": action_space or ["speak", "vote"],
    }


class TestPlayerAgentInit:
    """测试 PlayerAgent 初始化"""

    def test_init_with_werewolf(self):
        agent = PlayerAgent(player_id=0, role_type="werewolf", camp="evil")
        assert agent.player_id == 0
        assert agent.role_type == "werewolf"
        assert agent.camp == "evil"
        assert agent.player_name == "玩家0"
        assert "werewolf" in agent.agent.name

    def test_init_with_custom_name(self):
        agent = PlayerAgent(player_id=1, role_type="seer", camp="good",
                            player_name="预言家小明")
        assert agent.player_name == "预言家小明"
        assert "预言家小明" in agent.agent.name

    def test_init_with_extra_context(self):
        ctx = {"狼队友": [2, 3], "已查验": "玩家1是好人"}
        agent = PlayerAgent(player_id=0, role_type="werewolf", camp="evil",
                            extra_context=ctx)
        assert agent.extra_context == ctx

    def test_instructions_contain_role(self):
        agent = PlayerAgent(player_id=0, role_type="seer", camp="good")
        assert "预言家" in agent.agent.instructions
        assert "玩家编号是 0" in agent.agent.instructions

    def test_instructions_contain_extra_context(self):
        ctx = {"狼队友": [3]}
        agent = PlayerAgent(player_id=0, role_type="werewolf", camp="evil",
                            extra_context=ctx)
        assert "狼队友" in agent.agent.instructions
        assert "[3]" in agent.agent.instructions

    @pytest.mark.parametrize("role_type", ["werewolf", "seer", "witch", "hunter", "villager"])
    def test_all_roles_have_instructions(self, role_type):
        agent = PlayerAgent(player_id=0, role_type=role_type,
                            camp="good" if role_type != "werewolf" else "evil")
        assert ROLE_INSTRUCTIONS[role_type] in agent.agent.instructions
        assert "JSON 格式" in agent.agent.instructions


class TestBuildPrompt:
    """测试 prompt 构建"""

    def test_prompt_contains_day_and_phase(self):
        agent = PlayerAgent(player_id=1, role_type="villager", camp="good")
        view = make_game_view(phase="speech", day_number=2)
        prompt = agent.build_prompt(view)
        assert "第 2 天" in prompt
        assert "speech" in prompt

    def test_prompt_contains_players(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        view = make_game_view(players=[
            {"player_id": 0, "name": "A", "is_alive": True},
            {"player_id": 1, "name": "B", "is_alive": False},
        ])
        prompt = agent.build_prompt(view)
        assert "[0] A (存活)" in prompt
        assert "[1] B (死亡)" in prompt

    def test_prompt_contains_speeches(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        view = make_game_view(speeches=[
            {"player_id": 1, "player_name": "B", "content": "我是好人"},
            {"player_id": 2, "player_name": "C", "content": "我怀疑B"},
        ])
        prompt = agent.build_prompt(view)
        assert "我是好人" in prompt
        assert "我怀疑B" in prompt

    def test_prompt_contains_events(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        view = make_game_view(events=[
            {"event_type": "night_kill", "data": {"target": 3}},
        ])
        prompt = agent.build_prompt(view)
        assert "night_kill" in prompt

    def test_prompt_contains_action_space(self):
        agent = PlayerAgent(player_id=0, role_type="werewolf", camp="evil")
        view = make_game_view(action_space=["kill"])
        prompt = agent.build_prompt(view)
        assert "kill" in prompt


class TestParseDecision:
    """测试 LLM 输出解析"""

    def test_parse_valid_json(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        output = '{"action": "speak", "target": null, "content": "我是村民", "reason": "表水"}'
        dec = agent.parse_decision(output)
        assert dec.action == "speak"
        assert dec.target is None
        assert dec.content == "我是村民"
        assert dec.reason == "表水"

    def test_parse_json_with_code_block(self):
        agent = PlayerAgent(player_id=0, role_type="werewolf", camp="evil")
        output = '我的决策：\n```json\n{"action": "kill", "target": 3, "content": "刀3", "reason": "他是预言家"}\n```'
        dec = agent.parse_decision(output)
        assert dec.action == "kill"
        assert dec.target == 3

    def test_parse_json_with_extra_text(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        output = '我觉得。\n{"action": "vote", "target": 2, "content": "投2号", "reason": "像狼"}\n同意？'
        dec = agent.parse_decision(output)
        assert dec.action == "vote"
        assert dec.target == 2

    def test_parse_invalid_text_returns_pass(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        dec = agent.parse_decision("今天天气真好，我没什么想说的。")
        assert dec.action == "pass"
        assert "无法提取" in dec.reason

    def test_parse_broken_json_returns_pass(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        dec = agent.parse_decision("{not valid json!!!}")
        assert dec.action == "pass"
        assert "解析失败" in dec.reason

    def test_parse_json_without_code_block_marker(self):
        agent = PlayerAgent(player_id=0, role_type="seer", camp="good")
        output = '{"action":"check","target":1,"content":"查验1号","reason":"可疑"}'
        dec = agent.parse_decision(output)
        assert dec.action == "check"
        assert dec.target == 1


class TestPlayerDecision:
    """测试 PlayerDecision 数据类"""

    def test_from_json(self):
        data = {"action": "speak", "target": None, "content": "发言", "reason": "逻辑"}
        dec = PlayerDecision.from_json(data)
        assert dec.action == "speak"
        assert dec.target is None
        assert dec.content == "发言"

    def test_from_json_with_defaults(self):
        dec = PlayerDecision.from_json({})
        assert dec.action == ""
        assert dec.target is None
        assert dec.content == ""

    def test_to_dict(self):
        dec = PlayerDecision(action="kill", target=5, content="刀5", reason="怀疑神")
        d = dec.to_dict()
        assert d["action"] == "kill"
        assert d["target"] == 5
        assert d["content"] == "刀5"
        assert d["reason"] == "怀疑神"

    def test_roundtrip(self):
        original = {"action": "vote", "target": 3, "content": "投3", "reason": "像狼"}
        dec = PlayerDecision.from_json(original)
        assert dec.to_dict() == original


class TestDecide:
    """测试 decide 异步方法"""

    @pytest.mark.asyncio
    async def test_decide_returns_decision(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        view = make_game_view()
        agent.run = AsyncMock(
            return_value='{"action":"speak","target":null,"content":"我是村民","reason":"表水"}'
        )
        dec = await agent.decide(view)
        assert isinstance(dec, PlayerDecision)
        assert dec.action == "speak"

    @pytest.mark.asyncio
    async def test_decide_handles_exception(self):
        agent = PlayerAgent(player_id=0, role_type="villager", camp="good")
        view = make_game_view()
        agent.run = AsyncMock(side_effect=Exception("API error"))
        dec = await agent.decide(view)
        assert dec.action == "pass"
        assert "失败" in dec.reason

    @pytest.mark.asyncio
    async def test_decide_builds_prompt_from_view(self):
        agent = PlayerAgent(player_id=0, role_type="werewolf", camp="evil")
        view = make_game_view(phase="night_wolf", action_space=["kill"])
        agent.run = AsyncMock(
            return_value='{"action":"kill","target":3,"content":"","reason":""}'
        )
        await agent.decide(view)
        call_arg = agent.run.call_args[0][0]
        assert "night_wolf" in call_arg
        assert "kill" in call_arg
