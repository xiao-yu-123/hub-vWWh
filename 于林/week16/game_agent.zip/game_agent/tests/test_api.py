"""API 集成测试 — 使用 FastAPI TestClient 测试所有端点。"""

import pytest
from fastapi.testclient import TestClient
from api.server import app, manager, GAME_CONFIGS

client = TestClient(app)


def _clear_games():
    """清空所有对局，确保测试隔离。"""
    for gid in list(manager._games.keys()):
        del manager._games[gid]


@pytest.fixture(autouse=True)
def setup():
    _clear_games()
    yield
    _clear_games()


# ---- 健康检查 ----

class TestHealth:
    def test_health_returns_ok(self):
        resp = client.get("/")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "timestamp" in data


# ---- 配置 ----

class TestConfigs:
    def test_list_configs(self):
        resp = client.get("/configs")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        assert len(data) == 3

    def test_configs_contain_standard_6(self):
        resp = client.get("/configs")
        names = [c["name"] for c in resp.json()]
        assert "standard_6" in names

    def test_config_structure(self):
        resp = client.get("/configs")
        cfg = resp.json()[0]
        assert "name" in cfg
        assert "description" in cfg
        assert "player_count" in cfg
        assert "roles" in cfg
        assert isinstance(cfg["roles"], list)


# ---- 创建游戏 ----

class TestCreateGame:
    def test_create_with_default_config(self):
        resp = client.post("/games", json={})
        assert resp.status_code == 201
        data = resp.json()
        assert "game_id" in data
        assert data["config_name"] == "standard_6"
        assert data["day_number"] == 1
        assert data["is_game_over"] is False
        assert data["winner"] is None

    def test_create_with_specific_config(self):
        resp = client.post("/games", json={"config_name": "simple_4"})
        assert resp.status_code == 201
        assert resp.json()["config_name"] == "simple_4"

    def test_create_with_custom_names(self):
        resp = client.post("/games", json={
            "player_names": ["A", "B", "C", "D", "E", "F"],
        })
        assert resp.status_code == 201

    def test_create_with_invalid_config_returns_400(self):
        resp = client.post("/games", json={"config_name": "invalid"})
        assert resp.status_code == 400

    def test_each_creation_generates_unique_id(self):
        r1 = client.post("/games", json={})
        r2 = client.post("/games", json={})
        assert r1.json()["game_id"] != r2.json()["game_id"]


# ---- 列出游戏 ----

class TestListGames:
    def test_list_empty(self):
        resp = client.get("/games")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_list_after_create(self):
        client.post("/games", json={})
        client.post("/games", json={"config_name": "simple_4"})
        resp = client.get("/games")
        assert len(resp.json()) == 2

    def test_list_item_structure(self):
        client.post("/games", json={})
        resp = client.get("/games")
        g = resp.json()[0]
        assert "game_id" in g
        assert "config_name" in g
        assert "phase" in g
        assert "day_number" in g
        assert "alive_count" in g
        assert "player_count" in g
        assert "is_game_over" in g


# ---- 获取游戏状态 ----

class TestGetGame:
    def test_get_existing_game(self):
        r = client.post("/games", json={})
        gid = r.json()["game_id"]
        resp = client.get(f"/games/{gid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["game_id"] == gid
        assert len(data["players"]) > 0

    def test_get_admin_view_contains_roles(self):
        r = client.post("/games", json={})
        gid = r.json()["game_id"]
        resp = client.get(f"/games/{gid}")
        players = resp.json()["players"]
        # admin view should have role and side
        assert "role" in players[0]
        assert "side" in players[0]

    def test_get_nonexistent_returns_404(self):
        resp = client.get("/games/nonexistent")
        assert resp.status_code == 404

    def test_get_includes_game_metadata(self):
        r = client.post("/games", json={})
        gid = r.json()["game_id"]
        resp = client.get(f"/games/{gid}")
        data = resp.json()
        assert "event_log" in data
        assert "dialogues" in data
        assert "deaths" in data
        assert "witch_antidote_used" in data
        assert "witch_poison_used" in data
        assert "sheriff_id" in data


# ---- 阶段推进 ----

class TestStep:
    def _create_and_step(self, steps=1, config="standard_6"):
        r = client.post("/games", json={"config_name": config})
        gid = r.json()["game_id"]
        step_results = []
        for _ in range(steps):
            resp = client.post(f"/games/{gid}/step")
            step_results.append(resp)
        return gid, step_results

    def test_single_step_succeeds(self):
        _, results = self._create_and_step(steps=1)
        assert results[0].status_code == 200

    def test_step_returns_correct_structure(self):
        _, results = self._create_and_step(steps=1)
        data = results[0].json()
        assert "game_id" in data
        assert "phase" in data
        assert "phase_index" in data
        assert "day_number" in data
        assert "step_data" in data
        assert "players" in data
        assert "dialogues" in data
        assert "deaths" in data
        assert "is_game_over" in data
        assert "next_phase" in data

    def test_step_nonexistent_returns_404(self):
        resp = client.post("/games/nonexistent/step")
        assert resp.status_code == 404

    def test_phase_progresses_through_cycle(self):
        gid, results = self._create_and_step(steps=3)
        phases = [r.json()["phase"] for r in results]
        assert phases == ["night_seer", "night_witch", "night_result"]

    def test_full_cycle_returns_to_night_after_8_steps(self):
        gid, results = self._create_and_step(steps=8)
        # After full cycle: day should increase, phase back to night_wolf
        last = results[-1].json()
        assert last["phase"] == "night_wolf"
        assert last["day_number"] == 2

    def test_step_data_varies_by_phase(self):
        gid, _ = self._create_and_step(steps=0)
        # night_wolf
        r1 = client.post(f"/games/{gid}/step")
        assert "wolf_votes" in r1.json()["step_data"]
        # night_seer
        r2 = client.post(f"/games/{gid}/step")
        assert "seer_id" in r2.json()["step_data"] or "check_result" in r2.json()["step_data"]
        # night_witch
        r3 = client.post(f"/games/{gid}/step")
        assert "witch_id" in r3.json()["step_data"] or "save" in r3.json()["step_data"]

    def test_speech_phase_generates_dialogues(self):
        gid, results = self._create_and_step(steps=5)
        # After step 5, we should be at speech phase or past it
        # Step through to speech
        for _ in range(5):
            client.post(f"/games/{gid}/step")
        # Get state and check dialogues
        resp = client.get(f"/games/{gid}")
        # After multiple day cycles, there should be some dialogues
        # (may not have dialogues if speech phase hasn't happened recently)

    def test_vote_phase_includes_votes(self):
        gid, _ = self._create_and_step(steps=0)
        # Step to vote (index 6)
        for _ in range(6):
            client.post(f"/games/{gid}/step")
        r = client.post(f"/games/{gid}/step")  # vote phase
        step_data = r.json()["step_data"]
        assert "votes" in step_data
        assert "eliminated" in step_data

    def test_day_increases_after_full_cycle(self):
        gid, _ = self._create_and_step(steps=0)
        for _ in range(8):
            client.post(f"/games/{gid}/step")
        resp = client.get(f"/games/{gid}")
        assert resp.json()["day_number"] == 2


# ---- 删除游戏 ----

class TestDeleteGame:
    def test_delete_existing(self):
        r = client.post("/games", json={})
        gid = r.json()["game_id"]
        resp = client.delete(f"/games/{gid}")
        assert resp.status_code == 200
        assert resp.json()["deleted"] is True

    def test_delete_nonexistent_returns_404(self):
        resp = client.delete("/games/nonexistent")
        assert resp.status_code == 404

    def test_delete_removes_from_list(self):
        r = client.post("/games", json={})
        gid = r.json()["game_id"]
        client.delete(f"/games/{gid}")
        resp = client.get("/games")
        assert resp.json() == []


# ---- 边界情况 ----

class TestEdgeCases:
    def test_create_all_configs(self):
        for name in GAME_CONFIGS:
            resp = client.post("/games", json={"config_name": name})
            assert resp.status_code == 201

    def test_game_over_after_many_steps(self):
        """持续推进直到游戏结束。"""
        r = client.post("/games", json={"config_name": "simple_4"})
        gid = r.json()["game_id"]

        game_over = False
        for _ in range(200):  # 上限防止死循环
            resp = client.post(f"/games/{gid}/step")
            if resp.json()["is_game_over"]:
                game_over = True
                assert resp.json()["winner"] in ("good", "evil")
                break

        assert game_over, "游戏应在 200 步内结束"

    def test_step_after_game_over_returns_400(self):
        r = client.post("/games", json={"config_name": "simple_4"})
        gid = r.json()["game_id"]

        # Step to game over
        for _ in range(200):
            resp = client.post(f"/games/{gid}/step")
            if resp.json()["is_game_over"]:
                break

        # Try stepping again
        resp = client.post(f"/games/{gid}/step")
        assert resp.status_code == 400

    def test_player_count_matches_config(self):
        r = client.post("/games", json={"config_name": "big_9"})
        gid = r.json()["game_id"]
        resp = client.get(f"/games/{gid}")
        assert len(resp.json()["players"]) == 9

    def test_step_data_contains_deaths_when_applicable(self):
        """夜结果阶段应包含死亡记录。"""
        r = client.post("/games", json={"config_name": "simple_4"})
        gid = r.json()["game_id"]

        # Step: night_wolf(0) → night_seer(1) → night_witch(2) → night_result(3)
        for _ in range(3):
            client.post(f"/games/{gid}/step")
        resp = client.post(f"/games/{gid}/step")  # night_result
        # This step may or may not have deaths depending on game state
        assert resp.status_code == 200
