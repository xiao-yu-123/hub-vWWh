"""测试 game_record 和 game_logger。"""

import json
import os
import tempfile
import pytest
from schema.game_record import GameRecord
from schema.game_logger import GameLogger


class TestGameRecord:
    """测试 GameRecord 数据类"""

    def test_defaults(self):
        r = GameRecord()
        assert r.game_id == ""
        assert r.winner is None

    def test_to_dict_and_back(self):
        r = GameRecord(
            game_id="g001", config_name="standard_6",
            winner="good", total_rounds=24, total_days=3,
            players=[{"player_id": 0, "name": "玩家1", "role": "seer"}],
            event_log=[{"phase": "night_wolf", "event_type": "wolf_kill"}],
            dialogues=[{"player_id": 0, "content": "我是预言家"}],
            deaths=[{"player_id": 1, "cause": "night_kill"}],
            vote_history=[{"day": 1, "eliminated": 0}],
            sheriff_id=0,
        )
        d = r.to_dict()
        r2 = GameRecord.from_dict(d)
        assert r2.game_id == "g001"
        assert r2.winner == "good"
        assert len(r2.players) == 1
        assert len(r2.event_log) == 1
        assert r2.sheriff_id == 0

    def test_from_dict_partial(self):
        r = GameRecord.from_dict({"game_id": "g002"})
        assert r.game_id == "g002"
        assert r.winner is None
        assert r.players == []

    def test_serialize_to_file(self):
        r = GameRecord(game_id="g003", config_name="simple_4", winner="evil")
        with tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w", encoding="utf-8"
        ) as f:
            r.to_json(f.name)
            loaded = GameRecord.from_json(f.name)

        assert loaded.game_id == "g003"
        assert loaded.winner == "evil"

    def test_get_player_events(self):
        r = GameRecord(
            event_log=[
                {"phase": "night_wolf", "event_type": "wolf_kill",
                 "data": {"wolf_ids": [0, 1], "target": 3}},
                {"phase": "night_seer", "event_type": "seer_check",
                 "data": {"seer_id": 2, "target": 0}},
                {"phase": "vote", "event_type": "vote_result",
                 "data": {"eliminated": 1}},
            ]
        )
        # 玩家0 是狼，也是查验目标
        events_0 = r.get_player_events(0)
        assert len(events_0) == 2  # wolf_kill (wolf_ids) + seer_check (target)
        # 玩家2 是预言家
        events_2 = r.get_player_events(2)
        assert len(events_2) == 1  # seer_check (seer_id)

    def test_get_player_speeches(self):
        r = GameRecord(dialogues=[
            {"player_id": 0, "content": "我是村民"},
            {"player_id": 1, "content": "我是预言家"},
            {"player_id": 0, "content": "我怀疑1号"},
        ])
        speeches = r.get_player_speeches(0)
        assert len(speeches) == 2
        assert "我是村民" in speeches[0]["content"]

    def test_killer_of(self):
        r = GameRecord(deaths=[
            {"player_id": 0, "cause": "night_kill"},
            {"player_id": 1, "cause": "vote"},
        ])
        assert r.killer_of(0) == "night_kill"
        assert r.killer_of(2) is None

    def test_wolf_and_god_players(self):
        r = GameRecord(players=[
            {"player_id": 0, "role": "werewolf"},
            {"player_id": 1, "role": "seer"},
            {"player_id": 2, "role": "witch"},
            {"player_id": 3, "role": "hunter"},
            {"player_id": 4, "role": "villager"},
        ])
        assert len(r.wolf_players) == 1
        assert len(r.god_players) == 3

    def test_from_game_state_integration(self):
        """验证从 GameState 构建 GameRecord。"""
        from engine.game_engine import GameEngine
        e = GameEngine("simple_4", shuffle=False)

        # 推进几轮
        for _ in range(4):
            e.step()

        record = GameRecord.from_game_state(e.state, e.game_id, e.config_name)
        assert record.game_id == e.game_id
        assert record.config_name == "simple_4"
        assert len(record.players) == 4
        assert len(record.event_log) > 0


class TestGameLogger:
    """测试游戏日志记录器"""

    def test_logger_file_output(self):
        with tempfile.NamedTemporaryFile(
            suffix=".log", delete=False, mode="w", encoding="utf-8"
        ) as f:
            log = GameLogger(filepath=f.name, console=False)
            log.phase_start("night_wolf", 1)
            log.player_action(0, "kill", target=3, reason="他是预言家")
            log.death(3, "玩家4", "night_kill")
            log.game_over("evil", day=2)
            log.close()

        with open(f.name, "r", encoding="utf-8") as f:
            lines = f.readlines()
        assert len(lines) == 4
        for line in lines:
            record = json.loads(line)
            assert "time" in record
            assert "tag" in record
            assert "message" in record

    def test_logger_console_no_crash(self):
        """确保控制台输出不抛异常。"""
        log = GameLogger(console=True)
        log.phase_start("speech", 1)
        log.speech(0, "玩家1", "我是好人")
        log.vote_result([], {0: 1}, eliminated=0)
        log.error("测试错误")
        log.close()

    def test_logger_special_events(self):
        with tempfile.NamedTemporaryFile(
            suffix=".log", delete=False, mode="w", encoding="utf-8"
        ) as f:
            log = GameLogger(filepath=f.name, console=False)
            log.witch_save(3)
            log.hunter_shoot(4, 1)
            log.seer_check(2, 1, "evil")
            log.info("游戏正常")
            log.close()

        with open(f.name, "r", encoding="utf-8") as f:
            lines = f.readlines()
        assert len(lines) == 4

    def test_logger_phase_start_with_message(self):
        with tempfile.NamedTemporaryFile(
            suffix=".log", delete=False, mode="w", encoding="utf-8"
        ) as f:
            log = GameLogger(filepath=f.name, console=False)
            log.phase_start("night_wolf", 2, "狼人请行动")
            log.phase_end("night_wolf", 2, {"final_target": 3})
            log.close()

        with open(f.name, "r", encoding="utf-8") as f:
            lines = f.readlines()
        assert len(lines) == 2
