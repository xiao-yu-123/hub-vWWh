"""测试 BaseAgent — Agent SDK 桥接层。"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from agents.base import BaseAgent


class TestBaseAgentInit:
    """测试 BaseAgent 初始化"""

    def test_init_creates_agent(self):
        agent = BaseAgent()
        assert agent.agent is not None

    def test_agent_has_name(self):
        agent = BaseAgent()
        assert hasattr(agent.agent, 'name')

    def test_agent_has_model(self):
        agent = BaseAgent()
        assert hasattr(agent.agent, 'model')

    def test_agent_has_instructions(self):
        agent = BaseAgent()
        assert hasattr(agent.agent, 'instructions')
        assert agent.agent.instructions == "你好"


class TestBaseAgentRun:
    """测试 BaseAgent.run 异步方法"""

    @pytest.mark.asyncio
    async def test_run_returns_string(self):
        agent = BaseAgent()
        mock_result = MagicMock()
        mock_result.final_output = "测试输出"

        with patch("agents.base.Runner") as mock_runner:
            mock_runner.run = AsyncMock(return_value=mock_result)
            output = await agent.run("你好")
            assert output == "测试输出"

    @pytest.mark.asyncio
    async def test_run_passes_input_to_runner(self):
        agent = BaseAgent()
        mock_result = MagicMock()
        mock_result.final_output = "result"

        with patch("agents.base.Runner") as mock_runner:
            mock_runner.run = AsyncMock(return_value=mock_result)
            await agent.run("查验3号")

            call_args = mock_runner.run.call_args
            # Runner.run(self.agent, input)
            assert call_args[0][0] == agent.agent
            assert call_args[0][1] == "查验3号"

    @pytest.mark.asyncio
    async def test_multiple_agents_independent(self):
        a1 = BaseAgent()
        a2 = BaseAgent()
        # 两个 agent 是不同实例
        assert a1.agent is not a2.agent

    @pytest.mark.asyncio
    async def test_run_handles_exception(self):
        agent = BaseAgent()
        with patch("agents.base.Runner") as mock_runner:
            mock_runner.run = AsyncMock(side_effect=Exception("API Error"))
            with pytest.raises(Exception, match="API Error"):
                await agent.run("test")
