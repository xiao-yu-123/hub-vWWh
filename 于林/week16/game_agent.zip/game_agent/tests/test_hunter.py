import pytest
from roles.base import RoleType, Camp
from roles.hunter import Hunter


def make_player(player_id: int, role: str) -> dict:
    return {"player_id": player_id, "role": role}


def make_game_state(alive_players: list[dict]) -> dict:
    return {"alive_players": alive_players}


class TestHunterBasics:
    """测试猎人基础属性"""

    def test_role_type(self):
        h = Hunter(player_id=1)
        assert h.role_type == RoleType.HUNTER
        assert h.name == "Hunter"

    def test_camp(self):
        h = Hunter(player_id=1)
        assert h.camp == Camp.GOOD

    def test_is_night_actionable(self):
        h = Hunter(player_id=1)
        assert h.is_night_actionable() is False

    def test_is_alive_by_default(self):
        h = Hunter(player_id=1)
        assert h.is_alive is True

    def test_repr(self):
        h = Hunter(player_id=2)
        r = repr(h)
        assert "Hunter" in r
        assert "player_id=2" in r
        assert "alive" in r


class TestDayActions:
    """测试猎人白天行为"""

    def test_can_speak_when_alive(self):
        h = Hunter(player_id=1)
        assert h.can_speak() is True

    def test_cannot_speak_when_dead(self):
        h = Hunter(player_id=1)
        h.is_alive = False
        assert h.can_speak() is False

    def test_can_vote_when_alive(self):
        h = Hunter(player_id=1)
        assert h.can_vote() is True

    def test_get_speech_returns_non_empty(self):
        h = Hunter(player_id=1)
        speech = h.get_speech({})
        assert isinstance(speech, str)
        assert len(speech) > 0

    def test_get_vote_target_excludes_self(self):
        h = Hunter(player_id=0)
        players = [
            make_player(0, "hunter"),
            make_player(1, "werewolf"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players)
        vote = h.get_vote_target(state)
        assert vote is not None
        assert vote.target != 0

    def test_get_vote_target_returns_none_when_only_self(self):
        h = Hunter(player_id=0)
        state = make_game_state([make_player(0, "hunter")])
        vote = h.get_vote_target(state)
        assert vote is None


class TestShootTargets:
    """测试猎人开枪目标选择"""

    def test_get_valid_shoot_targets_excludes_self(self):
        h = Hunter(player_id=0)
        players = [
            make_player(0, "hunter"),
            make_player(1, "werewolf"),
            make_player(2, "seer"),
            make_player(3, "villager"),
        ]
        state = make_game_state(players)
        targets = h.get_valid_shoot_targets(state)
        assert 0 not in targets
        assert 1 in targets
        assert 2 in targets
        assert 3 in targets
        assert len(targets) == 3

    def test_get_valid_shoot_targets_empty_when_only_self(self):
        h = Hunter(player_id=0)
        state = make_game_state([make_player(0, "hunter")])
        targets = h.get_valid_shoot_targets(state)
        assert targets == []


class TestOnDeath:
    """测试猎人死亡触发技能"""

    def test_death_by_night_kill_can_shoot(self):
        h = Hunter(player_id=0)
        players = [
            make_player(0, "hunter"),
            make_player(1, "werewolf"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players)
        result = h.on_death("night_kill", state)

        assert h.is_alive is False
        assert result is not None
        assert len(result) == 1
        assert result[0] in (1, 2)

    def test_death_by_vote_can_shoot(self):
        h = Hunter(player_id=0)
        players = [
            make_player(0, "hunter"),
            make_player(1, "werewolf"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players)
        result = h.on_death("vote", state)

        assert h.is_alive is False
        assert result is not None
        assert len(result) == 1

    def test_death_by_poison_cannot_shoot(self):
        h = Hunter(player_id=0)
        players = [
            make_player(0, "hunter"),
            make_player(1, "werewolf"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players)
        result = h.on_death("poison", state)

        assert h.is_alive is False
        assert result is None  # 闷枪

    def test_death_by_night_kill_no_targets_returns_none(self):
        h = Hunter(player_id=0)
        state = make_game_state([make_player(0, "hunter")])
        result = h.on_death("night_kill", state)

        assert h.is_alive is False
        assert result is None  # 没有可射击的目标

    def test_death_does_not_shoot_self(self):
        h = Hunter(player_id=0)
        players = [
            make_player(0, "hunter"),
            make_player(1, "werewolf"),
        ]
        state = make_game_state(players)
        result = h.on_death("vote", state)

        assert result is not None
        assert 0 not in result  # 不能带自己


class TestWinCondition:
    """测试猎人胜负判定"""

    def test_win_when_no_wolves(self):
        h = Hunter(player_id=1)
        players = [
            make_player(1, "hunter"),
            make_player(2, "villager"),
            make_player(3, "seer"),
        ]
        state = make_game_state(players)
        assert h.check_win(state) is True

    def test_not_win_when_wolves_alive(self):
        h = Hunter(player_id=1)
        players = [
            make_player(1, "hunter"),
            make_player(2, "werewolf"),
            make_player(3, "villager"),
        ]
        state = make_game_state(players)
        assert h.check_win(state) is False


class TestPrivateContext:
    """测试猎人私有上下文"""

    def test_get_private_context(self):
        h = Hunter(player_id=3)
        ctx = h.get_private_context()
        assert ctx["role"] == "Hunter"
        assert ctx["player_id"] == 3
        assert ctx["camp"] == "good"
        assert ctx["role_type"] == "hunter"
        assert ctx["night_action"] is None
        assert ctx["death_ability"] == "shoot"
