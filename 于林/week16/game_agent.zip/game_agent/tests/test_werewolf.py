import pytest
from roles.base import RoleType, Camp, NightAction, VoteAction
from roles.werewolf import Werewolf


def make_player(player_id: int, role: str, camp: str) -> dict:
    return {"player_id": player_id, "role": role, "camp": camp}


def make_game_state(alive_players: list[dict], wolf_players: list[int] = None) -> dict:
    return {
        "alive_players": alive_players,
        "wolf_players": wolf_players or [],
    }


class TestWerewolfBasics:
    """测试狼人基础属性"""

    def test_role_type(self):
        w = Werewolf(player_id=1)
        assert w.role_type == RoleType.WEREWOLF
        assert w.name == "Werewolf"

    def test_camp(self):
        w = Werewolf(player_id=1)
        assert w.camp == Camp.EVIL

    def test_is_night_actionable(self):
        w = Werewolf(player_id=1)
        assert w.is_night_actionable() is True

    def test_is_alive_by_default(self):
        w = Werewolf(player_id=1)
        assert w.is_alive is True

    def test_is_alive_setter(self):
        w = Werewolf(player_id=1)
        w.is_alive = False
        assert w.is_alive is False

    def test_repr(self):
        w = Werewolf(player_id=2)
        r = repr(w)
        assert "Werewolf" in r
        assert "player_id=2" in r
        assert "alive" in r


class TestNightAction:
    """测试狼人夜晚行动"""

    def test_kill_returns_valid_target(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "villager", "good"),
            make_player(2, "seer", "good"),
        ]
        state = make_game_state(players, wolf_players=[0])
        action = w.get_night_action(state)

        assert action is not None
        assert action.action_type == "kill"
        assert action.target in (1, 2)

    def test_kill_excludes_wolf_teammates(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "werewolf", "evil"),
            make_player(2, "villager", "good"),
        ]
        state = make_game_state(players, wolf_players=[0, 1])
        action = w.get_night_action(state)

        assert action is not None
        assert action.target == 2

    def test_kill_returns_none_when_no_valid_targets(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "werewolf", "evil"),
        ]
        state = make_game_state(players, wolf_players=[0, 1])
        action = w.get_night_action(state)

        assert action is None

    def test_get_valid_kill_targets(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "villager", "good"),
            make_player(2, "seer", "good"),
            make_player(3, "werewolf", "evil"),
            make_player(4, "hunter", "good"),
        ]
        state = make_game_state(players, wolf_players=[0, 3])
        targets = w.get_valid_kill_targets(state)

        assert 1 in targets
        assert 2 in targets
        assert 4 in targets
        assert 0 not in targets
        assert 3 not in targets
        assert len(targets) == 3


class TestDayActions:
    """测试狼人白天行为"""

    def test_can_speak_when_alive(self):
        w = Werewolf(player_id=1)
        assert w.can_speak() is True

    def test_cannot_speak_when_dead(self):
        w = Werewolf(player_id=1)
        w.is_alive = False
        assert w.can_speak() is False

    def test_can_vote_when_alive(self):
        w = Werewolf(player_id=1)
        assert w.can_vote() is True

    def test_cannot_vote_when_dead(self):
        w = Werewolf(player_id=1)
        w.is_alive = False
        assert w.can_vote() is False

    def test_get_speech_returns_non_empty(self):
        w = Werewolf(player_id=1)
        speech = w.get_speech({})
        assert isinstance(speech, str)
        assert len(speech) > 0

    def test_get_vote_target_prefers_non_wolf(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "werewolf", "evil"),
            make_player(2, "villager", "good"),
        ]
        state = make_game_state(players, wolf_players=[0, 1])
        vote = w.get_vote_target(state)
        assert vote is not None
        assert vote.target == 2

    def test_get_vote_target_returns_none_when_no_targets(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "werewolf", "evil"),
        ]
        state = make_game_state(players, wolf_players=[0, 1])
        vote = w.get_vote_target(state)
        assert vote is None


class TestWinCondition:
    """测试狼人阵营胜负判定（屠边规则）"""

    def test_win_when_all_gods_dead(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "villager", "good"),
            make_player(2, "villager", "good"),
        ]
        state = make_game_state(players, wolf_players=[0])
        assert w.check_win(state) is True

    def test_win_when_all_villagers_dead(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "seer", "good"),
            make_player(2, "hunter", "good"),
        ]
        state = make_game_state(players, wolf_players=[0])
        assert w.check_win(state) is True

    def test_not_win_when_gods_and_villagers_alive(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "seer", "good"),
            make_player(2, "villager", "good"),
        ]
        state = make_game_state(players, wolf_players=[0])
        assert w.check_win(state) is False

    def test_not_win_when_witch_alive_and_villager_alive(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "witch", "good"),
            make_player(2, "villager", "good"),
        ]
        state = make_game_state(players, wolf_players=[0])
        assert w.check_win(state) is False

    def test_win_when_only_wolves_alive(self):
        w = Werewolf(player_id=0)
        players = [
            make_player(0, "werewolf", "evil"),
            make_player(1, "werewolf", "evil"),
        ]
        state = make_game_state(players, wolf_players=[0, 1])
        assert w.check_win(state) is True


class TestDeath:
    """测试狼人死亡处理"""

    def test_on_death_sets_is_alive_false(self):
        w = Werewolf(player_id=1)
        result = w.on_death("night_kill", {})
        assert w.is_alive is False
        assert result is None

    def test_on_death_by_vote(self):
        w = Werewolf(player_id=1)
        w.on_death("vote", {})
        assert w.is_alive is False


class TestPrivateContext:
    """测试狼人私有上下文"""

    def test_get_private_context(self):
        w = Werewolf(player_id=1)
        ctx = w.get_private_context()
        assert ctx["role"] == "Werewolf"
        assert ctx["player_id"] == 1
        assert ctx["camp"] == "evil"
        assert ctx["role_type"] == "werewolf"
        assert ctx["night_action"] == "kill"
