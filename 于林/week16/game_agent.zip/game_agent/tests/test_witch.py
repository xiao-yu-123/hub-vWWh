import pytest
from roles.base import RoleType, Camp, NightAction
from roles.witch import Witch


def make_player(player_id: int, role: str) -> dict:
    return {"player_id": player_id, "role": role}


def make_game_state(alive_players: list[dict], night_kill_target: int = None) -> dict:
    return {
        "alive_players": alive_players,
        "night_kill_target": night_kill_target,
    }


class TestWitchBasics:
    """测试女巫基础属性"""

    def test_role_type(self):
        w = Witch(player_id=1)
        assert w.role_type == RoleType.WITCH
        assert w.name == "Witch"

    def test_camp(self):
        w = Witch(player_id=1)
        assert w.camp == Camp.GOOD

    def test_is_night_actionable_initially(self):
        w = Witch(player_id=1)
        assert w.is_night_actionable() is True

    def test_both_potions_available_initially(self):
        w = Witch(player_id=1)
        assert w.antidote_used is False
        assert w.poison_used is False

    def test_repr(self):
        w = Witch(player_id=2)
        r = repr(w)
        assert "Witch" in r
        assert "player_id=2" in r
        assert "alive" in r


class TestAvailableActions:
    """测试女巫可用行动列表"""

    def test_save_available_when_someone_killed(self):
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert "save" in actions
        assert "poison" in actions

    def test_save_and_poison_mutually_exclusive(self):
        """单夜不能双药同用：两药都在时返回两个选项但只能选一个"""
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert set(actions) == {"save", "poison"}

    def test_cannot_save_self(self):
        w = Witch(player_id=1)
        players = [
            make_player(1, "witch"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert "save" not in actions
        assert actions == ["poison"]

    def test_save_unavailable_when_nobody_killed(self):
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
        ]
        state = make_game_state(players, night_kill_target=None)
        actions = w.get_available_actions(state)
        assert "save" not in actions
        assert actions == ["poison"]

    def test_only_save_when_poison_used(self):
        w = Witch(player_id=0)
        w.use_poison()
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert actions == ["save"]
        assert "poison" not in actions

    def test_only_poison_when_antidote_used(self):
        w = Witch(player_id=0)
        w.use_antidote()
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert actions == ["poison"]

    def test_pass_when_both_used(self):
        w = Witch(player_id=0)
        w.use_antidote()
        w.use_poison()
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert actions == ["pass"]

    def test_is_night_actionable_false_when_both_used(self):
        w = Witch(player_id=0)
        w.use_antidote()
        w.use_poison()
        assert w.is_night_actionable() is False

    def test_cannot_save_when_night_kill_is_witch_self(self):
        w = Witch(player_id=1)
        players = [
            make_player(1, "witch"),
            make_player(2, "villager"),
        ]
        state = make_game_state(players, night_kill_target=1)
        actions = w.get_available_actions(state)
        assert "save" not in actions


class TestNightAction:
    """测试女巫夜晚行动返回"""

    def test_night_action_is_save_when_available(self):
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
        ]
        state = make_game_state(players, night_kill_target=1)
        action = w.get_night_action(state)

        assert action is not None
        assert action.action_type == "save"
        assert action.target == 1

    def test_night_action_is_poison_when_no_kill(self):
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "villager"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players, night_kill_target=None)
        action = w.get_night_action(state)

        assert action is not None
        assert action.action_type == "poison"
        assert action.target != 0

    def test_night_action_returns_none_when_both_used(self):
        w = Witch(player_id=0)
        w.use_antidote()
        w.use_poison()
        players = [make_player(0, "witch"), make_player(1, "villager")]
        state = make_game_state(players, night_kill_target=1)
        action = w.get_night_action(state)

        assert action is None


class TestPoisonTargets:
    """测试毒药目标选择"""

    def test_poison_targets_exclude_self(self):
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "werewolf"),
            make_player(2, "villager"),
            make_player(3, "seer"),
        ]
        state = make_game_state(players)
        targets = w.get_valid_poison_targets(state)
        assert 0 not in targets
        assert 1 in targets
        assert 2 in targets
        assert 3 in targets
        assert len(targets) == 3

    def test_poison_targets_empty_when_only_self(self):
        w = Witch(player_id=0)
        state = make_game_state([make_player(0, "witch")])
        targets = w.get_valid_poison_targets(state)
        assert targets == []


class TestPotionUsage:
    """测试药品使用标记"""

    def test_use_antidote(self):
        w = Witch(player_id=1)
        assert w.antidote_used is False
        w.use_antidote()
        assert w.antidote_used is True

    def test_use_poison(self):
        w = Witch(player_id=1)
        assert w.poison_used is False
        w.use_poison()
        assert w.poison_used is True

    def test_potions_are_single_use(self):
        w = Witch(player_id=1)
        w.use_antidote()
        w.use_antidote()  # 重复使用无额外效果
        assert w.antidote_used is True


class TestDayActions:
    """测试女巫白天行为"""

    def test_can_speak_when_alive(self):
        w = Witch(player_id=1)
        assert w.can_speak() is True

    def test_get_speech_returns_non_empty(self):
        w = Witch(player_id=1)
        speech = w.get_speech({})
        assert isinstance(speech, str)
        assert len(speech) > 0

    def test_get_vote_target_excludes_self(self):
        w = Witch(player_id=0)
        players = [
            make_player(0, "witch"),
            make_player(1, "werewolf"),
        ]
        state = make_game_state(players)
        vote = w.get_vote_target(state)
        assert vote is not None
        assert vote.target == 1


class TestWinCondition:
    """测试女巫胜负判定"""

    def test_win_when_no_wolves(self):
        w = Witch(player_id=1)
        players = [
            make_player(1, "witch"),
            make_player(2, "villager"),
            make_player(3, "hunter"),
        ]
        state = make_game_state(players)
        assert w.check_win(state) is True

    def test_not_win_when_wolves_alive(self):
        w = Witch(player_id=1)
        players = [
            make_player(1, "witch"),
            make_player(2, "werewolf"),
        ]
        state = make_game_state(players)
        assert w.check_win(state) is False


class TestDeath:
    """测试女巫死亡处理"""

    def test_on_death(self):
        w = Witch(player_id=1)
        w.on_death("night_kill", {})
        assert w.is_alive is False


class TestPrivateContext:
    """测试女巫私有上下文"""

    def test_get_private_context(self):
        w = Witch(player_id=3)
        ctx = w.get_private_context()
        assert ctx["role"] == "Witch"
        assert ctx["player_id"] == 3
        assert ctx["camp"] == "good"
        assert ctx["role_type"] == "witch"
        assert ctx["antidote_used"] is False
        assert ctx["poison_used"] is False

    def test_private_context_reflects_used_potions(self):
        w = Witch(player_id=3)
        w.use_antidote()
        ctx = w.get_private_context()
        assert ctx["antidote_used"] is True
        assert ctx["poison_used"] is False
