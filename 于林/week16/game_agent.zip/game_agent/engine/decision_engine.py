"""智能默认决策引擎。

为各角色/阶段提供有策略性的默认决策，替代"选第一个"的确定性行为。
决策风格 (balanced / bold / cautious / random) 影响目标选择和发言内容。

核心策略：
- 狼人：优先刀神职（预言家 > 女巫 > 猎人），其次刀高调发言者
- 预言家：优先查验发言可疑的玩家，新玩家 > 老玩家
- 女巫：谨慎型默认救人，大胆型不救留药毒人
- 猎人：优先开枪带狼人面相的玩家
- 投票：根据发言内容判断，倾向放逐可疑玩家
"""

import random
from typing import Optional, List, Dict, Any


def weighted_choice(candidates: List[int],
                    weights: Optional[List[float]] = None,
                    style: str = "balanced",
                    rng: Optional[random.Random] = None) -> Optional[int]:
    """按权重随机选一个候选。如果没有候选则返回 None。

    Args:
        candidates: 候选目标 ID 列表
        weights: 对应权重（越高越优先），None 则等权
        style: 决策风格。random 忽略权重等概率
        rng: 随机数生成器
    """
    if not candidates:
        return None
    r = rng or random
    if style == "random":
        return r.choice(candidates)
    if weights is None:
        weights = [1.0] * len(candidates)
    total = sum(weights)
    if total <= 0:
        return r.choice(candidates)
    pick = r.random() * total
    acc = 0.0
    for c, w in zip(candidates, weights):
        acc += w
        if pick <= acc:
            return c
    return candidates[-1]


class DecisionEngine:
    """为各角色/阶段生成有策略性的默认决策。

    用法：
        de = DecisionEngine(styles={"0": "bold", "1": "cautious"})
        target = de.wolf_kill_target(alive_players, wolf_players, rng)
    """

    ROLE_PRIORITY = {"seer": 10, "witch": 8, "hunter": 6, "villager": 2}
    GOD_ROLES = {"seer", "witch", "hunter"}

    def __init__(self, player_styles: Dict[str, str] = None, seed: int = None):
        self.styles = player_styles or {}
        self.rng = random.Random(seed)
        self._speech_count: Dict[int, int] = {}  # 发言次数统计

    def style_of(self, player_id) -> str:
        return self.styles.get(str(player_id), "balanced")

    # ================================================================
    # 狼人选杀目标
    # ================================================================

    def wolf_kill_target(self, alive_players: List[dict],
                         wolf_ids: List[int]) -> Optional[int]:
        """狼人选击杀目标：优先神职 > 高调发言者 > 随机。

        决策风格影响：
        - bold: 高权重优先神职
        - cautious: 优先低调的（发言少的）
        - random: 等概率
        """
        # 可选目标：存活非狼
        candidates = [p for p in alive_players
                      if p.get("player_id") not in wolf_ids]
        if not candidates:
            return None

        wolf_style = self.styles.get(str(wolf_ids[0]), "balanced")

        if wolf_style == "random":
            return self.rng.choice(candidates)["player_id"]

        weights = []
        for p in candidates:
            w = 1.0
            role = p.get("role", "")
            # 神职高权重
            if role in self.GOD_ROLES:
                w = self.ROLE_PRIORITY.get(role, 5) if wolf_style == "bold" else self.ROLE_PRIORITY.get(role, 5) * 0.7
            # 发言多 → 更可疑/更危险
            pid = p["player_id"]
            speech_n = self._speech_count.get(pid, 0)
            if wolf_style == "bold":
                w += speech_n * 1.5  # 大胆型喜欢刀话多的（可能是神）
            else:
                w += speech_n * 0.5
            if wolf_style == "cautious":
                w += self.rng.uniform(-2, 2)  # 谨慎型加噪声
            weights.append(max(0.1, w))

        return weighted_choice([c["player_id"] for c in candidates], weights, wolf_style, self.rng)

    # ================================================================
    # 预言家查验目标
    # ================================================================

    def seer_check_target(self, alive_players: List[dict],
                          seer_id: int, checked_ids: set) -> Optional[int]:
        """预言家查验目标：优先查验话多的、新出现的。

        策略：优先查验还没查过的、发言异常的玩家。
        bold: 查验话最多的
        cautious: 查验话最少的
        """
        candidates = [p for p in alive_players
                      if p["player_id"] != seer_id
                      and p["player_id"] not in checked_ids]
        if not candidates:
            return None

        seer_style = self.style_of(seer_id)

        if seer_style == "random":
            return self.rng.choice(candidates)["player_id"]

        weights = []
        for p in candidates:
            pid = p["player_id"]
            speech_n = self._speech_count.get(pid, 0)
            w = 1.0 + speech_n * 0.3
            if seer_style == "bold":
                w += speech_n * 1.0  # 查验话多的
            elif seer_style == "cautious":
                w = max(0.5, 3.0 - speech_n * 0.5)  # 查验话少的（低调可疑）
            w += self.rng.uniform(-0.5, 0.5)
            weights.append(max(0.1, w))

        return weighted_choice([c["player_id"] for c in candidates], weights, seer_style, self.rng)

    # ================================================================
    # 女巫用药
    # ================================================================

    def witch_should_save(self, kill_target: int, witch_id: int,
                          witch_style: str = "balanced") -> bool:
        """女巫是否用解药。

        bold: 不救自己以外的但有概率不救来留药毒人
        cautious: 晚上被刀就救（只要不是自己）
        balanced: 大概率救
        """
        if kill_target is None or kill_target == witch_id:
            return False
        probs = {"bold": 0.4, "balanced": 0.85, "cautious": 0.95, "random": 0.5}
        return self.rng.random() < probs.get(witch_style, 0.8)

    def witch_poison_target(self, alive_players: List[dict],
                            witch_id: int,
                            witch_style: str = "balanced") -> Optional[int]:
        """女巫毒杀目标。

        bold: 有概率毒看起来像狼的发言多的
        cautious: 几乎不用毒
        balanced: 小概率毒
        """
        probs = {"bold": 0.35, "balanced": 0.08, "cautious": 0.02, "random": 0.2}
        if self.rng.random() > probs.get(witch_style, 0.1):
            return None

        candidates = [p for p in alive_players
                      if p["player_id"] != witch_id]
        if not candidates:
            return None

        if witch_style == "random":
            return self.rng.choice(candidates)["player_id"]

        # 优先毒话多的（可能是狼在带节奏）
        weights = []
        for p in candidates:
            speech_n = self._speech_count.get(p["player_id"], 0)
            w = 1.0 + speech_n * 0.5 + self.rng.uniform(-1, 1)
            weights.append(max(0.1, w))

        return weighted_choice([c["player_id"] for c in candidates], weights, witch_style, self.rng)

    # ================================================================
    # 猎人开枪
    # ================================================================

    def hunter_shoot_target(self, alive_players: List[dict],
                            hunter_id: int) -> Optional[int]:
        """猎人开枪目标：优先带话多的/可疑的。

        bold: 大胆带人，优先带话多的
        cautious: 谨慎带人，优先带话少的（避免带错神）
        """
        candidates = [p for p in alive_players
                      if p["player_id"] != hunter_id]
        if not candidates:
            return None

        style = self.style_of(hunter_id)

        if style == "random":
            return self.rng.choice(candidates)["player_id"]

        weights = []
        for p in candidates:
            speech_n = self._speech_count.get(p["player_id"], 0)
            w = 1.0
            if style == "bold":
                w += speech_n * 1.0
            elif style == "cautious":
                w = max(0.5, 3.0 - speech_n * 0.5)
            w += self.rng.uniform(-0.5, 0.5)
            weights.append(max(0.1, w))

        return weighted_choice([c["player_id"] for c in candidates], weights, style, self.rng)

    # ================================================================
    # 投票
    # ================================================================

    def vote_target(self, alive_players: List[dict],
                    voter_id: int,
                    recent_speeches: List[dict] = None) -> Optional[int]:
        """投票放逐目标。

        bold: 投发言最多的（带节奏/可疑）
        cautious: 随大流倾向
        random: 随便投
        """
        candidates = [p for p in alive_players
                      if p["player_id"] != voter_id]
        if not candidates:
            return None

        style = self.style_of(voter_id)

        if style == "random":
            return self.rng.choice(candidates)["player_id"]

        weights = []
        for p in candidates:
            pid = p["player_id"]
            speech_n = self._speech_count.get(pid, 0)
            w = 1.0 + speech_n * 0.3
            if style == "bold":
                w += speech_n * 0.8
            elif style == "cautious":
                w = max(0.5, 3.0 - speech_n * 0.3)
            w += self.rng.uniform(-1, 1)
            weights.append(max(0.1, w))

        return weighted_choice([c["player_id"] for c in candidates], weights, style, self.rng)

    # ================================================================
    # 发言生成
    # ================================================================

    def generate_speech(self, player: dict, day: int,
                        check_results: dict = None,
                        known_wolves: List[int] = None) -> str:
        """生成符合角色身份的发言内容。

        Args:
            player: 玩家信息 {player_id, name, role, side}
            day: 当前天数
            check_results: 预言家查验结果 {pid: "good"/"evil"}
            known_wolves: 狼人的狼队友 ID 列表
        """
        role = player["role"]
        name = player["name"]
        pid = player["player_id"]
        style = self.style_of(pid)

        self._speech_count[pid] = self._speech_count.get(pid, 0) + 1

        if role == "werewolf":
            return self._werewolf_speech(name, day, style, known_wolves or [])
        elif role == "seer":
            return self._seer_speech(name, day, style, check_results or {})
        elif role == "witch":
            return self._witch_speech(name, day, style)
        elif role == "hunter":
            return self._hunter_speech(name, day, style)
        else:
            return self._villager_speech(name, day, style)

    def _werewolf_speech(self, name: str, day: int, style: str,
                         teammates: List[int]) -> str:
        """狼人伪装发言。"""
        if day == 1:
            templates = {
                "bold": [
                    f"我是{name}，第一天信息不多，先听听看。不过我注意到有几个人发言很奇怪。",
                    f"{name}在这里，目前看不出什么，但我怀疑预言家可能已经查到了什么，希望预言家能跳出来带队。",
                ],
                "cautious": [
                    f"我是{name}，过。",
                    f"我是村民{name}，第一轮信息太少，先听发言。",
                ],
                "balanced": [
                    f"我是{name}，第一天信息不多，认真听发言中。",
                    f"我是{name}，过。先听大家的。",
                ],
            }
        else:
            templates = {
                "bold": [
                    f"我是{name}，经过昨天的事件，我认为我们应该集中精力找狼。我怀疑有几个人的发言自相矛盾。",
                    f"{name}发言：我昨天仔细听了，有人带头投票很可疑，建议大家冷静分析。",
                ],
                "cautious": [
                    f"我是{name}，昨天的事情很遗憾，今天大家冷静分析，不要乱投。",
                    f"我是{name}，跟票逻辑，目前信息仍然有限。",
                ],
                "balanced": [
                    f"我是{name}，我会认真分析每个人的发言。",
                    f"我是{name}，昨天的情况大家都看到了，需要更仔细地找线索。",
                ],
            }

        t = templates.get(style, templates["balanced"])
        return self.rng.choice(t)

    def _seer_speech(self, name: str, day: int, style: str,
                     check_results: dict) -> str:
        """预言家发言——透露查验结果。"""
        evil_found = {pid: res for pid, res in check_results.items() if res == "evil"}
        good_found = {pid: res for pid, res in check_results.items() if res == "good"}

        if evil_found:
            ids = list(evil_found.keys())
            target = ids[0]
            if style == "bold":
                return f"我是预言家！昨晚查验了{target}号，他是狼人！请大家跟我投票放逐他。我第一天的查验结果是...（稍后补充）"
            elif style == "cautious":
                return f"我是{name}，我有重要信息——我查验了{target}号，结果是狼人。希望好人相信我，今天投{target}号。"
            else:
                return f"我是预言家，我跳身份。我查验了{target}号，身份是狼人。第一天我查的是...建议大家今天放逐{target}号。"

        if good_found and style != "cautious" and day > 1:
            ids = list(good_found.keys())[-1]
            return f"我是预言家，昨晚查验了{ids}号，是好人。目前已经有{len(check_results)}条查验结果，我会继续帮大家找狼。"

        if day == 1:
            return f"我是{name}，先站边听发言，有身份也不急着跳。"

        return f"我是{name}，目前已经查验了{len(check_results)}人，我会在合适的时机公布所有查验结果。"

    def _witch_speech(self, name: str, day: int, style: str) -> str:
        """女巫发言——隐藏身份。"""
        if style == "bold":
            return f"我是{name}，昨晚我用了药（至于是解药还是毒药，你们自己猜）。我手里有信息，好人信我的话跟着我走。"
        elif style == "cautious":
            return f"我是{name}，先听发言，不急着表态。"
        else:
            templates = [
                f"我是{name}，认真分析中，希望预言家能跳出来带队。",
                f"我是{name}，过。听大家发言。",
            ]
            return self.rng.choice(templates)

    def _hunter_speech(self, name: str, day: int, style: str) -> str:
        """猎人发言——隐藏身份，暗示自己不怕死。"""
        if style == "bold":
            return f"我是{name}，我跳个神——我是猎人。谁想投我就投，看看你们敢不敢。"
        elif style == "cautious":
            return f"我是{name}，过。先听大家发言。"
        else:
            templates = [
                f"我是{name}，我不怕死，但我也不会乱带节奏。",
                f"我是{name}，建议大家好好发言，不要乱投票。",
            ]
            return self.rng.choice(templates)

    def _villager_speech(self, name: str, day: int, style: str) -> str:
        """村民发言——推理分析。"""
        if day == 1:
            templates = {
                "bold": [f"我是村民{name}，虽然第一天信息不多，但我注意到有些人的发言位置有问题。我建议大家多发言，不要划水。"],
                "cautious": [f"我是{name}，过。"],
                "balanced": [f"我是{name}，第一天先听发言，后面的轮次再好好分析。"],
            }
        else:
            templates = {
                "bold": [
                    f"我是{name}，经过前几天的发言，我认为有几个人的逻辑有问题。我建议今天认真投票，不要分票。",
                ],
                "cautious": [
                    f"我是村民{name}，信息有限，跟预言家走。",
                ],
                "balanced": [
                    f"我是{name}，我会仔细回顾每个人的发言，看看有没有矛盾的地方。",
                    f"我是村民{name}，希望大家都能认真发言，让预言家和女巫更好地判断。",
                ],
            }

        t = templates.get(style, templates["balanced"])
        return self.rng.choice(t)
