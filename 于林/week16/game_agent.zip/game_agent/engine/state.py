"""游戏状态 — 引擎的地面真相（Ground Truth），包含所有信息。"""

from dataclasses import dataclass, field
from typing import Optional, List
from engine.player import Player


@dataclass
class Event:
    """一条游戏事件。"""
    phase: str
    day: int
    event_type: str          # "wolf_kill", "seer_check", "witch_save", "night_deaths", etc.
    data: dict = field(default_factory=dict)
    public: bool = True       # 是否对所有玩家可见


@dataclass
class DeathRecord:
    player_id: int
    player_name: str
    cause: str                # "night_kill" / "vote" / "poison" / "shoot"
    phase: str


@dataclass
class DialogueRecord:
    player_id: int
    player_name: str
    phase: str
    content: str


@dataclass
class GameState:
    """引擎全局状态——地面真相。

    信息隔离时，引擎从此状态构建各玩家的 PlayerView。
    """
    players: List[Player] = field(default_factory=list)

    # 阶段
    phase_index: int = 0          # 0-7
    day_number: int = 1
    round_number: int = 0

    # 警长
    sheriff_id: Optional[int] = None

    # 女巫
    witch_antidote_used: bool = False
    witch_poison_used: bool = False
    witch_antidote_target: Optional[int] = None
    witch_poison_target: Optional[int] = None

    # 夜间临时状态
    night_kill_target: Optional[int] = None
    hunter_shoot_target: Optional[int] = None

    # 记录
    event_log: List[Event] = field(default_factory=list)
    dialogues: List[DialogueRecord] = field(default_factory=list)
    deaths: List[DeathRecord] = field(default_factory=list)

    # 终局
    is_game_over: bool = False
    winner: Optional[str] = None   # "good" / "evil"
    max_rounds: int = 200

    # ---- helpers ----

    @property
    def alive_players(self) -> List[Player]:
        return [p for p in self.players if p.is_alive]

    @property
    def alive_wolves(self) -> List[Player]:
        return [p for p in self.alive_players if p.is_wolf]

    @property
    def alive_gods(self) -> List[Player]:
        return [p for p in self.alive_players if p.is_god]

    @property
    def alive_villagers(self) -> List[Player]:
        return [p for p in self.alive_players if p.role == "villager"]

    @property
    def alive_good(self) -> List[Player]:
        return [p for p in self.alive_players if p.is_good]

    def get_player(self, pid: int) -> Optional[Player]:
        for p in self.players:
            if p.player_id == pid:
                return p
        return None

    def add_event(self, event_type: str, data: dict, public: bool = True):
        self.event_log.append(Event(
            phase=self._current_phase_name(),
            day=self.day_number,
            event_type=event_type,
            data=data,
            public=public,
        ))

    def add_dialogue(self, pid: int, content: str):
        p = self.get_player(pid)
        name = p.name if p else f"玩家{pid}"
        self.dialogues.append(DialogueRecord(
            player_id=pid, player_name=name,
            phase=self._current_phase_name(), content=content,
        ))

    def add_death(self, pid: int, cause: str):
        p = self.get_player(pid)
        name = p.name if p else f"玩家{pid}"
        if p:
            p.kill()
        self.deaths.append(DeathRecord(
            player_id=pid, player_name=name,
            cause=cause, phase=self._current_phase_name(),
        ))

    def _current_phase_name(self) -> str:
        from engine.phase import PHASES
        return PHASES[self.phase_index] if self.phase_index < len(PHASES) else "game_over"
