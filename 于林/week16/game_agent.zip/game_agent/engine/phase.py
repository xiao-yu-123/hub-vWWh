"""游戏阶段定义 — 8 个阶段的枚举和流转逻辑。"""

from enum import IntEnum


class Phase(IntEnum):
    NIGHT_WOLF = 0
    NIGHT_SEER = 1
    NIGHT_WITCH = 2
    NIGHT_RESULT = 3
    DAY_START = 4
    SPEECH = 5
    VOTE = 6
    DAY_END = 7

    @property
    def name_str(self) -> str:
        return PHASES[self.value]

    def next(self) -> "Phase":
        """返回下一个阶段，循环到 0。"""
        nxt = (self.value + 1) % len(PHASES)
        return Phase(nxt)

    @property
    def is_night(self) -> bool:
        return self.value <= Phase.NIGHT_RESULT.value

    @property
    def is_day(self) -> bool:
        return self.value >= Phase.DAY_START.value


PHASES = [
    "night_wolf",
    "night_seer",
    "night_witch",
    "night_result",
    "day_start",
    "speech",
    "vote",
    "day_end",
]


def phase_name(index: int) -> str:
    return PHASES[index] if 0 <= index < len(PHASES) else "game_over"
