"""游戏引擎 — 狼人杀核心状态机。

职责：
1. 管理 GameState —— 地面真相的唯一持有者
2. 驱动 8 个阶段的严格流转
3. 执行屠边规则胜负判定
4. 构建信息隔离后的 PlayerView（供 Agent 使用）
5. 产生结构化事件和日志

纯逻辑，无 I/O。Agent 调用由上层（API / main）编排。
"""

import random
import uuid
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Callable, Tuple

from engine.player import Player
from engine.state import GameState, Event
from engine.phase import Phase, phase_name, PHASES
from engine.decision_engine import DecisionEngine

# 角色配置预设
GAME_CONFIGS: Dict[str, List[str]] = {
    "standard_6": ["werewolf", "werewolf", "seer", "witch", "hunter", "villager"],
    "simple_4":  ["werewolf", "werewolf", "seer", "villager"],
    "big_9":     ["werewolf", "werewolf", "werewolf", "seer", "witch", "hunter",
                   "villager", "villager", "villager"],
}


# ---- 阶段执行结果 ----

@dataclass
class StepResult:
    """step() 调用的返回结构。"""
    phase: str                      # 当前阶段名
    phase_index: int
    day_number: int
    round_number: int
    step_data: dict                 # 本阶段动作/结果
    events: List[Event]             # 本阶段产生的事件
    is_game_over: bool
    winner: Optional[str]
    next_phase: str                 # 下一阶段名


# ---- 信息隔离视图 ----

@dataclass
class PlayerView:
    """从 GameState 构建的玩家合法视图。

    Agent 只收到此视图，绝无法访问地面真相。
    """
    player_id: int
    role: str
    side: str
    phase: str
    day_number: int
    my_check_results: dict             # 预言家查验结果
    known_wolf_teammates: List[int]    # 狼人可见队友
    witch_antidote_available: bool
    witch_poison_available: bool
    alive_players: List[dict]          # [{player_id, name, is_alive}, ...] 不含角色
    recent_speeches: List[dict]
    recent_events: List[dict]
    sheriff_id: Optional[int]
    action_space: List[str]            # 本阶段可执行操作


# ---- 引擎 ----

class GameEngine:
    """狼人杀游戏引擎。

    典型用法:
        engine = GameEngine("standard_6")
        while not engine.state.is_game_over:
            result = engine.step()
            print(result.phase, result.step_data)
    """

    def __init__(self,
                 config_name: str = "standard_6",
                 player_names: Optional[List[str]] = None,
                 shuffle: bool = True,
                 player_styles: Optional[Dict[str, str]] = None,
                 decision_hook: Optional[Callable] = None):
        """
        Args:
            config_name: 角色配置名
            player_names: 自定义玩家名
            shuffle: 是否随机打乱角色
            player_styles: 玩家决策风格 {"0": "bold", "1": "cautious", ...}
            decision_hook: 可选外部决策函数
        """
        if config_name not in GAME_CONFIGS:
            raise ValueError(f"Unknown config: {config_name}. "
                             f"Available: {list(GAME_CONFIGS)}")

        role_list = list(GAME_CONFIGS[config_name])
        if shuffle:
            random.shuffle(role_list)

        if not player_names:
            player_names = [f"玩家{i + 1}" for i in range(len(role_list))]

        # ---- 角色 side 映射 ----
        def _role_side(r: str) -> str:
            return "evil" if r == "werewolf" else "good"

        self.config_name = config_name
        self.game_id = uuid.uuid4().hex[:8]
        self.state = GameState(
            players=[Player(player_id=i, name=name, role=role,
                            side=_role_side(role))
                     for i, (name, role) in enumerate(zip(player_names, role_list))],
            phase_index=Phase.NIGHT_WOLF.value,
        )
        self._decision_hook = decision_hook
        self._pending_decisions: Dict[int, dict] = {}
        self.decision_engine = DecisionEngine(player_styles=player_styles or {})

    # ================================================================
    # 公共 API
    # ================================================================

    def set_phase_decisions(self, decisions: Dict[int, dict]):
        """在当前阶段执行前注入外部决策。

        由 main.py / API 调用，在 step() 之前设置。
        键为 player_id，值为 {"action": "kill", "target": 3, "content": "发言", ...}
        """
        self._pending_decisions = decisions

    def _get_decision(self, player_id: int, action: str,
                      default_target: Optional[int] = None) -> dict:
        """获取指定玩家的决策：优先使用注入的决策，否则返回默认。"""
        dec = self._pending_decisions.pop(player_id, None)
        if dec:
            return dec
        return {"action": action, "target": default_target, "content": "", "reason": "默认决策"}

    def step(self) -> StepResult:
        """推进一个阶段。

        Returns:
            StepResult — 阶段结果
        """
        if self.state.is_game_over:
            return self._make_result({})

        prev_phase = self.current_phase
        phase = self._current_phase_enum()

        # 执行阶段
        handler = {
            Phase.NIGHT_WOLF:   self._do_night_wolf,
            Phase.NIGHT_SEER:   self._do_night_seer,
            Phase.NIGHT_WITCH:  self._do_night_witch,
            Phase.NIGHT_RESULT: self._do_night_result,
            Phase.DAY_START:    self._do_day_start,
            Phase.SPEECH:       self._do_speech,
            Phase.VOTE:         self._do_vote,
            Phase.DAY_END:      self._do_day_end,
        }
        step_data = handler[phase]()
        self.state.round_number += 1

        # 推进阶段
        self.state.phase_index = (self.state.phase_index + 1) % len(PHASES)
        if self.state.phase_index == 0:
            self.state.day_number += 1

        # 最大回合安全检查
        if self.state.round_number >= self.state.max_rounds and not self.state.is_game_over:
            self.state.is_game_over = True
            self.state.winner = "evil"  # 默认狼胜

        return self._make_result(step_data)

    @property
    def current_phase(self) -> str:
        return phase_name(self.state.phase_index)

    def is_game_over(self) -> bool:
        return self.state.is_game_over

    def build_player_view(self, player_id: int) -> PlayerView:
        """构建玩家合法视图（信息隔离）。

        根据 role 过滤信息：
        - 狼人：看到其他狼队友 ID
        - 预言家：看到自己的查验结果
        - 女巫：知道药品剩余状态
        - 其他人：只看到公共信息
        """
        p = self.state.get_player(player_id)
        if p is None:
            raise ValueError(f"Player {player_id} not found")

        # 狼队友
        known_wolf_teammates = []
        if p.is_wolf:
            known_wolf_teammates = [w.player_id for w in self.state.alive_wolves
                                    if w.player_id != player_id]

        # 预言家查验结果
        my_check_results = dict(p.check_results) if p.role == "seer" else {}

        # 女巫药品
        witch_antidote_avail = (p.role == "witch" and not self.state.witch_antidote_used)
        witch_poison_avail = (p.role == "witch" and not self.state.witch_poison_used)

        # 存活玩家（脱敏：不含角色）
        alive = [pl.to_dict() for pl in self.state.alive_players]

        # 近期发言（最近 10 条）
        recent = [
            {"player_id": d.player_id, "player_name": d.player_name,
             "content": d.content, "phase": d.phase}
            for d in self.state.dialogues[-10:]
        ]

        # 近期公开事件（最近 10 条）
        recent_events = [
            {"phase": e.phase, "day": e.day, "event_type": e.event_type, "data": e.data}
            for e in self.state.event_log if e.public
        ][-10:]

        # 行动空间
        action_space = self._get_action_space(player_id)

        return PlayerView(
            player_id=player_id,
            role=p.role,
            side=p.side,
            phase=self.current_phase,
            day_number=self.state.day_number,
            my_check_results=my_check_results,
            known_wolf_teammates=known_wolf_teammates,
            witch_antidote_available=witch_antidote_avail,
            witch_poison_available=witch_poison_avail,
            alive_players=alive,
            recent_speeches=recent,
            recent_events=recent_events,
            sheriff_id=self.state.sheriff_id,
            action_space=action_space,
        )

    def get_player_view_dict(self, player_id: int) -> dict:
        """build_player_view 的 dict 版本，供 Agent prompt 使用。"""
        v = self.build_player_view(player_id)
        return {
            "phase": v.phase,
            "day_number": v.day_number,
            "players": v.alive_players,
            "recent_speeches": v.recent_speeches,
            "recent_events": v.recent_events,
            "my_action_space": v.action_space,
            "sheriff_id": v.sheriff_id,
            # 角色私密信息
            "_private": {
                "my_role": v.role,
                "my_side": v.side,
                "check_results": v.my_check_results,
                "wolf_teammates": v.known_wolf_teammates,
                "witch_antidote_available": v.witch_antidote_available,
                "witch_poison_available": v.witch_poison_available,
            },
        }

    # ================================================================
    # 阶段处理器
    # ================================================================

    def _current_phase_enum(self) -> Phase:
        return Phase(self.state.phase_index)

    def _make_result(self, step_data: dict) -> StepResult:
        """构建 StepResult。"""
        return StepResult(
            phase=self.current_phase,
            phase_index=self.state.phase_index,
            day_number=self.state.day_number,
            round_number=self.state.round_number,
            step_data=step_data,
            events=list(self.state.event_log[-5:]),
            is_game_over=self.state.is_game_over,
            winner=self.state.winner,
            next_phase=phase_name((self.state.phase_index + 1) % len(PHASES)),
        )

    def _get_action_space(self, player_id: int) -> List[str]:
        """返回当前阶段该玩家可执行的行动。"""
        p = self.state.get_player(player_id)
        if p is None or not p.is_alive:
            return []

        phase = self._current_phase_enum()
        mapping = {
            Phase.NIGHT_WOLF:   (lambda: ["kill"] if p.is_wolf else []),
            Phase.NIGHT_SEER:   (lambda: ["check"] if p.role == "seer" else []),
            Phase.NIGHT_WITCH:  (lambda: self._witch_available_actions(player_id)),
            Phase.NIGHT_RESULT: (lambda: []),
            Phase.DAY_START:    (lambda: []),
            Phase.SPEECH:       (lambda: ["speak"]),
            Phase.VOTE:         (lambda: ["vote"]),
            Phase.DAY_END:      (lambda: []),
        }
        return mapping.get(phase, lambda: [])()

    def _witch_available_actions(self, witch_id: int) -> List[str]:
        actions = []
        if not self.state.witch_antidote_used:
            if (self.state.night_kill_target is not None
                    and self.state.night_kill_target != witch_id):
                actions.append("save")
        if not self.state.witch_poison_used:
            actions.append("poison")
        return actions

    # ---- 夜间阶段 ----

    def _do_night_wolf(self) -> dict:
        """狼人选击杀目标。使用 DecisionEngine 智能选目标。"""
        wolves = self.state.alive_wolves
        if not wolves:
            return {"wolf_votes": [], "final_target": None}

        alive_dicts = [p.to_admin_dict() for p in self.state.alive_players]
        wolf_ids = [w.player_id for w in wolves]
        valid_ids = [p["player_id"] for p in alive_dicts if p["player_id"] not in wolf_ids]

        # 外部决策优先，否则用智能默认
        smart_target = self.decision_engine.wolf_kill_target(alive_dicts, wolf_ids)
        default_target = smart_target if smart_target in valid_ids else (valid_ids[0] if valid_ids else None)
        dec = self._get_decision(wolves[0].player_id, "kill", default_target)

        target = dec.get("target") if dec.get("target") in valid_ids else default_target
        self.state.night_kill_target = target

        if target is not None:
            self.state.add_event("wolf_kill", {
                "wolf_ids": [w.player_id for w in wolves],
                "target": target,
            }, public=False)

        return {
            "wolf_votes": [{"player_id": w.player_id, "target": target}
                           for w in wolves] if target else [],
            "final_target": target,
        }

    def _do_night_seer(self) -> dict:
        """预言家查验。使用 DecisionEngine 智能选目标。"""
        seers = [p for p in self.state.alive_players if p.role == "seer"]
        if not seers:
            return {"check_result": None}

        seer = seers[0]
        checked = set(seer.check_results.keys())
        alive_dicts = [p.to_admin_dict() for p in self.state.alive_players]
        valid_ids = [p["player_id"] for p in alive_dicts
                     if p["player_id"] != seer.player_id
                     and p["player_id"] not in checked]

        smart_target = self.decision_engine.seer_check_target(alive_dicts, seer.player_id, checked)
        default_target = smart_target if smart_target in valid_ids else (valid_ids[0] if valid_ids else None)
        dec = self._get_decision(seer.player_id, "check", default_target)
        target = dec.get("target") if dec.get("target") in valid_ids else default_target

        if target is not None:
            t = self.state.get_player(target)
            result = "evil" if t and t.is_wolf else "good"
            seer.check_results[target] = result
            self.state.add_event("seer_check", {
                "seer_id": seer.player_id,
                "target": target,
                "result": result,
            }, public=False)

            return {"seer_id": seer.player_id, "target": target, "result": result}
        return {"check_result": None}

    def _do_night_witch(self) -> dict:
        """女巫用药。DE 根据风格决定是否救人/毒人。"""
        witches = [p for p in self.state.alive_players if p.role == "witch"]
        if not witches:
            return {"action": None}

        witch = witches[0]
        style = self.decision_engine.style_of(witch.player_id)
        data = {"witch_id": witch.player_id}

        dec = self._get_decision(witch.player_id, "save_or_poison")
        action = dec.get("action", "")

        # 解药 — 外部决策优先，否则 DE 按风格决定
        if action == "save":
            should = True
        elif action == "poison":
            should = False
        else:
            should = self.decision_engine.witch_should_save(
                self.state.night_kill_target, witch.player_id, style)

        if (should and self.state.night_kill_target is not None
                and not self.state.witch_antidote_used
                and self.state.night_kill_target != witch.player_id):
            self.state.witch_antidote_used = True
            self.state.witch_antidote_target = self.state.night_kill_target
            data["save"] = self.state.night_kill_target
            self.state.add_event("witch_save", {"target": self.state.night_kill_target},
                                 public=False)
        else:
            data["save"] = None

        # 毒药 — 外部决策优先，否则 DE 按风格决定
        if action == "poison":
            pt = dec.get("target")
            valid = [p.player_id for p in self.state.alive_players if p.player_id != witch.player_id]
            if pt in valid:
                self.state.witch_poison_used = True
                self.state.witch_poison_target = pt
                data["poison"] = pt
                self.state.add_event("witch_poison", {"target": pt}, public=False)
            else:
                data["poison"] = None
        else:
            alive_dicts = [p.to_admin_dict() for p in self.state.alive_players]
            smart_poison = self.decision_engine.witch_poison_target(
                alive_dicts, witch.player_id, style)
            if smart_poison is not None and not self.state.witch_poison_used:
                self.state.witch_poison_used = True
                self.state.witch_poison_target = smart_poison
                data["poison"] = smart_poison
                self.state.add_event("witch_poison", {"target": smart_poison}, public=False)
            else:
                data["poison"] = None

        return data

    def _do_night_result(self) -> dict:
        """夜晚结算：处理狼刀 + 女巫解药/毒药 + 猎人开枪。"""
        deaths_today = []

        # 狼刀结算
        target = self.state.night_kill_target
        if target is not None:
            if self.state.witch_antidote_target == target:
                self.state.add_event("night_kill_saved", {"target": target})
            else:
                self.state.add_death(target, "night_kill")
                deaths_today.append({"player_id": target, "cause": "night_kill"})

                # 猎人被刀——触发开枪
                target_player = self.state.get_player(target)
                if target_player and target_player.role == "hunter":
                    shoot = self._hunter_shoot(target, "night_kill")
                    if shoot:
                        deaths_today.append(shoot)

        # 毒药结算
        if self.state.witch_poison_target is not None:
            self.state.add_death(self.state.witch_poison_target, "poison")
            deaths_today.append({"player_id": self.state.witch_poison_target,
                                 "cause": "poison"})

        self.state.add_event("night_deaths", {"deaths": deaths_today})
        self.state.night_kill_target = None
        self.state.witch_antidote_target = None
        self.state.witch_poison_target = None

        return {"deaths": deaths_today}

    def _hunter_shoot(self, hunter_id: int, cause: str) -> Optional[dict]:
        """猎人被动：被刀或被投时可开枪，DE 按风格选目标。"""
        if cause == "poison":
            return None

        targets = [p for p in self.state.alive_players
                   if p.player_id != hunter_id]
        if not targets:
            return None

        alive_dicts = [p.to_admin_dict() for p in self.state.alive_players]
        smart_target = self.decision_engine.hunter_shoot_target(alive_dicts, hunter_id)
        valid_ids = [t.player_id for t in targets]
        default_target = smart_target if smart_target in valid_ids else targets[0].player_id
        dec = self._get_decision(hunter_id, "shoot", default_target)
        target = dec.get("target") if dec.get("target") in valid_ids else default_target

        self.state.add_death(target, "shoot")
        self.state.add_event("hunter_shoot", {
            "hunter_id": hunter_id, "target": target,
        })
        return {"player_id": target, "cause": "shoot"}

    # ---- 白天阶段 ----

    def _do_day_start(self) -> dict:
        """天亮了：公布昨晚死亡信息。"""
        last_deaths = [d for d in self.state.deaths
                       if d.phase == "night_result"]
        return {
            "announced": True,
            "last_night_deaths": [
                {"player_id": d.player_id, "player_name": d.player_name,
                 "cause": d.cause}
                for d in last_deaths
            ],
        }

    def _do_speech(self) -> dict:
        """发言阶段。每个存活玩家依次发言，使用 DE 生成角色化发言。"""
        speeches = []
        for p in self.state.alive_players:
            dec = self._get_decision(p.player_id, "speak")
            content = dec.get("content", "")
            if not content:
                # DE 生成符合角色的发言
                check_results = {}
                if p.role == "seer":
                    check_results = p.check_results
                known_wolves = []
                if p.is_wolf:
                    known_wolves = [w.player_id for w in self.state.alive_wolves
                                    if w.player_id != p.player_id]
                content = self.decision_engine.generate_speech(
                    p.to_admin_dict(), self.state.day_number,
                    check_results, known_wolves,
                )
            self.state.add_dialogue(p.player_id, content)
            speeches.append({"player_id": p.player_id, "player_name": p.name,
                             "content": content})
        return {"speeches": speeches}

    def _do_vote(self) -> dict:
        """投票放逐。每人投一票（非自己），DE 按风格选目标。"""
        alive = self.state.alive_players
        if not alive:
            return {"votes": [], "eliminated": None}

        alive_dicts = [p.to_admin_dict() for p in alive]
        votes: Dict[int, int] = {}
        for voter in alive:
            candidates = [p for p in alive if p.player_id != voter.player_id]
            if not candidates:
                continue
            smart_target = self.decision_engine.vote_target(alive_dicts, voter.player_id)
            default_target = smart_target if smart_target in [c.player_id for c in candidates] else candidates[0].player_id
            dec = self._get_decision(voter.player_id, "vote", default_target)
            target = dec.get("target", default_target)
            if target not in [c.player_id for c in candidates]:
                target = candidates[0].player_id
            votes[voter.player_id] = target

        # 统计
        tally: Dict[int, int] = {}
        for target in votes.values():
            tally[target] = tally.get(target, 0) + 1

        # 警长 +1 票
        if (self.state.sheriff_id is not None
                and self.state.sheriff_id in votes):
            extra = votes[self.state.sheriff_id]
            tally[extra] = tally.get(extra, 0) + 1

        eliminated = None
        if tally:
            eliminated = max(tally, key=tally.get)
            self.state.add_death(eliminated, "vote")

            # 猎人被投——触发开枪
            ep = self.state.get_player(eliminated)
            if ep and ep.role == "hunter":
                self._hunter_shoot(eliminated, "vote")

        self.state.add_event("vote_result", {
            "votes": [{"voter": v, "target": t} for v, t in votes.items()],
            "tally": tally,
            "eliminated": eliminated,
        })

        return {
            "votes": [{"voter": v, "target": t} for v, t in votes.items()],
            "tally": tally,
            "eliminated": eliminated,
        }

    def _do_day_end(self) -> dict:
        """检查胜负。"""
        winner = self._check_win()
        if winner:
            self.state.is_game_over = True
            self.state.winner = winner
            self.state.add_event("game_over", {"winner": winner})
        return {"winner": winner}

    # ================================================================
    # 胜负判定（屠边规则）
    # ================================================================

    def _check_win(self) -> Optional[str]:
        """屠边胜负判定。

        - 好人胜利：所有狼人死亡
        - 狼人胜利：所有神职死亡 或 所有村民死亡
        """
        if not self.state.alive_wolves:
            return "good"
        if not self.state.alive_gods or not self.state.alive_villagers:
            return "evil"
        return None
