"""玩家数据结构 — 引擎内部使用的玩家状态。"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Player:
    player_id: int
    name: str
    role: str          # "werewolf" / "seer" / "witch" / "hunter" / "villager"
    side: str          # "good" / "evil"
    is_alive: bool = True
    can_act: bool = True
    check_results: dict[int, str] = field(default_factory=dict)  # pid -> "good"/"evil"

    @property
    def is_god(self) -> bool:
        return self.role in ("seer", "witch", "hunter")

    @property
    def is_wolf(self) -> bool:
        return self.role == "werewolf"

    @property
    def is_good(self) -> bool:
        return self.side == "good"

    def kill(self):
        self.is_alive = False
        self.can_act = False

    def disable(self):
        self.can_act = False

    def to_dict(self) -> dict:
        return {
            "player_id": self.player_id,
            "name": self.name,
            "is_alive": self.is_alive,
            "can_act": self.can_act,
        }

    def to_admin_dict(self) -> dict:
        d = self.to_dict()
        d["role"] = self.role
        d["side"] = self.side
        return d
