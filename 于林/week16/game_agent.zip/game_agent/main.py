"""狼人杀多智能体平台 — 主入口。

完整游戏流程：
1. 加载配置 → 2. 创建引擎 → 3. 创建玩家 Agent
→ 4. 逐阶段推进（Agent 决策） → 5. 终局复盘 → 6. 经验存储

用法：
    python main.py                        # 默认 standard_6（默认决策，不含LLM）
    python main.py --config simple_4      # 简易 4 人局
    python main.py --config big_9         # 标准 9 人局
    python main.py --mode llm             # LLM Agent 决策模式
"""

import argparse
import asyncio
import os

from engine.game_engine import GameEngine, GAME_CONFIGS
from agents.player_agent import PlayerDecision
from agents.summary import SummaryAgent, PlayerReflection
from memory.experience import (
    Experience, save_experience, get_lessons_summary,
)
from schema.game_logger import GameLogger
from schema.game_record import GameRecord


async def run_game(config_name: str = "standard_6",
                   use_llm: bool = False,
                   show_speeches: bool = True):
    """运行一局完整的狼人杀游戏。

    Args:
        config_name: 角色配置名
        use_llm: True = LLM Agent 决策，False = 默认决策
        show_speeches: 是否在控制台展示发言内容
    """
    # ---- 1. 创建引擎 ----
    engine = GameEngine(config_name)
    os.makedirs("logs", exist_ok=True)
    logger = GameLogger(f"logs/{engine.game_id}.log")
    logger.phase_start("init", 0, f"游戏创建 {config_name} (id={engine.game_id})")

    # ---- 2. 创建玩家 Agent ----
    agents = {}
    for p in engine.state.players:
        if use_llm:
            lessons = get_lessons_summary(p.role, top_n=3)
            extra = {}
            if lessons:
                extra["历史经验"] = lessons
            from agents.player_agent import PlayerAgent
            agents[p.player_id] = PlayerAgent(
                player_id=p.player_id, role_type=p.role,
                camp=p.side, player_name=p.name,
                extra_context=extra,
            )
            logger.info(f"  Agent[{p.player_id}] {p.name}({p.role})"
                        f"{' +经验' if lessons else ''}")
        else:
            agents[p.player_id] = None

    # ---- 3. 游戏主循环 ----
    step_count = 0
    while not engine.state.is_game_over and step_count < engine.state.max_rounds:
        phase = engine.current_phase
        day = engine.state.day_number
        logger.phase_start(phase, day)

        # 确定行动玩家并收集决策
        acting = _acting_players(engine)
        decisions = {}
        for pid in acting:
            if use_llm and agents.get(pid):
                agent = agents[pid]
                try:
                    view = engine.get_player_view_dict(pid)
                    dec = await agent.decide(view)
                    decisions[pid] = dec.to_dict()
                except Exception as e:
                    logger.error(f"Agent[{pid}] 决策失败: {e}")
                    decisions[pid] = {"action": "pass"}
            # 不设 decisions => 引擎使用默认决策

        if decisions:
            engine.set_phase_decisions(decisions)
        result = engine.step()
        step_count += 1

        # 记录阶段结果
        _log_step(logger, result, show_speeches)

        if result.is_game_over:
            break

    # ---- 4. 终局 ----
    logger.game_over(engine.state.winner, engine.state.day_number)

    # 保存对局记录
    os.makedirs("records", exist_ok=True)
    record = GameRecord.from_game_state(engine.state, engine.game_id, config_name)
    record_path = f"records/{engine.game_id}.json"
    record.to_json(record_path)
    logger.info(f"对局记录已保存: {record_path}")

    # ---- 5. 玩家反思 + 经验存储 ----
    if use_llm:
        await _do_reflections(engine, logger)

    logger.close()

    # ---- 6. 打印摘要 ----
    _print_summary(engine, step_count, record_path)
    return engine


# ================================================================
# 辅助函数
# ================================================================

def _acting_players(engine: GameEngine) -> list[int]:
    """返回当前阶段需要行动的玩家 ID 列表。"""
    phase = engine.current_phase
    state = engine.state

    mapping = {
        "night_wolf":  [w.player_id for w in state.alive_wolves],
        "night_seer":  [p.player_id for p in state.alive_players
                        if p.role == "seer"],
        "night_witch": [p.player_id for p in state.alive_players
                        if p.role == "witch"
                        and (not state.witch_antidote_used
                             or not state.witch_poison_used)],
        "speech":      [p.player_id for p in state.alive_players],
        "vote":        [p.player_id for p in state.alive_players],
    }
    return mapping.get(phase, [])


def _log_step(logger: GameLogger, result, show_speeches: bool):
    """记录阶段执行结果。"""
    data = result.step_data

    if result.phase == "night_result":
        for d in data.get("deaths", []):
            logger.death(d["player_id"], f"玩家{d['player_id']}", d["cause"])

    elif result.phase == "speech" and show_speeches:
        for s in data.get("speeches", []):
            logger.speech(s["player_id"], s["player_name"], s["content"])

    elif result.phase == "vote":
        logger.vote_result(
            data.get("votes", []), data.get("tally", {}),
            data.get("eliminated"),
        )


async def _do_reflections(engine: GameEngine, logger: GameLogger):
    """为每个玩家生成反思总结并保存经验。"""
    role_cn = {"werewolf": "狼人", "seer": "预言家", "witch": "女巫",
               "hunter": "猎人", "villager": "村民"}
    winner_cn = "好人方" if engine.state.winner == "good" else "邪恶方"

    for p in engine.state.players:
        camp_cn = "好人方" if p.side == "good" else "邪恶方"
        history = _personal_history(engine, p.player_id)

        try:
            sa = SummaryAgent(
                role_name=role_cn.get(p.role, p.role),
                camp_name=camp_cn,
                player_name=p.name,
                winner_name=winner_cn,
                is_winner=(p.side == engine.state.winner),
                personal_history=history,
            )
            sa.set_personal_history(history)
            ref = await sa.summarize()
        except Exception:
            ref = PlayerReflection(summary="反思生成失败")

        exp = Experience(
            role_type=p.role, camp=p.side,
            winner=engine.state.winner or "unknown",
            is_winner=(p.side == engine.state.winner),
            summary=ref.summary, strategies=ref.strategies,
            mistakes=ref.mistakes, lessons=ref.lessons,
            game_id=engine.game_id, player_name=p.name,
        )
        save_experience(exp)
        logger.info(f"经验已保存: {p.name}({p.role}) "
                     f"胜={exp.is_winner}")


def _personal_history(engine: GameEngine, player_id: int) -> str:
    """构建玩家在本局中的个人经历文本。"""
    p = engine.state.get_player(player_id)
    if p is None:
        return ""

    role_cn = {"werewolf": "狼人", "seer": "预言家", "witch": "女巫",
               "hunter": "猎人", "villager": "村民"}
    lines = [
        f"角色: {role_cn.get(p.role, p.role)}",
        f"阵营: {'好人方' if p.side == 'good' else '邪恶方'}",
    ]

    for e in engine.state.event_log:
        data = e.data
        desc = ""

        if e.event_type == "wolf_kill" and player_id in data.get("wolf_ids", []):
            desc = f"你和狼队友决定击杀玩家{data.get('target')}"
        elif e.event_type == "seer_check" and data.get("seer_id") == player_id:
            r = "狼人" if data.get("result") == "evil" else "好人"
            desc = f"你查验了玩家{data.get('target')}，结果是{r}"
        elif e.event_type == "witch_save" and data.get("target") == player_id:
            desc = "女巫使用解药救活了你"
        elif e.event_type == "hunter_shoot" and data.get("hunter_id") == player_id:
            desc = f"你作为猎人开枪带走了玩家{data.get('target')}"
        elif e.event_type == "vote_result" and data.get("eliminated") == player_id:
            desc = f"你在第{e.day}天被投票放逐"
        elif e.event_type == "night_deaths":
            for d in data.get("deaths", []):
                if d.get("player_id") == player_id:
                    desc = f"你在夜晚死亡（{d.get('cause')}）"

        if desc:
            lines.append(f"[第{e.day}天 {e.phase}] {desc}")

    for d in engine.state.dialogues:
        if d.player_id == player_id:
            lines.append(f"[发言] {d.content}")

    return "\n".join(lines) if len(lines) > 2 else "（无记录）"


def _print_summary(engine: GameEngine, step_count: int, record_path: str):
    """打印终局摘要。"""
    w = "好人阵营获胜!" if engine.state.winner == "good" else "狼人阵营获胜!"
    print("\n" + "=" * 60)
    print(f"  狼人杀对局结束 — {w}")
    print("=" * 60)
    print(f"  配置: {engine.config_name}  |  天数: {engine.state.day_number}"
          f"  |  回合: {step_count}")
    print(f"  死亡: {len(engine.state.deaths)} 人"
          f"  |  发言: {len(engine.state.dialogues)} 条")
    print(f"  记录: {record_path}")
    print("-" * 60)
    print("  角色分配:")
    for p in engine.state.players:
        s = "存活" if p.is_alive else "死亡"
        print(f"    [{p.player_id}] {p.name} - {p.role} ({p.side}) [{s}]")
    print("=" * 60)


# ================================================================
# 入口
# ================================================================

def main():
    parser = argparse.ArgumentParser(description="狼人杀多智能体平台")
    parser.add_argument("--config", default="standard_6",
                        choices=list(GAME_CONFIGS.keys()),
                        help="角色配置")
    parser.add_argument("--mode", default="default",
                        choices=["default", "llm"],
                        help="决策模式: default=默认决策, llm=AI代理")
    parser.add_argument("--quiet", action="store_true",
                        help="不显示发言详情")
    args = parser.parse_args()

    asyncio.run(run_game(
        config_name=args.config,
        use_llm=(args.mode == "llm"),
        show_speeches=not args.quiet,
    ))


if __name__ == "__main__":
    main()
